import sys, time, shutil, traceback, os
from time import sleep
import subprocess

gAddOnsDir = os.path.join(os.environ['ZEBU_DESIGN_DIR'], 'include/sw_stack')
ws = eclipse.get_workspace_path()
scriptsDir = os.path.join(os.environ['ZEBU_DESIGN_DIR'], 'scripts')
sys.path.append(scriptsDir)


rst_cbb_name = 'Reset_to_dut_if'
irq_cbb_name = 'IT_from_dut_if'
data_in_cbb_name = 'data_in'
rst_socket_name = 'Reset_Socket'


from update_hybridvdk import * 

#TODO use flow provided NORM_VZ_VER instead
def normalizeVersion(ver):
    if ver == 'NIGHTLY':
        return 9999999999
    if ver[0].isalpha() and ver[1] == '-':
        ver = ver[2:]
    l = ver.upper().replace('SP','').replace('-','.').split('.')
    if len(l) < 2:
        raise Exception("version format is not valid: " + ver)
    l.extend(['00'] * (4 - len(l)))
    if len(l[0]) == 2:
        l[0] = '20'+l[0]
    if len(l[0]) < 4:
        raise Exception("version format is not valid: " + ver)
    for i in range(1,4):
        if len(l[i]) < 2:
            l[i] = '0'+l[i]
    return int("".join(l))

def make_dir(path):
    if not os.path.isdir(path):
        os.mkdir(path)

def force_copy_file(src, dst):
    if os.path.isdir(dst):
       dst += '/' + os.path.basename(src)
    if os.path.exists(dst):
       os.remove(dst)
    shutil.copy2(src, dst)
    os.chmod(dst, 0o666)

def copytree(src, dst, symlinks=False, ignore=None):
    for item in os.listdir(src):
        s = os.path.join(src, item)
        d = os.path.join(dst, item)
        if os.path.exists(d):
            try:
                shutil.rmtree(d)
            except Exception as e:
                #print('[ERROR]: In copytree reason: %s' % str(e))
                os.unlink(d)
        if os.path.isdir(s):
            shutil.copytree(s, d, symlinks, ignore)
        else:
            shutil.copy2(s, d)

def copy_addons_to_workspace(file_path, explicit_dest=''):
    if explicit_dest != '':
        force_copy_file(os.path.join(gAddOnsDir, file_path), explicit_dest)
    else:
        force_copy_file(os.path.join(gAddOnsDir, file_path), file_path)

def copy_addons_dir_to_workspace(file_path, delete_before_copy=False, explicit_dest=''):
    if explicit_dest != '':
        dest = explicit_dest
    else:
        dest = file_path
    if delete_before_copy and os.path.exists(dest):
        shutil.rmtree(dest)
    make_dir(dest)
    copytree( file_path, dest)

    
##################################################################
############ VP CONFIG
##################################################################

def patch_vpconfig_PlatformTestBase(vdk_name):
    platformTestBasePrj = 'PlatformTestBase'

    versioned_src = f'{ws}/PlatformTestBase_{vdk_name}_{vpx.version()[0:9]}/src'
    real_dest = f'{ws}/PlatformTestBase/src'

    # AUTO file: key sequence read by platform test to automate execution
    copy_addons_to_workspace('%s/../AUTO' % versioned_src,f'{ws}/{vdk_name}/vpconfigs/PlatformTestBase/AUTO')

    for f in ['OtherFiles/Main.cpp', 'Platform/irqmap.h', 'Platform/memmap.h']:
        copy_addons_to_workspace('%s/%s' % (versioned_src, f) , '%s/%s' % (real_dest, f))

    copy_addons_dir_to_workspace('%s/Components/ARM/ZEBU' % versioned_src, False, '%s/Components/ARM/ZEBU' % real_dest)

    copy_addons_to_workspace(ws + '/%s/vpconfigs/PlatformTestBase/configure_hybrid_demo.py' % vdk_name)

    # Rebuild PlatformTestBase
    pt = eclipse.get_project(platformTestBasePrj)
    # Build eSW fails if we do not refresh eclipse project?!
    pt.refresh()
    pt.build()
 
 
def update_vpconfigs(vdk_name, linaro_ver):
    
    cfgPath = 'vpconfigs/shared'
    copy_addons_to_workspace(f'{gAddOnsDir}/shared/HybridVDK.py', f'{ws}/{vdk_name}/{cfgPath}/device_tree_input/')
    copy_addons_to_workspace(f'{gAddOnsDir}/shared/vpscript.py', f'{ws}/{vdk_name}/{cfgPath}/vpscript.py')

    if (linaro_ver == 2014):
        cfgPath = 'vpconfigs/Linaro_2014_10'
        copy_addons_to_workspace(f'{gAddOnsDir}/Linaro-2014.10/Linaro_2014_10.py', f'{ws}/{vdk_name}/{cfgPath}/device_tree_input/Linaro_2014_10.py')
        copy_addons_to_workspace(f'{gAddOnsDir}/Linaro-2014.10/configure.py', f'{ws}/{vdk_name}/{cfgPath}/configure.py')
        rsynccmd = 'rsync -avur ' +  f'{gAddOnsDir}/Linaro-2014.10/images' + " " + f'{ws}/{vdk_name}/skins/Linaro-2014.10/'
        rsyncproc = subprocess.Popen(rsynccmd,shell=True, stdin=subprocess.PIPE,stdout=subprocess.PIPE,)
        exitcode = rsyncproc.wait()
        if exitcode == 0 : 
            print("[INFO][VPCOFIG]: Linaro 2014.10 Updated...")
        else:
            print("[ERROR][VPCOFIG]: Please check the folder and files for Linaro-2014.10")
    else:
        cfgPath = 'vpconfigs/Linaro_2017_09'
        copy_addons_to_workspace(f'{gAddOnsDir}/Linaro-2017.09/Linaro_2017_09.py', f'{ws}/{vdk_name}/{cfgPath}/device_tree_input/Linaro_2017_09.py')
        copy_addons_to_workspace(f'{gAddOnsDir}/Linaro-2017.09/configure.py', f'{ws}/{vdk_name}/{cfgPath}/configure.py')
        rsynccmd = 'rsync -avurz ' +  f'{gAddOnsDir}/Linaro-2017.09/images' + " " + f'{ws}/{vdk_name}/skins/Linaro-2017.09/'
        rsyncproc = subprocess.Popen(rsynccmd,shell=True, stdin=subprocess.PIPE,stdout=subprocess.PIPE,)
        exitcode = rsyncproc.wait()
        if exitcode == 0 : 
            print("[INFO][VPCOFIG]: Linaro-2017.09 Updated...")
        else:
            print("[ERROR][VPCOFIG]: Please check the folder and files for Linaro-2017.10")
            
# Reroute connections to DRAM target @0x80000000, into HybridVDK -> FASTMEM
 
def reroute_mb_dram_to_fastmem(vdk,hybrid_vdk_ss):
    mb = vdk.get_instance('/Motherboard_ARM_Base')
    mb_initial_dram_target_if = mb.get_instance('DRAM').get_interface('MEM')

    hbb = vdk.get_instance(f'/{hybrid_vdk_ss}')
    dram_if = hbb.get_interface(data_in_cbb_name)
 
    for connection in mb_initial_dram_target_if.get_connections():
        decoding_info = connection.get_decoding_info()
        d_start_e = decoding_info.get_start_address_evaluated()

        if d_start_e == '0x80000000':
            d_start = decoding_info.get_start_address()
            d_size = decoding_info.get_size()
            #d_offset = decoding_info.get_offset()
            d_offset = '0x80000000'
            I1 = connection.get_first()
            I2 = connection.get_second()
            if I1 == mb_initial_dram_target_if:
                I3 = I2
            else:
                I3 = I1
            I3_type = I3.get_type();
            I3_name = I3.get_name();
            I3_description = I3.get_description();
            I3_protocol_id = I3.get_protocol_id();
            I3_external_masterslaveness = I3.get_external_masterslaveness();
            
            con = dram_if.connect_to(I3);
            con.set_decoding_info(start=d_start, size=d_size, offset=d_offset)
            connection.remove()
          
    d_start = '0x80000000'
    d_size = '0x80000000'
    d_offset = '0x80000000'
    hbb_intf = hbb.get_interface(data_in_cbb_name).get_connections()
    hbb_intf[1].set_decoding_info(start=d_start, size=d_size, offset=d_offset)
    
#########################################################################
###### CREATE H264 VDK
#########################################################################

def update_vdk(vdk_name='H264', hybrid_vdk_ss='ZeBu_interface', automation='semi', TB_zRci=False, vpconfig_type='Linaro'):
    
    FastMemX = False
    if (automation == "semi"):
        vdk_name=str(vdkcreator.get_current_design())
        print(f'[INFO]: Updating {vdk_name}...')
 
    if vpx.version().find('Q-2020.06') == -1 and \
       vpx.version().find('S-2021.09') == -1 and \
       vpx.version().find('T-2022.06') == -1 and \
       vpx.version().find('U-2023.03') == -1 and \
       vpx.version().find('V-2024.03') == -1 and \
       True:
        #raise Exception("Unsupported Virtualizer Version: " + vpx.version())
        print(f"[WARNING] Unsupported Virtualizer Version: {vpx.version()}")

    ###########################################
    # Create Hybrid VDK
    ###########################################
    if (automation == "full"):
        print(f'[INFO]: Creating Hybrid VDK... {hybrid_vdk_ss}')
        hybrid_vdk(hybrid_vdk_ss, automation, TB_zRci)
    else:
        print(f'[INFO]: Updating Hybrid VDK... {hybrid_vdk_ss}')
        

      ###########################################
    # Create ARM Base Reference VDK
    ###########################################
    
    if (automation == "full"):
        print(f'[INFO]: Creating {vdk_name}...')
        
        if (vpconfig_type == "Linaro"):
            vpConfigs_lst = ['Linaro_2017_09', 'Linaro_2014_10']
        elif(vpconfig_type == "Android"):
            vpConfigs_lst = ['Linaro_2014_10','Android_9_0','Android10_SW_Rendering']
        elif(vpconfig_type == "Test"): 
            vpConfigs_lst = ['PlatformTestBase']
        elif(vpconfig_type == 'All'):
            vpConfigs_lst = ['Linaro_2014_10','Linaro_2017_09','Android_9_0','Android10_SW_Rendering']
            
        arm_base_template = vdkcreator.get_template('ARM_Base_Reference_VDK').configure().set_vp_configs(vpConfigs_lst)
        vdk = vdkcreator.create_vdk(name=vdk_name, template=arm_base_template)
    else:
        print(f'[INFO]: Updating {vdk_name}...')
        vdk = vdkcreator.get_current_design()
    
    
    try:
        vdk.get_instance('Extension_Slot_0').remove()
    except:
        print('[Update] Platform Extension_Slot_0  already updated.')
    
    try:
        vdk.get_instance('Extension_Slot_1').remove()
    except:
        print('[Update] Platform Extension_Slot_1  already updated.')
    
    root = vdk.get_root()
    
     ###########################################
    # Instantiate Hybrid VDK and connect it to Motherboard Extension Slot0
    ###########################################
    print('[INFO]: Connecting  Hybrid VDK to H264 VDK ')

    if (automation == "full"):
        cbb = root.add_building_block(hybrid_vdk_ss, 'Synopsys', hybrid_vdk_ss, hybrid_vdk_ss)
    else:
        cbb = root.get_instance(hybrid_vdk_ss)
    


    rst_cbb = cbb.get_interface(rst_cbb_name)
    irq_cbb = cbb.get_interface(irq_cbb_name)
    data_in_cbb = cbb.get_interface(data_in_cbb_name)

    vdk_placeholder_intf = vdk.get_instance('/Motherboard_ARM_Base').get_interface("VDK_Extension_Placeholder1")

    # Connect DATA_INTERFACE
    data_in_cbb.disconnect()
    con = vdk.add_connection(data_in_cbb,vdk_placeholder_intf.get_interface("VDK_Extension_Placeholder1_Memory_To_BB"))
    con.set_undecoded()
    
    # Connect Reset
    rst_cbb.disconnect()
    con = vdk.add_connection(rst_cbb,vdk_placeholder_intf.get_interface("VDK_Extension_Placeholder1_Reset_2_To_BB"))

    if not TB_zRci:    
        cbb.get_interface(rst_socket_name).disconnect()
        con = vdk.add_connection(cbb.get_interface(rst_socket_name),vdk_placeholder_intf.get_interface("VDK_Extension_Placeholder1_Reset_1_To_BB"))
    
    # Connect Interrupts
    irq_cbb.disconnect()
    con = vdk.add_connection(irq_cbb,vdk_placeholder_intf.get_interface("VDK_Extension_Placeholder1_Interrupts_From_BB"))

    #! reroute connections 'to Motherboard/DRAM target @0x80000000', into FASTMEM
    reroute_mb_dram_to_fastmem(vdk,hybrid_vdk_ss)

    vdk.save()
    
    ###########################################
    # Update vpconfigs
    ###########################################
    print('[INFO]: Updating vpconfigs... Linaro : 2014.10 / 2017.09')
    
    if(vpconfig_type == 'Linaro'):
        update_vpconfigs(vdk_name, 2014)
        update_vpconfigs(vdk_name, 2017)
    elif(vpconfig_type == 'Android'):
        update_vpconfigs(vdk_name, 2014)
    elif(vpconfig_type == 'All'):
        update_vpconfigs(vdk_name, 2014)
        update_vpconfigs(vdk_name, 2017)        
        
    print('[INFO]: Updating vpconfigs done')
    vdk.save()
    vdk.build()

    return vdk

