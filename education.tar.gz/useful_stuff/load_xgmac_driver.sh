#! /bin/sh -f

export WORKSPACE=mini-aarch64-linux.6_6_hunter_wrapper

#insmod $WORKSPACE/mini-aarch64-linux/output/modules/6.6.23/kernel/drivers/net/pcs/pcs_xpcs.ko
#insmod $WORKSPACE/mini-aarch64-linux/output/modules/6.6.23/kernel/drivers/net/ethernet/stmicro/stmmac/stmmac.ko
#insmod $WORKSPACE/mini-aarch64-linux/output/modules/6.6.23/kernel/drivers/net/ethernet/stmicro/stmmac/stmmac-platform.ko
#insmod $WORKSPACE/mini-aarch64-linux/output/modules/6.6.23/kernel/drivers/net/ethernet/stmicro/stmmac/dwmac-generic.ko

insmod images-v6.6.br_kernel/modules/6.6.0/kernel/drivers/net/pcs/pcs_xpcs.ko
insmod images-v6.6.br_kernel/modules/6.6.0/kernel/drivers/net/ethernet/stmicro/stmmac/stmmac.ko
insmod images-v6.6.br_kernel/modules/6.6.0/kernel/drivers/net/ethernet/stmicro/stmmac/stmmac-platform.ko
insmod images-v6.6.br_kernel/modules/6.6.0/kernel/drivers/net/ethernet/stmicro/stmmac/dwmac-generic.ko
