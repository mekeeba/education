import os
import sys


# Usage This script will convert the standard release CPU connections from fastmem tlm ports to AXI port (sends transactions directly to HW).
# vssh -d $workspace_name -c .synopsys -s $VDK_TOP/convert_dram_connection_rtl.py
# Example
# vssh -d $VDK_WORKSPACE -c .synopsys_release_test -s $VDK_TOP/rebuild_platform_test.py

# get workspace path
workspace_path = eclipse.get_workspace_path()

print("Importing Component == " + sys.argv[0])
component = "/"+sys.argv[0].rstrip().replace("/","")

# Platform Test
target = eclipse.get(component)
target.clean()
target.build()
target.refresh()
