import os
import sys

# Set top level variables
if not "VDK_INSTALL_PATH" in os.environ:
    print("Please set VDK_INSTALL_PATH to the path of the locally installed uncompressed VDK package")
    print("System is exiting")
    sys.exit("VDK_INSTALL_PATH is not defined")
else:
    vdk_install_path = os.environ["VDK_INSTALL_PATH"]

# Set workspace path
workspace_path = eclipse.get_workspace_path()

# Optional to set active compileer
#vdkcreator.set_active_compiler("gcc-7.3-64")

# Create the New project
print("Creating new HybridVDK from VDK Package")
hybrid_vdk_project = vdkcreator.create_vdk("HybridVDK", True, vdk_install_path+"/HybridVDK/HybridVDK.vdkzip")

# Platform Test
print("Importing PlatformTest")
platform_test_project = eclipse.get("/PlatformTest")

## amba_pv_datawidth_converter_customized
#print("Importing amba_pv_datawidth_converter_customized")
#amba_pv_datawidth_converter_customized = eclipse.get("/amba_pv_datawidth_converter_customized")

# xtor_fastmem_dram2lin
print("Importing xtor_fastmem_dram2lin_adaptor")
xtor_fastmem_dram2lin = eclipse.get("/xtor_fastmem_dram2lin_adaptor")

## custom_interleaver
#print("Importing custom_interleaver")
#custom_interleaver = eclipse.get("/custom_interleaver")

# Clean the projects.
print("Cleaning Projects")
platform_test_project.clean()
#amba_pv_datawidth_converter_customized.clean()

#xtor_fastmem_dram2lin.clean()

hybrid_vdk_project.clean()
#custom_interleaver.clean()

# Build the projects.
print("Building Projects")
platform_test_project.build()
platform_test_project.refresh()

#xtor_fastmem_dram2lin.build()
#xtor_fastmem_dram2lin.refresh()

#amba_pv_datawidth_converter_customized.build()
#amba_pv_datawidth_converter_customized.refresh()
#custom_interleaver.build()
#custom_interleaver.refresh()
hybrid_vdk_project.refresh_library()
hybrid_vdk_project.update_all()
hybrid_vdk_project.build()

# Set the default active vpconfig
print("Setting Default VPconfig Linux 6.6")
hybrid_vdk_project.set_active_vp_config("Linux_v6.6")

# Print Helper Message.
print("VDK Workspace Setup Complete .... To Run VDK please execute vs -d $workspace_name &")
