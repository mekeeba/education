// -----------------------------------------------
// Copyright (c) SYNOPSYS  2005-2020
// -----------------------------------------------
// LEGAL NOTICE: This file is the sole property of
// EMULATION AND VERIFICATION ENGINEERING (EVE).
//
// This file is  provided under  a Product License
// Agreement between EVE and a Licensee.
//
// The Licensee shall not make this file available
// in any  form or  disclose or permit  disclosure
// of this file to third parties.
// -----------------------------------------------

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated"
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <queue>
#include <stdlib.h>
#include <stdexcept>
#include <exception>
#include <pthread.h>
#include <sys/timeb.h>
#include <sys/time.h>
#include <libZebu.hh>
#include <RunManager.hh>
#include "ZFSDB.hh"
#include "zRci_types.hh"
#include "ZFSDB.hh"
#include "libZebuZEMI3.hh"
//#ifdef CUSTOMBOARD
#include "XtorScheduler.hh"
#include "svt_pthread_threading.hh"
#include "svt_zebu_platform.hh"
#include <signal.h>
#define THREADING svt_pthread_threading
#define PLATFORM svt_zebu_platform
//#endif

#include "ProxyEnv.hh"


#include "ProxyUSBXtor.hh"
#include <cassert>
#include "xtor_usb_svs.hh"

#if (defined(ZRCI_VERSION) && ZRCI_VERSION==4)
  #define EXTERN_C
  #define SIMZ ZRCI
#else
  #define EXTERN_C extern "C"
#endif

//#ifdef PA
//#include "libZebuZEMI3.hh"
//#endif

#pragma GCC diagnostic pop

#ifndef ZWORK
#define ZWORK "zebu.work"
#endif

using namespace std;
using namespace ZEBU;
using namespace ZEBU_IP;
using namespace ZRCI;
using namespace ZEBU_VM;

using namespace ZEBU_MP ;

Board *zebu_board = NULL;
const char* xmlFile = NULL;
int debugLevel = 5;
bool saveDone = false;
ProxyEnv::Callbacks_t cbs;
pthread_t pbiThread;
pthread_mutex_t mutex;
ProxyEnv *env = NULL;

ZEBU_IP::XTOR_USB_SVS::xtor_usb_svs* usb3_xtor ;

//To use USB Mass Storage device model
#if defined(USB_MASS_STORAGE_MODEL)
  #include "USB3DeviceMassStorage.hh"
  using namespace SNPS::VSA::VDM::USB ;
  USB3DeviceMassStorage *dev_model = nullptr ;
  #if defined(USB_MASS_STORAGE_TWO_INSTANCES)
    USB3DeviceMassStorage *dev_model_1 = nullptr ;
  #endif
#endif

void catch_sigalarm(int sig, siginfo_t* info, void* vp) {
    return;
}

int run_dev_test(bool, void*, const char* dev_inst) ;

void wait_for_dev_completion() ;

//void
//connectHandshake()
//{
//    FILE *fp = fopen("ready_to_connect", "w");
//    if (fp == NULL) {
//        printf("Cannot create ready_to_connect\n");
//        exit(-1);
//    } else {
//        printf("Created regular file ready_to_connect\n");
//        setvbuf(fp, NULL, _IONBF, 0);
//    }
//}
//
//
//bool
//ready(void *arg)
//{
//    fprintf(stderr, "ProxyTB is ready to connect.\n");
//    return true;
//}

static void preUSBInitBFMCB(ProxyUSBXtor* proxyUSB, void* xtor, void* user_arg)
{
  std::cout << "inside the PreUSBInitBFM callback" << std::endl ;
  //ZEBU_IP::XTOR_USB_SVS::xtor_usb_svs* usb3_xtor = 
  //                       (ZEBU_IP::XTOR_USB_SVS::xtor_usb_svs*)xtor ;
  usb3_xtor = (ZEBU_IP::XTOR_USB_SVS::xtor_usb_svs*)xtor ;
  if (usb3_xtor) {
     //usb3_xtor->addConfigParam("DRD_HostReset", (bool)false) ;
      usb3_xtor->writeUserIO(uint32_t(2)) ;
  }
}

bool
postOpenFct(ProxyEnv *env, ZEMI3Manager *z3mgr, ZEBU::Board *zboard, void* arg)
{
    zebu_board = zboard;
    
    return true;
}


bool
readyFct(ProxyEnv *env, void* arg)
{
    printf("ProxyEnv is ready to connect...\n");
    //connectHandshake();

    return true;
}


bool
rxMsg(const char* name, unsigned int len, const uint8_t *data, ProxyEnv *env, void* args)
{
//    // Ignore IPv4 and IPv6 packets. Those are administrative packets sent by the Guest O/S itself
//    if ((data[12] == 0x08 && data[13] == 0x00)
//        || (data[12] == 0x86 && data[13] == 0xdd)) return true;
//
//    printf("%s: Received %d bytes...\n", name, len);
//
//    // Provide a reply to the 'ping.py' script
//    if (len < 1024) {
//        uint8_t reply[1024];
//
//        memcpy(reply, data, len);
//        
//        // Increment the first byte, and send it back right away
//        reply[0]++;
//        env->tapSendFct(name, len, reply);
//    }
//    
    return true;
}


bool
resetFct(ProxyEnv *env, void* arg)
{
    printf("ProxyEnv is resetting...\n");
    return true;
}


bool
restartFct(ProxyEnv *env, void* arg)
{
    printf("ProxyEnv is restarting...\n");
    return true;
}


bool
shutdownFct(ProxyEnv *env, void* arg)
{
    printf("ProxyEnv is shutting down...\n");
    std::string strTclCmd;
    strTclCmd = "exit";
    printf("TCL command callback is \"%s\"\n",strTclCmd.c_str());
    zRci_UCLI_callback(strTclCmd.c_str());
    sleep(5);

    return true;
}


bool
saveFct(const char* saveTo, ProxyEnv *env, void* arg)
{
    printf("ProxyEnv is saving to \"%s\"...\n", saveTo);
    sleep(5);
    std::string strTclCmd;
    strTclCmd = "__save_dmtcp_cmd_from_usb_xtor ";
    strTclCmd += saveTo;
    printf("VM is checkpointing \"%s\"\n", saveTo);
    printf("TCL command callback is \"%s\"\n", strTclCmd.c_str());
    zRci_UCLI_callback(strTclCmd.c_str());
    while (true) {
        if (saveDone) break;
    }
    return true;
}


void* proxyEnv(void*)
{
    fprintf(stderr,"***Spawned-off proxyEnv Thread***\n");

#ifdef DMTCP_ENABLE
    env->DMTCP_VM.enable();
#endif

#if defined(USB_MASS_STORAGE_MODEL)
    dev_model->Initialize() ;
    dev_model->Enable() ;
    dev_model->Start() ;

  #if defined(USB_MASS_STORAGE_TWO_INSTANCES)
    dev_model_1->Initialize() ;
    dev_model_1->Enable() ;
    dev_model_1->Start() ;
  #endif

#endif

    env->startAllProxyXtors();
    fprintf(stderr,"***Start ProxyEnv Connect***\n");
    env->connect();

    return NULL;
}


void
usage(const char* cmd)
{
    fprintf(stderr, "Usage: %s [options] config.xml\n", cmd);
    fprintf(stderr, "   -D n        Set debug level.\n");
    fprintf(stderr, "   -h          Print this help message.\n");
    fprintf(stderr, "\n");
    
    exit(-1);
}


EXTERN_C void* zRci_pre_board_open(const ZRCI::TbOpts&) {

    fprintf (stderr,"===================================================================\n");
    fprintf (stderr,"======================= simz_pre_board_open =======================\n");
    fprintf (stderr,"===================================================================\n");

    return 0;

}

EXTERN_C void* zRci_post_board_open(const ZRCI::TbOpts& tbopts) {

	zebu_board = tbopts.board;
	
    fprintf (stderr,"===================================================================\n");
    fprintf (stderr,"===================== simz_post_board_open  =======================\n");
    fprintf (stderr,"===================================================================\n");

    // zebu_board = tbopts.board;
    
    cbs.postOpenFct             = postOpenFct;
    cbs.readyFct                = readyFct;
    cbs.tapRecvFct              = rxMsg;
    cbs.resetFct                = resetFct;
    cbs.restartFct              = restartFct;
    cbs.shutdownFct             = shutdownFct;
    cbs.saveFct                 = saveFct;
    cbs.arg                     = NULL;
 
    
    return 0;
}

EXTERN_C void* zRci_pre_board_init(const ZRCI::TbOpts& tbopts) {

    fprintf (stderr,"===================================================================\n");
    fprintf (stderr,"==================== simz_pre_board_init ==========================\n");
    fprintf (stderr,"===================================================================\n");
/*
//#ifdef CUSTOMBOARD
//    ZEBU_MP::svt_c_runtime_cfg *runtime   = ZEBU_MP::svt_c_runtime_cfg::get_default();
//    runtime->set_platform(new ZEBU_MP::svt_zebu_platform(board, true));
//    if (runtime->get_threading_api() == NULL) {
//    	runtime->set_threading_api(new ZEBU_MP::svt_pthread_threading());
//    }
//#endif


    bool zEmiRun = false;
    svt_pthread_threading *threading = new svt_pthread_threading();
    fprintf (stderr,"[pre_board_init] STEP 1\n");
    svt_c_runtime_cfg *runtime = new svt_c_runtime_cfg();
    runtime->set_threading_api(threading);
    runtime->set_platform(new svt_zebu_platform(zebu_board, zEmiRun));
    svt_c_runtime_cfg::set_default(runtime);
    fprintf (stderr,"[pre_board_init] STEP 2\n");


    std::string presentWD = getenv("PWD");
#if defined(USB_DEV_32)
    presentWD += "/../config_usb32.xml";
#else
  #if defined(USB_MASS_STORAGE_TWO_INSTANCES)
    presentWD += "/../config_two_usb_devs.xml" ;
  #else
    presentWD += "/../config.xml";
  #endif
#endif

    xmlFile = presentWD.c_str();
	fprintf (stderr,"[pre_board_init] STEP 3\n");
      env = new ProxyEnv("env", xmlFile, zebu_board, &cbs, debugLevel);
      fprintf (stderr,"[pre_board_init] STEP 4\n");
      //env = new ProxyEnv("env", xmlFile, tbopts.manager , &cbs, debugLevel);
 */ 
    return 0;
}

EXTERN_C void* zRci_post_save(const ZRCI::TbOpts& tbopts){
    fprintf (stderr,"Hardware Save Completed!\n");
    saveDone = true;
    //connectHandshake();

    return 0;
}

EXTERN_C void* zRci_post_board_init(const ZRCI::TbOpts& TbOpts){

// As suggested by CB in Jira

    fprintf (stderr,"===================================================================\n");
    fprintf (stderr,"=============== pre_board_init IN post_board_init =================\n");
    fprintf (stderr,"===================================================================\n");


    bool zEmiRun = false;
    svt_pthread_threading *threading = new svt_pthread_threading();
    fprintf (stderr,"[pre_board_init] STEP 1\n");
    svt_c_runtime_cfg *runtime = new svt_c_runtime_cfg();
    runtime->set_threading_api(threading);
    runtime->set_platform(new svt_zebu_platform(zebu_board, zEmiRun));
    svt_c_runtime_cfg::set_default(runtime);
    fprintf (stderr,"[pre_board_init] STEP 2\n");


    std::string presentWD = getenv("PWD");
#if defined(USB_DEV_32)
    presentWD += "/../config_usb32.xml";
#else
  #if defined(USB_MASS_STORAGE_TWO_INSTANCES)
    presentWD += "/../config_two_usb_devs.xml" ;
  #else
    presentWD += "/../config.xml";
  #endif
#endif

    xmlFile = presentWD.c_str();
	fprintf (stderr,"[pre_board_init] STEP 3\n");
      env = new ProxyEnv("env", xmlFile, zebu_board, &cbs, debugLevel);
      fprintf (stderr,"[pre_board_init] STEP 4\n");
      //env = new ProxyEnv("env", xmlFile, tbopts.manager , &cbs, debugLevel);

// END Jira suggestion

    fprintf (stderr,"===================================================================\n");
    fprintf (stderr,"==================== simz_post_board_init =========================\n");
    fprintf (stderr,"===================================================================\n");

    fprintf(stderr, " %d  %d ZRCI Mode is \n ", TbOpts.mode, ZRCI::TB_MODE_REPLAY  ) ;
    if (TbOpts.mode == ZRCI::TB_MODE_REPLAY) {
    } else {
//#ifdef PA
//        if (zemiManager != NULL) {
//            fprintf(stderr,"starting ZEMI3Manager\n");
//            zemiManager->start();
//        }
//#endif
      const char *dev_inst_1     = "hw_top.top1.usb_device"; 
      //const char *dev_inst_1     = "hw_top.top1.Device" ;

      //const char *dev_inst_1     = "hw_top.top1.usb_instances[1].usb" ;

	ProxyUSBXtor* usb0 = env->getProxyUSBXtor("usb0") ;
        usb0->setPreUSBInitBFMCB(preUSBInitBFMCB, NULL) ;
        assert (usb0 != NULL) ;

#if defined(USB_MASS_STORAGE_MODEL)
      //Lets create the USB Device Model...
      //dev_model = new USB3DeviceMassStorage(dev_inst_1,"hw_top.top1.clk_48m", "usb_strick_1.img", 0xA00000) ;
      dev_model = new USB3DeviceMassStorage(dev_inst_1,"hw_top.top1.clk_48m", "usb_strick_1.img", 0xA00000) ;

      assert (dev_model != nullptr) ;

      dev_model->Create() ;

  #if defined(USB_MASS_STORAGE_TWO_INSTANCES)

      //const char *dev_inst_2     = "hw_top.top2.inst[1].usb";
      const char *dev_inst_2     = "hw_top.top2.usb_device";

      ProxyUSBXtor* usb1 =
                     env->getProxyUSBXtor("usb1") ;
      assert (usb1 != NULL) ;
      usb1->setPreUSBInitBFMCB(preUSBInitBFMCB, NULL) ;

      dev_model_1 = new USB3DeviceMassStorage(dev_inst_2,"hw_top.top2.clk_48m", "usb_strick_2.img", 0x1400000) ;

      assert (dev_model_1 != nullptr) ;

      dev_model_1->Create() ;
  #endif

#else

  #if defined(USB_DEV_32)
        run_dev_test(true, usb0, dev_inst_1) ;
  #else
        run_dev_test(false, usb0, dev_inst_1) ;
  #endif

#endif
	pthread_create (&pbiThread, NULL, proxyEnv, NULL);
        fprintf(stderr, "Thread pbiThread created\n");
    }
    return 0;
}

void* unplug_device() ;

EXTERN_C void* zRci_param (const std::string& key, const std::string &value)
{
    std::cerr << " simz_param: key = " << key << " value = " << value << std::endl;
  
    if (key == "usb0_debug") {
        int debug_level = -1;
    	bool valid = true;
    	if (sscanf(value.c_str(),"%d",&debug_level) != 1) {
    	     valid = false;
    	}
    	if (debug_level < -1 || debug_level > 5) {
    	     valid = false;
    	}
    	if ( ! valid ) {
    	     fprintf(stderr,"WARNING: wrong usb0_debug specified. Expected a number between 0-5\n");
    	} else {
    	     fprintf(stderr,"Setting usb0 debug level to %d\n",debug_level);
    	     debugLevel = debug_level;
    	}
    }
    if (key == "xmlFile") {
        const char* c = value.c_str();
        xmlFile = c;	
    }

    return NULL;
}

void start_fwc_waveform(Board* board) ;
void stop_fwc_waveform() ;
void connect_device() ;
void resume_device_autowakeup() ;

EXTERN_C std::string zRci_command(const std::string& key, const std::string& value)
{
  fprintf(stderr, "The command name is: %s\n", key.c_str()) ;
  if (key == "start_fwc_waveform")
  {
    fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
    start_fwc_waveform(zebu_board) ;
    fprintf(stderr, "End command: %s\n", key.c_str()) ;
  }
  else if (key == "stop_fwc_waveform")
  {
    fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
    stop_fwc_waveform() ;
    fprintf(stderr, "End command: %s\n", key.c_str()) ;
  }
  else if (key == "unplug_device")
  {
    fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
    unplug_device() ;
    fprintf(stderr, "End command: %s\n", key.c_str()) ;
  }
  else if (key == "plug_device")
  {
    fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
    connect_device() ;
    fprintf(stderr, "End command: %s\n", key.c_str()) ;
  }
  else if (key == "suspend_device")
  {
    if(usb3_xtor)
    {
      fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
      ZEBU_IP::XTOR_USB_SVS::zusb_status status ;
      status = usb3_xtor->suspendDevice() ;
      fprintf(stderr, "End command: %s, command status: %d\n", key.c_str(), status) ;
    }
  }
  else if (key == "resume_device_autowakeup")
  {
    fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
    resume_device_autowakeup() ;
    fprintf(stderr, "End command: %s\n", key.c_str()) ;
  }
  else if (key == "resume_device")
  {
    if(usb3_xtor)
    {
      fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
      ZEBU_IP::XTOR_USB_SVS::zusb_status status ;
      status = usb3_xtor->resumeDevice() ;
      fprintf(stderr, "End command: %s, command status: %d\n", key.c_str(), status) ;
    }
  }
  else if (key == "check_link_state")
  {
    if(usb3_xtor)
    {
      fprintf(stderr, "Starting command: %s\n", key.c_str()) ;
      int link_state = usb3_xtor->getUSBLinkState() ;
      const char* link_state_str = usb3_xtor->getUSBLinkState_string(link_state) ;
      fprintf(stderr, "End command: %s, link state: %d(%s)\n", key.c_str(), link_state, (link_state_str ? link_state_str : "")) ;
    }
  }
  else
  {
    fprintf(stderr, "The command: %s, not implemented.\n", key.c_str()) ;
  }
  return key ;
}


EXTERN_C void* zRci_cleanup (const SIMZ::TbOpts &opts)
{
    printf ("===================================================================\n");
    printf ("==========================  simz_cleanup start ====================\n");
    printf ("======================= mode: %d =========== =======================\n",opts.mode);
    printf ("===================================================================\n");
    fflush(stdout);

#if !defined(USB_MASS_STORAGE_MODEL)
    wait_for_dev_completion() ;
#endif
    env->shutdown() ;
    delete env ;

    //sleep(10);

//#ifdef PA
//    if (zemiManager != NULL) {
//        zemiManager->terminate();
//    }
//#endif

    printf ("===================================================================\n");
    printf ("==========================  simz_cleanup end ======================\n");
    printf ("===================================================================\n");
    fflush(stdout);

    return 0;
}
