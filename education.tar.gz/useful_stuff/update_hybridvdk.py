import sys, time, shutil, traceback, os
from time import sleep

#rst_cbb_name = 'Reset_to_dut_if'
rst_cbb_name = 'Reset_to_dut_i_sigin_reset_from_systemc_if'
#irq_cbb_name = 'IT_from_dut_if'
irq_cbb_name = 'SBSig_from_dut_i_sigout_if'

data_in_cbb_name = 'data_in'

rst_socket_name = 'Reset_Socket'

add_mem_test = False

hybrid_bb_name = 'ZebuCockpit_BB'

def add_tlmc_parameter(tlmcP, name, type, default_val):
    try:
        tlmc_param = tlmcP.add_parameter()
        tlmc_param.set_name(name)
        tlmc_param.set_type(type)
        tlmc_param.set_default_value(default_val)
    except:
        print("Parameter "+name+" already present, skipping it")
        
def add_tlmc_interface(tlmcP, name, type):
    try:
        tlmc_param = tlmcP.add_interface()
        tlmc_param.set_name(name)
        tlmc_param.set_type(type)
    except:
        print("Interface "+name+" already present, skipping it")
    
def update_mmc_tlmc():
    
    print('[INFO][TLMC]: Updating MMC Adaptor')
    
    mmc_name =  "xtor_mmc_device_svs_adaptor"
        
    mmc = tlmcreator.load_model('xtor_mmc_device_svs_adaptor')
 
    # Adding Parameters   
    add_tlmc_parameter(mmc, "StartCardPresent", "unsigned int", "1")
    add_tlmc_parameter(mmc, "cardType", "std::string", "\"MMCv4.4\"")
    add_tlmc_parameter(mmc, "cardName", "std::string", "\"mmc_linux\"")
    add_tlmc_parameter(mmc, "cardFile", "std::string", "\"card0.ext2.bin\"")
    add_tlmc_parameter(mmc, "configNum", "unsigned int", "0")
    add_tlmc_parameter(mmc, "Monitor", "bool", "false")

    # Adding Interfaces:
    
    add_tlmc_interface(mmc, "CardDetect", "sc_core::sc_in<unsigned int>")
    add_tlmc_interface(mmc, "WriteProtect", "sc_core::sc_in<unsigned int>")
    add_tlmc_interface(mmc, "PowerOn", "sc_core::sc_in<bool>")

    # Instances & Callbacks:
    
    mmc_adaptor = mmc.get_instance('adaptor')

    mmc_adaptor.get_callback('on_run_start').set_enabled(True)
    mmc_adaptor.get_callback('on_board_close').set_enabled(True)
    
    mmc.save()
    
    linux_src = os.environ['ZEBU_DESIGN_DIR'] +'/include/card/VDK_Card_Linux2.hh'
    linux_dst = eclipse.get_workspace_path()  +"/xtor_mmc_device_svs_adaptor/VDK_Card_Linux2.hh"
        
    shutil.copy2(linux_src, linux_dst)
    
    mmc_base_src = os.environ['ZEBU_DESIGN_DIR'] + "/include/mmc_adaptor/"
    mmc_base_dst = eclipse.get_workspace_path()  + "/xtor_mmc_device_svs_adaptor"
         
    shutil.copy2(mmc_base_src + mmc_name + ".cc", mmc_base_dst + "/"+ mmc_name + ".cc")
    shutil.copy2(mmc_base_src + mmc_name + ".h", mmc_base_dst + "/"+ mmc_name + ".h")
        
    mmc.save()
    mmc.build()

  
def hybrid_vdk(vdk_name='DUT', automation='semi' , TB_zRci=False):
 
    if (automation == "full"):
        hvdk = vdkcreator.create_building_block(name=vdk_name)
        HYBRID_VDK_NAME=vdk_name
    else:
        hvdk = vdkcreator.get_current_design()    
        HYBRID_VDK_NAME = str(vdkcreator.get_current_design())

    # Create a HybridVDK
    hvdk.get_library_manager().add_path('${ZEBU_ADAPTOR_PATH}')

    # Set information of the HybridVDK   
    hvdk.set_vendor('Synopsys')
    hvdk.set_library_name(HYBRID_VDK_NAME)
    hvdk.set_name(HYBRID_VDK_NAME)
    hvdk.set_version('1.0')
    hvdk.set_hw_category('VDK')
    hvdk.set_hw_vendor('Synopsys')
    hvdk.set_hw_name(HYBRID_VDK_NAME)
    hvdk.set_description('HybridVDK Extension for H264 Demo')
    
    print('[INFO_HVDK]: Updating  ' + HYBRID_VDK_NAME)
    
    root = hvdk.get_root()
    
    if (automation == 'full'):
        cbb = root.add_building_block(hybrid_bb_name,"Synopsys","ZebuHybrid","ZHAL_CBB")
    else:
        cbb = root.get_instance(hybrid_bb_name)

    cbb_config = cbb.get_configuration()   
    
    tmp_config = cbb_config.duplicate()
    
    #zb_intf = tmp_config.get_parameter('top_interfaces').get_values()
    if (vpx.version() != "V-2024.03" ): 

        zb_intf = tmp_config.get_parameter('top_interfaces').get_values()
        
        # Configuring AXI3 @ 32Bits: AMBA_TARGET
        zb_intf[1].get_parameter("type").set_value("interrupts")

        # Configuring AXI3 @ 32Bits: AMBA_TARGET
        zb_intf[2].get_parameter("memmap_size").set_value("0x20000")
        zb_intf[2].get_parameter("hybridregserver").set_value("True")

        # Configuring FASTMEME
        zb_intf[4].get_parameter("memmap_size").set_value("0x80000000")
        zb_intf[4].get_parameter("frontdoor_adaptor").set_value("AMBA_target_1")
        zb_intf[4].get_parameter("base_address").set_value("0x80000000")

        if (TB_zRci):
        
            print('[INFO_HVDK]:  Removing MMC Adaptor Interface: from ZHAL_CBB')
            
            if(zb_intf[5].get_id() == 'video_out'):
                print("zRci for Video is in development...")
                zb_intf[6].remove()
            else:
                zb_intf[5].remove()
            
            
            cbb.regenerate(tmp_config)
                
            print('[INFO_HVDK]:  Saving new configuration in CSV file... ')
            tmp_config.export_configuration(hybrid_bb_name)
            
            sys_manager = cbb.get_instance("SystemManager")
            sys_manager.get_parameter("External_lib/external_lib_path").set_value('$(ZEBU_DESIGN_DIR)/testbench_zRci/rundir/libTB.so')
            
    elif(vpx.version() == "V-2024.03"):

        ########### ####### ZHAL - 2024.03  ################### ######################

        zb_cat = tmp_config.get_parameter('Zebu Category').get_values()
        #       
        zb_hyb = zb_cat[0]
        #    
        zb_hyb= zb_cat[0].get_parameter('hybrid_interfaces').get_values()     
        # Configuring AXI3 @ 32Bits: AMBA_TARGET
        zb_hyb[0].get_parameter("memmap_size").set_value("0x20000")
        zb_hyb[0].get_parameter("hybridregserver").set_value("True")

        # Configuring FASTMEME
        fastMem = zb_hyb[2]
        #fm_par = zb_hyb[2].get_parameters()
        #fm_reg = fm_par[1].get_values() # // It does not show the regions
        fm_reg = zb_hyb[2].get_parameter("mapping").get_values()
        mem_0 = fm_reg[0].get_parameter('Region').get_values()
                 
        #mem_0[0].get_parameter("memmap_size").set_value("0x80000000") // It is now done automatically
        mem_0[0].get_parameter("base_address").set_value("0x80000000")
        
        #zb_hyb[2].get_parameter("frontdoor_adaptor").set_value("AMBA_target_1") // Also done automatically

        #zb_hyb[2].get_parameter("memmap_size").set_value("0x80000000")
        #       zb_hyb[2].get_parameter("frontdoor_adaptor").set_value("AMBA_target_1")
        #       zb_hyb[2].get_parameter("base_address").set_value("0x80000000")
    
        # Configuring AXI3 @ 32Bits: AMBA_TARGET
        zb_hyb[4].get_parameter("type").set_value("interrupts")
        
        #fm = zb_hyb[2].get_parameters()
        #fm_rega = fm[1].get_values()
        #mem = a[0].get_parameter('Region').get_values()

        # If the platform will run with a precompiled Testbench zRci. 

        zb_tst = zb_cat[1].get_parameter('testbench_interfaces').get_values()     

        if(zb_tst[0].get_id() == 'video_out'):
             zb_tst[0].get_parameter('width').set_value(641)
 

        if (TB_zRci):

            print('[INFO_HVDK]:  Removing MMC Adaptor Interface: from ZHAL_CBB')
            
            if(zb_tst[0].get_id() == 'video_out'):
                print("zRci for Video is in development...")
                zb_intf[6].remove()
            else:
                zb_intf[5].remove()
            
            
            cbb.regenerate(tmp_config,'generate')
                
            print('[INFO_HVDK]:  Saving new configuration in CSV file... ')
            tmp_config.export_configuration(hybrid_bb_name + ".csv")
            
            sys_manager = cbb.get_instance("SystemManager")
            sys_manager.get_parameter("External_lib/external_lib_path").set_value('$(ZEBU_DESIGN_DIR)/testbench_zRci/rundir/libTB.so')
        
        
    else:
       print ("Unsupported Version... Please, Check Configuration ") 
       
    print('[INFO_HVDK]: Regenerating ZHAL_CBB')
    cbb.regenerate(tmp_config, 'generate')

    print('[INFO_HVDK]:  Connecting ZHAL_CBB to VDK')
    tmp_config.export_configuration(hybrid_bb_name+".csv")
        
    ###########################################
    # Update VMMC Adaptor TLMC
    ###########################################
    print('[INFO_HVDK][TLMC]: Updating MMC Adaptor...')
    update_mmc_tlmc()
    hvdk.update_all()
    print('[INFO_HVDK][TLMC]: Updating MMC Adaptor Done')
    print('[INFO_HVDK]:  Integrating additional components...')
    # DesignWare eMMC Socket IP
    card_socket = root.add_building_block('i_DW_MMC_Socket', 'Synopsys', 'DESIGNWARE_MOBILESTORAGE', 'CardSocket')
    card_socket.get_parameter_group('DWSLL', 'EXTRA_PROPERTIES').get_parameter('Param_StartCardPresent').set_value(0)
    card_socket.get_interface("Reset").externalize("ROOT","Reset_Socket")
    # Previously Called :genZebuIp
    
    emmc = cbb.get_instance("ZebuIp_mmc_card")
    # DesignWare eMMC Socket to external Reset
    # Connect DesignWare eMMC Socket <-> ZeBu eMMC Adaptor
    hvdk.add_connection(emmc.get_interface('CardDetect'), card_socket.get_interface('CardSocket').get_interface_in_slot('CardPresent'))
    hvdk.add_connection(emmc.get_interface('WriteProtect'), card_socket.get_interface('CardSocket').get_interface_in_slot('WriteProtect'))
    # stub ZeBu eMMC Adaptor Port
    emmc.get_interface('PowerOn').stub_with('Synopsys','VDKC_MODELS','signal_drive')
    emmc.get_interface('PowerOn').get_stub().get_parameter('DT').set_value('bool')
    emmc.get_interface('PowerOn').get_stub().get_parameter('output_value').set_value(1)
    emmc.get_parameter('cardFile').set_value('$(ZEBU_DESIGN_DIR)/card0.ext2.bin')

    print('[INFO]: Externalizing Interfaces')
    hvdk.save()
    hvdk.build()

    cbb.get_interface(data_in_cbb_name).externalize("ROOT")
    cbb.get_interface(irq_cbb_name).externalize("ROOT")
    cbb.get_interface(rst_cbb_name).externalize("ROOT")

    hvdk.save()
    hvdk.build()
    
    
    if (add_mem_test):
        # RAM Memory
        ram = root.add_building_block('i_RAM_Memory', 'Synopsys', 'GenericIPlib', 'Memory_Generic')
        ram.get_parameter('BUSWIDTH').set_value('32')
        ram.get_interface('CLK').stub()
     
        ram.get_interface('p_PSELECT').stub()
        ram.get_interface('p_PowerDown').stub()
        ram.get_interface('p_Retention').stub()
         
        con = hvdk.add_connection(root.get_interface("data_in"), ram.get_interface('MEM'))
        con.set_decoding_info(start=0x400000, size=0x400000)
    
        # Test Verification Memory
        test_result = root.add_building_block('i_Test_Verification_Memory', 'Synopsys', 'GenericIPlib', 'Memory_Generic')
        test_result.get_parameter('BUSWIDTH').set_value('32')
        test_result.get_parameter('initial_value').set_value('0')
        
        # Test Verification Memory <-> Ext_IF_Memory_To_BB
        con = hvdk.add_connection(root.get_interface("data_in"), test_result.get_interface('MEM'))
        con.set_decoding_info(start=0x8000, size=0x8)
        test_result.get_interface('CLK').stub()
        
        test_result.get_interface('p_PSELECT').stub()
        test_result.get_interface('p_PowerDown').stub()
        test_result.get_interface('p_Retention').stub()

#hybrid_vdk("HYBRID_VDK_NAME", "semi", True)
#hybrid_vdk("HYBRID_VDK_NAME", "semi", False)

