import sys, time, shutil, traceback, os
from time import sleep

scriptsDir = os.path.join(os.environ['ZEBU_DESIGN_DIR'], 'scripts')

sys.path.append(scriptsDir)

ws = eclipse.get_workspace_path()

from update_hybridvdk import * 
from update_h264vdk import *


vdk_name = "H264"
HYBRID_VDK_NAME = "Zebu_Interface"
automation = "full"
testbench_zRci = False
vpconfig_type = "Linaro"
update_vdk(vdk_name, HYBRID_VDK_NAME, automation, testbench_zRci, vpconfig_type)
