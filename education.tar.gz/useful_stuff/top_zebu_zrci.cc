//---------------------------------------------------------------------
// COPYRIGHT (C) 2016 SYNOPSYS INC.
// This software and the associated documentation are confidential and
// proprietary to Synopsys, Inc. Your use or disclosure of this software
// is subject to the terms and conditions of a written license agreement
// between you, or your company, and Synopsys, Inc. In the event of
// publications, the following notice is applicable:
//
// ALL RIGHTS RESERVED
//
// The entire notice above must be reproduced on all authorized copies.

#include "zRci_types.hh"
#include "svt_pthread_threading.hh"
#include "svt_zebu_platform.hh"
#include "libZebuZEMI3.hh"
#include "ZFSDB.hh"
#include "ZEMI3Xtor.hh"

#include "XtorScheduler.hh"
#include "test_base.hh"
#include "test_bulk.hh"
#include "test_bulk_stream.hh"
#include "test_bulk_cancel_urb.hh"
#include "test_bulk_dmtcp.hh"
#include "test_intr.hh"
#include "test_isoc.hh"
#include "test_bulk_role_switch.hh"
#include "test_usb_31_link_ts_7_1.hh"
#include "test_usb_31_link_ts_7_18.hh"
#include "test_usb_31_link_ts_7_19.hh"
#include "test_usb_31_link_ts_7_23.hh" 
#include "test_usb_31_link_ts_7_24.hh"
#include "test_usb_31_link_ts_7_25.hh"
#include "test_usb_31_link_ts_7_27.hh"  
#include "test_usb_31_link_ts_7_28.hh"
#include "test_usb_31_link_ts_7_29.hh"
#include "test_usb_31_link_ts_7_35.hh"
#include "test_usb_31_link_ts_7_36.hh"
#include "test_usb_31_link_ts_7_37.hh"
#include "test_usb_31_link_ts_7_41.hh" 
#include "test_bulk_unplug_plug_bulk.hh" 
#include "test_bulk_hs_unplug_plug_bulk_ss.hh" 
#include "test_bulk_hs_unplug_plug_bulk_ssp.hh" 
#include "test_bulk_ss_unplug_plug_bulk_hs.hh" 
#include "test_bulk_connect_disconnect.hh"
#include "test_bulk_protocol_reset.hh"
#include "test_bulk_dynamic_reset.hh"
#include "test_bulk_suspend_resume_via_remote_wakeup.hh" 
#include <string.h>
#include "svt_c_threading.hh"
#include "tb_usb_report.hh"
Board     *board = NULL;

using namespace std;
using namespace ZEBU;
using namespace ZEBU_IP;
using namespace XTOR_USB_SVS;
using namespace ZRCI;

FastWaveformCapture * fwc_wave = NULL;
WaveFile *            dyn_wave = NULL;

XtorScheduler         * xsched;
XtorScheduler         * dev_xsched ;
test_base             * test[NUM_INST];
svt_c_threading       * test_thread[NUM_INST];
svt_c_threading       * host_thread[NUM_INST];
svt_c_threading       * dev_thread[NUM_INST];
tb_usb_report         * report;
svt_c_runtime_cfg     * runtime;
string                  host_inst[NUM_INST];
string                  dev_inst[NUM_INST];
string            test_name;
string            speed;
string            host_debug_str;
string            dev_debug_str;
int                     host_debug;
int                     dev_debug;

//char * host_str = new char [24*1024]; 

void   sig_handler();
void   handler_ctrl_c (int sig) ;

void   start_dyn_waveform();
void   create_schedulers();
void   wait_test_thread_join();
test_base * create_test(const char * test_name) ;



int run_test() {

  printf("HOST_DEBUG %d DEV_DEBUG %d \n", host_debug, dev_debug);
  for ( int i = 0; i < NUM_INST; i++) {
    test_thread[i] = runtime->get_threading_api()->clone();
    struct test_base::invoke_fn fn = {test[i], "test_main"}; 
    test[i]->board = board;
    printf("Calling test[i]->tb_invoke_function test[i] %d %p %p %s \n", NUM_INST, test[i], fn , fn.fn_name);
    test_thread[i]->spawn(test[i]->tb_invoke_function, (void*)(&fn));
  }
  sleep(1);

  sig_handler();
  //start_dyn_waveform();
  return 0;
}

//wait_test_thread_join
//--------------------------------
void wait_test_thread_join () {
  for ( int i = 0; i < NUM_INST; i++) {
    usb_tb_print_inst(report, "Waiting for test_thread[%d] to complete ... ", i);
    fflush(stdout);
    test_thread[i]->join();
    usb_tb_print_inst(report, "Waiting for test_thread[%d] to complete ... unblocked ", i);
    fflush(stdout);
  }

  for ( int i = 0; i < NUM_INST; i++) {
    if ( (test[i]->host->host_err_cnt != 0) || (test[i]->dev->dev_err_cnt != 0) || (test[i]->host->tbDone == 0)) {
      printf(" \n Test Failed FAILED \n");
    }
    else {
      printf("\n Test Passed PASSED \n");
    }
  }
}

//start_fwc_waveform
//----------------------------------
void start_fwc_waveform() {
  fwc_wave = new FastWaveformCapture ;
  printf("Waveforms enables \n");  
  fwc_wave ->initialize (board);
  fwc_wave ->add ("essential_Signals_Value_Set");
  fwc_wave ->dumpFile ("CSA.ztdb");// Starts dump
}

//start_dyn_waveform - This is added just to have a reference and user is expected to create their own .ztdb file and provide the path
//----------------------------------
void start_dyn_waveform() {
//#ifdef DYN_TRACE
//  dyn_wave = new WaveFile(board, "monitor.ztdb", "utf_wrapper.host_xtor_clk");
//  board->loadSelectionDB("<path_to_ztdb i.e. selection.zrdb>");
//  dyn_wave->dumpvars();
//  dyn_wave->dumpon();
//  printf("Enabled waveforms \n");
//#else
//  dyn_wave = NULL;
//#endif
}

//stop_dyn_waveform
//----------------------------------
void stop_dyn_waveform() {
//  printf("Waveforms enables \n");  
//  if (dyn_wave != NULL) {
//    dyn_wave->dumpoff();
//    dyn_wave->close();
//  }
}

//stop_fwc_waveform
//----------------------------------
void stop_fwc_waveform (){
  fwc_wave->closeFile(); // Stops & closes ztdb fwc_wave
  delete fwc_wave;
  fwc_wave = NULL;
}

//host_report_cb
//---------------------------------------------------------------
void host_report_cb(char * str) {
  string s = str;

  if (strstr(s.c_str(), "Request=DEV Type=80 GET_DESCRIPTOR wValue=DEVICE(100) wIndex=0 wLength=8")) {
    printf("************************ \n");
    printf("Got the requested string \n");
    Clock * clk = board->getClock("hw_top.top1.host_xtor_clk") ; 
    printf("%s:%d Clock Counter %llu \n", __FUNCTION__, __LINE__, clk->getCounter());
  }
}

// -----------------------------------------------------------------------
void sig_handler() {
  // set CTRL-C signal handler
  signal (SIGSEGV, &handler_ctrl_c);
  signal (SIGABRT, &handler_ctrl_c);
  signal (SIGTERM, &handler_ctrl_c);
  signal (SIGINT,  &handler_ctrl_c);
  signal (SIGQUIT,  &handler_ctrl_c);
  //signal (SIGUSR1,  &handler_ctrl_c);
}

// -----------------------------------------------------------------------
unsigned char protectHandler = 0;
void handler_ctrl_c (int sig) {
  int ret = 0;
  while (protectHandler != 0) {}
  if (protectHandler == 0) {
    // prevent concurrent redundant call to sig handler
    ++protectHandler;
    cerr << "protectHandler called " << endl;
    switch (sig) {
      case SIGSEGV:
        cerr << "Error happened" << endl;
        ret = -1;
        break;
      case SIGINT :
        cerr << "Test bench interrupted" << endl;
        break;
      case SIGABRT :
        cerr << "Test bench aborted" << endl;
        break;
      case SIGQUIT :
        cerr << "Test bench QUIT " << endl;
        break;
      case SIGTERM :
        cerr << "Test bench terminated" << endl;
        break;
      case SIGUSR1 :
        cerr << "Sigusr1" << endl;
        break;
    }

    if (fwc_wave != NULL) {   
      stop_fwc_waveform();
    }

#ifdef DYN_TRACE    
    stop_dyn_waveform();
#endif    

      fflush(stdout);
    --protectHandler;
    exit(ret);
  }
}

//create_schedulers();
//--------------------------------------------------
void create_schedulers() {
#ifndef SCH        
   xsched = NULL;
   dev_xsched = NULL;
#else
	  xsched = XtorScheduler::get();
	  XtorSchedParams_t * XtorSchedParams = xsched->getDefaultParams();
	  XtorSchedParams->useVcsSimulation   = false;
	  XtorSchedParams->useZemiManager     = true;
	  XtorSchedParams->noParams           = true;
	  XtorSchedParams->zebuInitCb         = NULL;
	  XtorSchedParams->zebuInitCbParams   = NULL; 
	  xsched->configure(XtorSchedParams); 

	  dev_xsched = XtorScheduler::get();
	  XtorSchedParams_t * dev_XtorSchedParams = dev_xsched->getDefaultParams();
	  dev_XtorSchedParams->useVcsSimulation   = false;
	  dev_XtorSchedParams->useZemiManager     = true;
	  dev_XtorSchedParams->noParams           = true;
	  dev_XtorSchedParams->zebuInitCb         = NULL;
	  dev_XtorSchedParams->zebuInitCbParams   = NULL; 
	  dev_xsched->configure(dev_XtorSchedParams); 
#endif        
}

//create_test
//---------------------------------------------------------
test_base * create_test(const char * test_name) {
  test_base * base;
  printf("Test Name = %s \n", test_name);
  if      (strcmp(test_name, "test_bulk") == 0)                base = new test_bulk;
  else if (strcmp(test_name, "test_bulk_cancel_urb") == 0)     base = new test_bulk_cancel_urb;
  else if (strcmp(test_name, "test_bulk_stream") == 0)         base = new test_bulk_stream;
  else if (strcmp(test_name, "test_bulk_dmtcp") == 0)          base = new test_bulk_dmtcp;
  else if (strcmp(test_name, "test_intr") == 0)                base = new test_intr;
  else if (strcmp(test_name, "test_isoc") == 0)                base = new test_isoc;
  else if (strcmp(test_name, "test_bulk_role_switch") == 0)    base = new test_bulk_role_switch;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_1") == 0)  base = new test_usb_31_link_ts_7_1;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_18") == 0) base = new test_usb_31_link_ts_7_18;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_19") == 0) base = new test_usb_31_link_ts_7_19;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_23") == 0) base = new test_usb_31_link_ts_7_23;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_24") == 0) base = new test_usb_31_link_ts_7_24;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_25") == 0) base = new test_usb_31_link_ts_7_25;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_27") == 0) base = new test_usb_31_link_ts_7_27;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_28") == 0) base = new test_usb_31_link_ts_7_28;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_29") == 0) base = new test_usb_31_link_ts_7_29;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_35") == 0) base = new test_usb_31_link_ts_7_35;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_36") == 0) base = new test_usb_31_link_ts_7_36;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_37") == 0) base = new test_usb_31_link_ts_7_37;
  else if (strcmp(test_name, "test_usb_31_link_ts_7_41") == 0) base = new test_usb_31_link_ts_7_41;
  else if (strcmp(test_name, "test_bulk_unplug_plug_bulk") == 0) base = new test_bulk_unplug_plug_bulk;
  else if (strcmp(test_name, "test_bulk_hs_unplug_plug_bulk_ss") == 0) base = new test_bulk_hs_unplug_plug_bulk_ss;
  else if (strcmp(test_name, "test_bulk_hs_unplug_plug_bulk_ssp") == 0) base = new test_bulk_hs_unplug_plug_bulk_ssp;
  else if (strcmp(test_name, "test_bulk_ss_unplug_plug_bulk_hs") == 0) base = new test_bulk_ss_unplug_plug_bulk_hs;
  else if (strcmp(test_name, "test_bulk_connect_disconnect") == 0)  base = new test_bulk_connect_disconnect;
  else if (strcmp(test_name, "test_bulk_protocol_reset") == 0)               base = new test_bulk_protocol_reset;
  else if (strcmp(test_name, "test_bulk_dynamic_reset") == 0)                base = new test_bulk_dynamic_reset;
  else if (strcmp(test_name, "test_bulk_suspend_resume_via_remote_wakeup") == 0) base = new test_bulk_suspend_resume_via_remote_wakeup;
  else {
    printf("INVALID INVALID INVALID TEST CASE");
    exit(1);
  }

  return base;
}

//zRci_pre_board_open
//---------------------------------------------------------
void   * zRci_pre_board_open(const ZRCI::TbOpts& tb0pts) {
  printf("Entered %s:%d \n", __FUNCTION__, __LINE__);
  return NULL;
}

//zRci_post_board_open
//---------------------------------------------------------
void   * zRci_post_board_open(const ZRCI::TbOpts& tb0pts) {
  printf("Entered %s:%d \n", __FUNCTION__, __LINE__);
  board = tb0pts.board;

  runtime       = new svt_c_runtime_cfg();
  svt_pthread_threading *threading = new svt_pthread_threading();
  runtime->set_threading_api(threading);
  runtime->set_platform(new svt_zebu_platform(board, 0));
  svt_c_runtime_cfg::set_default(runtime);

  report = new tb_usb_report("TB_DEBUG");
  return NULL;
}

//zRci_pre_board_init
//---------------------------------------------------------
void * zRci_pre_board_init(const ZRCI::TbOpts& tb0pts) {
  printf("Entered %s:%d \n", __FUNCTION__, __LINE__);
  return NULL;
}

//zRci_post_board_init
//---------------------------------------------------------
void * zRci_post_board_init(const ZRCI::TbOpts& tb0pts) {

  printf("Entered %s:%d \n", __FUNCTION__, __LINE__);
  create_schedulers();
  xtor_usb_svs::Register("xtor_usb_svs");

 #ifdef USE_MONITOR_USB_SVS
  monitor_usb_svs::Register("monitor_usb_svs");
 #endif  

  for ( int i = 0; i < NUM_INST; i++) {
    if (i == 0) {
      host_inst[i] = HOST_INST;
      dev_inst[i] = DEV_INST;
    }
    else {
      host_inst[i] = HOST_INST1;
      dev_inst[i] = DEV_INST1;
    }
//    test[i] = create_test(test_name.c_str());
    test[i] = create_test("test_bulk");
    test[i]->tb_host_create(speed.c_str(), host_debug, host_inst[i].c_str(), i + 1, xsched); 
    test[i]->tb_dev_create(speed.c_str(), dev_debug, dev_inst[i].c_str(), i + 1, dev_xsched); 
  }
  return NULL;
}

//zRci_param
//-----------------------------------------------------
void * zRci_param(const std::string& key, const std::string& value) {
 if (key == "load_values") {
   printf("*************** Load Values %s test %s ********** %d \n",key.c_str(), value.c_str(), value.size()); 
   test_name = "";
   speed = "";
   host_debug_str = "";
   dev_debug_str = "";
   int id = 0;
   //char * temp = new char (value.size()); //value.c_str();
   //value.copy(temp, value.size(), 0);
   std::string cmp = ":";
   size_t start = 0U;
   size_t end = 0;
   printf("%s \n", value.c_str());
   while (end != std::string::npos) {
     size_t end = value.find(cmp, start);
     if (id == 0) 
       test_name = value.substr(start, end - start);
     else if (id == 1) 
       speed = value.substr(start, end - start);
     else if (id == 2) 
       host_debug_str = value.substr(start, end - start);
     else if (id == 3) { 
       dev_debug_str = value.substr(start, end - start);
       break;
     }
     printf("id %d start %d end %d \n", id, start, end);
     start = end + cmp.length();
     //end = value.find(cmp, start);
     id++;
     printf("id %d start %d end %d \n", id, start, end);
   }
//   printf("Test Name %s Speed %s Host_Debug %s Dev_Debug %s \n", test_name.c_str(), speed.c_str(), host_debug_str.c_str(), dev_debug_str.c_str());
   printf("Test Name %s Speed %s Host_Debug %s Dev_Debug %s \n", "test_bulk", speed.c_str(), host_debug_str.c_str(), dev_debug_str.c_str());
   host_debug = atoi(host_debug_str.c_str());
   dev_debug = atoi(dev_debug_str.c_str());
 }
 return NULL; //(void*) key;
}

//zRci_command
//-----------------------------------------------------
std::string zRci_command(const std::string& key, const std::string& value) {
  int res;
  printf("Starting TB %s \n", key.c_str());
  
  if (key == "run_test") {
    printf("*************** START RUNNING %s **********\n",key.c_str()); 
    res=run_test();
    printf("*************** END RUNNING %s test **********\n",key.c_str()); 
  }
  else if (key == "run_post_test") {
  //  for ( int i = 0; i < NUM_INST; i++) {
  //    test_thread[i] = runtime->get_threading_api()->clone();
  //    struct test_base::invoke_fn fn = {test[i], "tb_host_post_run"}; 
  //    struct test_base::invoke_fn fn1 = {test[i], "tb_dev_post_run"}; 
  //    printf("Calling test[i]->tb_invoke_function test[i] %d %p %p %s \n", NUM_INST, test[i], fn , fn.fn_name);
  //    test_thread[i]->spawn(test[i]->tb_invoke_function, (void*)(&fn));
  //    test_thread[i]->spawn(test[i]->tb_invoke_function, (void*)(&fn1));
  //sleep(1);
   // }
  }
  else if (key == "start_fwc_waveform")
    start_fwc_waveform();
  else if (key == "stop_fwc_waveform")
    stop_fwc_waveform();
  else if (key == "start_dyn_waveform")
    start_dyn_waveform();
  else if (key == "stop_dyn_waveform")
    stop_dyn_waveform();
  else if (key == "wait_for_test_end") {
    wait_test_thread_join();
    printf("Test ended\n");
  }

  return key;
}

//zRci_pre_save
//-----------------------------------------------------
void   * zRci_pre_save(const ZRCI::TbOpts& tb0pts) {
	printf("Inside pre_save \n");
 //uint32_t rsl = preCheckPoint(NULL);
	fflush(stdout);
 return NULL;
}

//zRci_post_save
//-----------------------------------------------------
void   * zRci_post_save(const ZRCI::TbOpts& tb0pts) {
	printf("Inside post_save \n");
 //uint32_t rsl = postCheckPoint(NULL, 0);
 return NULL;
}
