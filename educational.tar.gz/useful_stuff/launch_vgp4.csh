#! /bin/csh -f

# Launch VGP4 emulator on ZS5 host
#rems --wait --zebu.work $ZEBU_WORK  -P rt_ZEBU_COMMON_ZS5_MU --timeout=2400 &
#rems --wait --zebu.work $ZEBU_WORK -P rt_ZEBU_ZS5_OS_TESTING  --timeout=4800 &
rems --wait --zebu.work $ZEBU_WORK -P rt_ZEBU_COMMON_ZS5_SU  --timeout=4800 &
#rems --wait --zebu.work $ZEBU_WORK  --timeout=2400 &
