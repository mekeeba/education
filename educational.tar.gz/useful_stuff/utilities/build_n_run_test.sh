#!/bin/sh
#--------------------------------------------------------------------
# ChipName : Omni
#--------------------------------------------------------------------
# $Rev: 1 $
#--------------------------------------------------------------------
# Copyright(C) 2022 Socionext Inc. All Rights Reserved.
#--------------------------------------------------------------------

echo "### START `basename $0` ###"

# set environment variables
scr_path=`dirname $0`
cd ${scr_path}/../..
VERIF_ENV=`pwd`
VERIF_ENV_CHIP="${VERIF_ENV}/verif_top"
DIR_RTL_ROOT=`dirname ${VERIF_ENV}`
DIR_GIT=${VERIF_ENV}/zebu
VERIF_ENV_ZEBU="${VERIF_ENV}/zebu/verif_zebu"
UPF_DIR=""
SETUP_LIB_SH="setup_lib.sh"
SIMULATOR="VCS"

export set_tool="SYNOPSYS"

export VERIF_ENV
export VERIF_ENV_CHIP
export DIR_RTL_ROOT
export DIR_GIT
export VERIF_ENV_ZEBU
export UPF_DIR
export SIMULATOR

# initialize options
run_env="sim"
dcomp_en=0
build_en=0
build_only_en=0
dcomp_dir_name=""
exe_en=0
sc_dir_name=""
env_name=""
upf_en=0
wave_en=0
timeout="default"
scr_comment=""
scr_run_command="scr_vcs_run"
scr_mode=""
scr_tool=""
cov=0
src_dir_name=""
cov_noassert=0
ts_dir=""
sim_dir_name=""
sim_dir_name_ts=1
disable_sim_ast=1
disable_sim_cov=1
gls_en=0
gls_sdf_en=0
xprop_en=0
gls_sdf_case=0
pmem_num=25
exe_name=""
hunter_boot_rom_name="hunter_boot_ROM"
hunter_boot_rom_ch="ch0"

list_target_cpu="SI_Fuji-AE RT_Fuji-AE CS_Hunter-AE"
list_common_code_dir="driver utility memory_map"
chiplet_en=0
num_of_chiplet=0
DIR_CHIPLET=""


# UVM TESTNAME definition
#   Default setting is to use below sequece
#      testbench/uvm_scenario/default/user_scenario.sv
#uvm_testname="testNop"
uvm_testname=""

memdata_list=""  # Set file name automardally under simdata/mem/*

# check options
while [ "$1" != "" ] ; do
  case "$1" in
    -c)
      dcomp_en=1
      shift 1
      ;;
    -cm)
      cov=1
      disable_sim_ast=0
      disable_sim_cov=0
      shift 1
      ;;
    -b)
      build_en=1
      shift 1
      ;;
    -bo)
      build_en=1
      if [ -n "$2" ] ; then
        sc_dir_name=`echo $2 | sed -e 's/\/\+$//'`
        ts_dir=`date "+%m%d_%H%M%S"`
        #sim_dir_name=${sc_dir_name}_${ts_dir}
        sim_dir_name_ts=0
        shift 2
      else
        echo "Error: You have to set testcase name"
        exit 1
      fi
      ;;
    -e)
      if [ -n "$2" ] ; then
        env_name="$2"
        shift  2
      else
        echo "Error: You have to set environment name"
        exit 1
      fi
      ;;
    -uvm_testname)
      if [ -n "$2" ] ; then
        uvm_testname="$2"
        shift  2
      else
        echo "Error: You have to set UVM_TESTNAME by -uvm_ttestname <UVM_TESTNAME> "
        exit 1
      fi
      ;;
    -s)
      exe_en=1
      if [ -n "$2" ] ; then
        sc_dir_name=`echo $2 | sed -e 's/\/\+$//'`
        ts_dir=`date "+%m%d_%H%M%S"`
        #sim_dir_name=${sc_dir_name}_${ts_dir}
        shift 2
      else
        echo "Error: You have to set testcase name"
        exit 1
      fi
      ;;
    -w)
      wave_en=1
      shift 1
      ;;
    -t)
      if [ -n "$2" ] ; then
        timeout="$2"
        shift 2
      else
        echo "Error: You have to set max run time"
        exit 1
      fi
      ;;
    -cov_noassert)
      cov_noassert=1
      shift 1
      ;;
    -n_ts)
      sim_dir_name_ts=0
      shift 1
      ;;
    -on_ast)
      disable_sim_ast=0
      shift 1
      ;;
    -on_cov)
      disable_sim_cov=0
      shift 1
      ;;
    -gls)
      gls_en=1
      shift 1
      ;;
    -gls_sdf)
      gls_sdf_en=1
      gls_en=1
      if [ -n "$2" ] ; then
        if [ "-best" = "$2" ] ; then
          gls_sdf_case=1
          shift  2
        elif [ "-worst" = "$2" ] ; then
          gls_sdf_case=2
          shift  2
        else
          echo "Error: $2 not support PVT case name. Need to set -best or -worst."
          exit 1
        fi
      else
        echo "Error: Need to set -best or -worst. If you use -gls_sdf option."
        exit 1
      fi
      ;;
    -xprop)
      xprop_en=1
      shift 1
      ;;
    -exe_name)
      if [ -n "$2" ] ; then
        exe_name="$2"
        shift 2
      else
        echo "Error: You have to set execution directory name"
        exit 1
      fi
      ;;
    -chiplet)
      chiplet_en=1
      shift 1
      ;;
    *)
      echo "Error: Unkown argument \"$1\""
      exit 1
      ;;
  esac
done

if [ "${sim_dir_name_ts}" = "0" ] ; then
  if [ "${gls_sdf_case}" = "1" ] ; then
    sim_dir_name=${sc_dir_name}_best
  elif [ "${gls_sdf_case}" = "2" ] ; then
    sim_dir_name=${sc_dir_name}_worst
  elif [ -n "${exe_name}" ] ; then
    sim_dir_name=${exe_name}
  else
    sim_dir_name=${sc_dir_name}
  fi
else
  if [ "${gls_sdf_case}" = "1" ] ; then
    sim_dir_name=${sc_dir_name}_best_${ts_dir}
  elif [ "${gls_sdf_case}" = "2" ] ; then
    sim_dir_name=${sc_dir_name}_worst_${ts_dir}
  elif [ -n "${exe_name}" ] ; then
    sim_dir_name=${exe_name}_${ts_dir}
  else
    sim_dir_name=${sc_dir_name}_${ts_dir}
  fi
fi

# source setup files
. ${VERIF_ENV_CHIP}/bin/setup/setup_general_env_variable.sh
#. ${VERIF_ENV_CHIP}/bin/setup/setup_ies.sh
. ${VERIF_ENV_CHIP}/bin/setup/${SETUP_LIB_SH}

. ${VERIF_ENV_CHIP}/bin/setup/setup_vcs.sh
. ${VERIF_ENV_CHIP}/bin/setup/setup_verdi.sh

#. ${VERIF_ENV_CHIP}/bin/setup/setup_vip.sh
#. ${VERIF_ENV_CHIP}/bin/setup/setup_denali.sh

#. ${VERIF_ENV_CHIP}/bin/setup/setup_zebu.sh
. ${VERIF_ENV_CHIP}/bin/setup/setup_dsm.sh

export sc_dir="${VERIF_ENV_CHIP}/testcase/${sc_dir_name}"
echo $sc_dir
if [ "${dcomp_en}" != "1" -o  ! "${exe_en}" != "1" ] ; then
  if [ ! -d ${sc_dir} ] ; then
    echo "Error: Not found such Scnenario   \"${sc_dir_name}\""
    exit 1
  fi
fi

category=`echo ${sc_dir_name} | cut -d"/" -f1`
sc_common_dir="${VERIF_ENV_CHIP}/testcase/${category}/common"

if [ "${env_name}" = "" ] ; then
  if [ -f ${VERIF_ENV_CHIP}/testcase/common/simdata/etc/e.txt ] ; then
    env_name=`cat ${VERIF_ENV_CHIP}/testcase/common/simdata/etc/e.txt`
  fi
  if [ -f ${sc_common_dir}/simdata/etc/e.txt ] ; then
    env_name=`cat ${sc_common_dir}/simdata/etc/e.txt`
  fi
  if [ -f ${sc_dir}/simdata/etc/e.txt ] ; then
    env_name=`cat ${sc_dir}/simdata/etc/e.txt`
  fi
  if [ "${env_name}" = "" ] ; then
    echo "Error: Not set environment name"
    exit 1
  fi
fi

. ${VERIF_ENV_CHIP}/bin/setup/setup_snps_vip.sh

# Set chiplet enable
if [[ ${env_name} == chiplet* ]]; then
    chiplet_en=1
    num_of_chiplet=1
    DIR_CHIPLET="chiplet"
else
    chiplet_en=0
    num_of_chiplet=0
    DIR_CHIPLET=""
fi
if [ $build_en -eq 1 ] ; then
  if [ -e ${VERIF_ENV_CHIP}/testcase/${sc_dir_name}/chiplet0 ] ;  then
    chiplet_en=1
    num_of_chiplet=1
    DIR_CHIPLET="chiplet"
  fi
fi
if [ $exe_en -eq 1 ] ; then
  if [ -e ${VERIF_ENV_CHIP}/testcase/${sc_dir_name}/chiplet0 ] ;  then
    chiplet_en=1
    num_of_chiplet=1
    DIR_CHIPLET="chiplet"
  fi
fi
export chiplet_en
export num_of_chiplet
export DIR_CHIPLET

if [ "${upf_en}" = "0" ] ; then
  if [ -f ${VERIF_ENV_CHIP}/testcase/common/simdata/etc/u.txt ] ; then
    upf_en=1
  fi
  if [ -f ${sc_common_dir}/simdata/etc/u.txt ] ; then
    upf_en=1
  fi
  if [ -f ${sc_dir}/simdata/etc/u.txt ] ; then
    upf_en=1
  fi
  if [ -e ${VERIF_ENV_CHIP}/testbench/top/filelist/${env_name}/enb_upf ] ; then
    upf_en=1
  fi
fi

UPF_DIR="${VERIF_ENV}/design/design/upf"



if [ "${dcomp_dir_name}" = "" ] ; then
  if [ "${gls_sdf_case}" = "1" ] ; then
    dcomp_dir_name="${env_name}.best"
  elif [ "${gls_sdf_case}" = "2" ] ; then
    dcomp_dir_name="${env_name}.worst"
  else
    dcomp_dir_name="${env_name}"
  fi
fi

. ${VERIF_ENV_CHIP}/bin/run_exe/make_vcs_filelist.sh

if [ $? != 0 ]; then
    echo "make_vcs_filelist.sh is failed"
    exit 1
fi

# option of rsync
rsync_option="-Ltrc --exclude=.svn"

# make work directory
if [ "${SIMULATOR}" = "IES" ] ; then
  work_dir="${VERIF_ENV_CHIP}/run/work_ies"
elif [ "${upf_en}" = "1" ] ; then
  if [ -z ${eman_session_name} ] ; then
    work_dir="${VERIF_ENV_CHIP}/run/work_upf"
  else
    work_dir="${VERIF_ENV_CHIP}/run/work"
  fi
else
  work_dir="${VERIF_ENV_CHIP}/run/work"
fi
if [ ! -d ${work_dir} ] ; then
  mkdir -p ${work_dir}
fi

if [ -z ${eman_session_name} ] ; then
  dcomp_dir="${work_dir}/compile/${dcomp_dir_name}"
else
  dcomp_dir="${work_dir}/${eman_session_name}/compile/${dcomp_dir_name}"
fi
export dcomp_dir


if [ "${gls_en}" = "1" ] ; then
      pmem_num=250
fi

if [ "${SIMULATOR}" = "IES" ] ; then
  dcomp_scr="${VERIF_ENV_CHIP}/bin/run_exe/dcomp_sim_ies.sh"
  exe_scr="${VERIF_ENV_CHIP}/bin/run_exe/exe_sim_ies.sh"
else
  dcomp_scr="${VERIF_ENV_CHIP}/bin/run_exe/dcomp_sim.sh"
  exe_scr="${VERIF_ENV_CHIP}/bin/run_exe/exe_sim.sh"
fi

dcomp_go="${dcomp_scr}"
exe_go="${exe_scr}"

build_scr="${VERIF_ENV_CHIP}/bin/run_exe/build.sh"

if [ -z ${eman_session_name} ] ; then
  build_dir="${work_dir}/${sim_dir_name}"
else
  build_dir="${work_dir}/${eman_session_name}/${sim_dir_name}"
fi
exe_dir="${build_dir}"

build_go="${build_scr}"
export build_dir

unset dcomp_jobid
unset build_jobid
unset exe_jobid
unset swfsdb_jobid

# output messages
echo "############### RUN INFORMATION ##################"
if [ "${SIMULATOR}" = "IES" ] ; then
  echo "Info: Simulator name      : ies"
else
  echo "Info: Simulator name      : vcs"
fi
if [ "${dcomp_en}" = "1" -o  "${exe_en}" = "1" ] ; then
  echo "Info: Envioronment name   : ${env_name}"
fi
echo "Info: Compile             : ${dcomp_en} ( 0: off   1: on )"
if [ "${dcomp_en}" = "1" -o  "${exe_en}" = "1" ] ; then
  echo "Info: Compile directory   : ${dcomp_dir}"
fi
echo "Info: Build               : ${build_en} ( 0: off   1: on )"
echo "Info: Execute             : ${exe_en} ( 0: off   1: on )"
if [ "${exe_en}" = "1" ] ; then
  echo "Info: Execute scenario    : ${sc_dir_name}"
  echo "Info: Execute directory   : ${exe_dir}"
fi
echo "Info: UPF                 : ${upf_en} ( 0: off   1: on )"
echo "Info: GLS                 : ${gls_en} ( 0: off   1: on )"
echo "Info: GLS_SDF             : ${gls_sdf_en} ( 0: off   1: on )"
echo "##################################################"


# export upf, tic, xprop info
export upf_en

# export makefile_name
export makefile_name

# export coverage option
export cov_noassert

# export enable/disable -assert,-cm option
export disable_sim_ast
export disable_sim_cov

# export verifienv nam for elaboration,simulateion
export env_name

export gls_en
export gls_sdf_en
export xprop_en
export gls_sdf_case

# export for UVM_TESTNAME
export uvm_testname

export chiplet_en
export num_of_chiplet
export list_target_cpu
export list_common_code_dir
# compile simulation environment
if [ ${dcomp_en} -eq 1 ] ; then

  if [ ! -d ${dcomp_dir} ] ; then
    mkdir -p ${dcomp_dir}
  fi
  # Dump compile design revision
  cd ${VERIF_ENV_CHIP}/../design/

  if [ -n "`type git 2>/dev/null`" ] ; then
    compiled_design=`git log --pretty=%H | head -n 1`
  else
    compiled_design='check_git_hash_is_disable'
  fi
  cd ${VERIF_ENV_CHIP}

  . ${VERIF_ENV_CHIP}/bin/run_exe/comp_pre_pj.sh

  cd ${dcomp_dir}

  echo "${compiled_design}" > current_design
  touch git.d.${compiled_design}

  echo "${env_name}" > e.txt
  rm -f bsub_dcomp_*.log

  cp ${VERIF_ENV_CHIP}/testbench/top/filelist/${env_name}/synopsys_sim.setup .

  eval "${dcomp_go}"

  cd ${VERIF_ENV_CHIP}
fi

# build scenario
if [ ${build_en} -eq 1 ] ; then
  export sc_dir_name

  mkdir -p ${build_dir}
  cd ${build_dir}

  if [ -n "`type git 2>/dev/null`" ] ; then
    hash_verif=`git log --pretty=%H | head -n 1`
  else
    compiled_design='check_git_hash_is_disable'
  fi

  touch git.v.${hash_verif}

  rm -f bsub_build_*.log
  src_dir_list=`ls ${sc_dir}`
  echo "sc_dir:${sc_dir}"
  echo ${build_go}
  pwd
  if [ "${src_dir_list}" != "" ] ; then
    . ${VERIF_ENV_CHIP}/bin/run_exe/build_pre_pj.sh
  fi

  cur_chiplet=""
  for chiplet in  `seq 0 $num_of_chiplet`
  do
    if [ $chiplet_en -eq 1 ] ; then
      cur_chiplet=$chiplet
    fi
    # Build testcase each target CPU
    for target_cpu in $list_target_cpu
    do
      if [ -e ${build_dir}/testcase/$DIR_CHIPLET$cur_chiplet/${target_cpu} ] ; then
        cd ${build_dir}/testcase/$DIR_CHIPLET$cur_chiplet/${target_cpu}
        eval "${build_go}"

        # Link Pre-load data (ROM data) to simv hierarchy directory
        cd ${build_dir}
      fi
    done

    # Build dummy_rom
    if [ -e ${build_dir}/dummy_rom/$DIR_CHIPLET$cur_chiplet/SI_Fuji-AE ] ; then
      cd ${build_dir}/dummy_rom/$DIR_CHIPLET$cur_chiplet/SI_Fuji-AE
      eval "${build_go}"

      # Link Pre-load data (ROM data) to simv hierarchy directory
      cd ${build_dir}
    fi
  done

 . ${VERIF_ENV_CHIP}/bin/run_exe/build_post_pj.sh

  cd ${VERIF_ENV_CHIP}
fi

# execute simulation
if [ ${exe_en} -eq 1 ] ; then
  . ${VERIF_ENV_CHIP}/bin/run_exe/exe_pre_pj.sh
  # check compile directory
  if [ ! -d ${dcomp_dir} ] ;then
    echo "Error: Not found compile directory  \"${dcomp_dir}\""
    exit 1
  fi

  current_design=`cat ${dcomp_dir}/current_design`
  echo "Info : This simulation runs under the following design revision."
  echo "     : YOUR   Design : ${current_design}"
  sleep 3s

  # collect datas to be used
  mkdir -p ${exe_dir}
  cd ${exe_dir}
  echo "${env_name}" > e.txt
#  export env_name
  export cov

  if [ "${SIMULATOR}" = "IES" ] ; then
    if [ -e INCA_libs ] ; then
      rm INCA_libs
    fi
    ln -fs ${dcomp_dir}/INCA_libs .
  else
    if [ -e simv ] ; then
      rm simv
    fi
    if [ -e simv.daidir ] ; then
      rm simv.daidir
    fi
    if [ -e simv.vdb ] ; then
      rm simv.vdb
    fi
    ln -fs ${dcomp_dir}/simv .
    ln -fs ${dcomp_dir}/simv.daidir .
  fi

  if [ -e rc ] ; then
    rm rc
  fi

  # copy simdata
  # 1. scenario/common/simdata
  # 2. scenario/category_name/common/simdata
  # 3. scenario/category_name/testcase_name/common/simdata
  dir_tmp="${VERIF_ENV_CHIP}/testcase"
  for dir in `echo ${sc_dir_name} | sed 's/\// /g'` ; do
    if [ -d ${dir_tmp}/common/simdata ] ; then
      if [ "`ls ${dir_tmp}/common/simdata`" != "" ] ; then
         cp -rfL ${dir_tmp}/common/simdata .
      fi
    fi
    dir_tmp=${dir_tmp}/${dir}
  done

  if [ -e ${sc_dir}/simdata ] ; then
    cp -rfL ${sc_dir}/simdata .
  fi

  if [ -f "${build_dir}/simdata/link/exp_data.list" ] ; then
    while read line ; do
      if [ ! "`eval echo ${line}`" == ""  ] ; then
        tmp0=(`eval echo ${line}`)
        if [ -f "${tmp0[0]}" -o -d "${tmp0[0]}" ] ; then
          if [ ${#tmp0[@]} -eq 1 ] ; then
            ln -fs ${tmp0[0]} ${build_dir}/simdata/exp_data
          elif [ ${#tmp0[@]} -eq 2 ] ; then
            ln -fs ${tmp0[0]} ${tmp0[1]}
          else
            echo "WARNING: not make link file   link.list \"${line}\""
          fi
        else
          echo "WARNING: not make link file   link.list \"${line}\""
        fi
      fi
    done < ${build_dir}/simdata/link/exp_data.list
  fi
  if [ -f "${build_dir}/simdata/link/mem.list" ] ; then
    while read line ; do
      if [ ! "`eval echo ${line}`" == ""  ] ; then
        tmp0=(`eval echo ${line}`)
        if [ -f "${tmp0[0]}" -o -d "${tmp0[0]}" ] ; then
          if [ ${#tmp0[@]} -eq 1 ] ; then
            ln -fs ${tmp0[0]} ${build_dir}/simdata/mem
          elif [ ${#tmp0[@]} -eq 2 ] ; then
            ln -fs ${tmp0[0]} ${tmp0[1]}
          else
            echo "WARNING: not make link file   link.list \"${line}\""
          fi
        else
          echo "WARNING: not make link file   link.list \"${line}\""
        fi
      fi
    done < ${build_dir}/simdata/link/mem.list
  fi

  # settings to wait for build and compile
  wait_sel=""

  # set timeout
  if [ "${timeout}" = "default"  ] ; then
    if [ -f ./simdata/etc/t.txt ] ; then
      timeout=`cat ./simdata/etc/t.txt`
    fi
  fi

  # Setting power aware sim enable
  if [ "${upf_en}" = "1" ] ; then
    rm -rf ${build_dir}/enb_upf
    touch ${build_dir}/enb_upf
  fi

  # Setting GLS sim enable
  if [ "${gls_en}" = "1" ] ; then
    rm -rf ${build_dir}/enb_gls
    touch ${build_dir}/enb_gls
  fi
  if [ "${gls_sdf_en}" = "1" ] ; then
    rm -rf ${build_dir}/enb_gls
    touch ${build_dir}/enb_gls
    rm -rf ${build_dir}/enb_gls_sdf
    touch ${build_dir}/enb_gls_sdf
  fi

  # Setting chiplet enable
  if [ "${chiplet_en}" = "1" ] ; then
    rm -rf ${build_dir}/chiplet_en
    touch ${build_dir}/chiplet_en
  fi

  # export environment variables
  TIMEOUT="${timeout}"
  export TIMEOUT
  if [ ${wave_en} -eq 1 ] ; then
    WAVE_DUMP_ON="1"
    export WAVE_DUMP_ON
  fi
#  SCENARIO="${sc_dir_name}"
  SCENARIO="${sim_dir_name}"
  export SCENARIO

  # submit simulation job
  exe_bsub=""
  exe_bsub="${exe_bsub} ${exe_go} "

  echo "DBG0:${exe_bsub}"
  rm -f bsub_exe_*.log

  # Check testcase build result, If there are any error simlation will stop.

  cur_chiplet=""
  for chiplet in  `seq 0 $num_of_chiplet`
  do
    if [ $chiplet_en -eq 1 ] ; then
      cur_chiplet=$chiplet
    fi
    if [ -e ${build_dir}/testcase/$DIR_CHIPLET$cur_chiplet/CS_Hunter-AE ]; then
      ddr_model="Denali"
      if [ -f ${build_dir}/simdata/etc/d.txt ] ; then
        d_txt=`cat ${build_dir}/simdata/etc/d.txt`
        if [ "${d_txt,,}" = "micron" ] ; then
          ddr_model="Micron"
        elif [ "${d_txt,,}" != "denali" ] ; then
          echo "Error: DDR preload format if etc/d.txt is unknown.  See \"${sc_dir_name}\""
          exit 1
        fi
      fi
      if [ ! -d ${build_dir}/simdata/mem ] ; then
        mkdir -p ${build_dir}/simdata/mem
      fi
    
      if [ $chiplet_en -eq 0 ] ; then
        python3  ${VERIF_ENV_CHIP}/testcase/common/utility/DDR_loader_dumper/DDR_loader_axi2dev.py ${build_dir}/testcase/$DIR_CHIPLET$cur_chiplet/CS_Hunter-AE/boot_pre_ddr_512b.hex ${build_dir}/simdata/mem/${hunter_boot_rom_name} ${hunter_boot_rom_ch} ${ddr_model}
        if [ ! -e ${build_dir}/simdata/mem/${hunter_boot_rom_name}.rank0_dev0.dat ] ||
          [ ! -e ${build_dir}/simdata/mem/${hunter_boot_rom_name}.rank0_dev1.dat ] ||
          [ ! -e ${build_dir}/simdata/mem/${hunter_boot_rom_name}.rank1_dev0.dat ] ||
          [ ! -e ${build_dir}/simdata/mem/${hunter_boot_rom_name}.rank1_dev1.dat ] ; then
          echo "Error: Generating DDR preload data for Hunter-AE boot ROM failed. See \"${sc_dir_name}\""
          exit 1
        fi
      else
        for chiplet in  `seq 0 $num_of_chiplet` ; do
          python3  ${VERIF_ENV_CHIP}/testcase/common/utility/DDR_loader_dumper/DDR_loader_axi2dev.py ${build_dir}/testcase/$DIR_CHIPLET$cur_chiplet/CS_Hunter-AE/boot_pre_ddr_512b.hex ${build_dir}/simdata/mem/$hunter_boot_rom_name_chiplet$chiplet ${hunter_boot_rom_ch} ${ddr_model}
          if [ ! -e ${build_dir}/simdata/mem/$hunter_boot_rom_name_chiplet$chiplet.rank0_dev0.dat ] ||
            [ ! -e ${build_dir}/simdata/mem/$hunter_boot_rom_name_chiplet$chiplet.rank0_dev1.dat ] ||
            [ ! -e ${build_dir}/simdata/mem/$hunter_boot_rom_name_chiplet$chiplet.rank1_dev0.dat ] ||
            [ ! -e ${build_dir}/simdata/mem/$hunter_boot_rom_name_chiplet$chiplet.rank1_dev1.dat ] ; then
            echo "Error: Generating DDR preload data for chiplet$chiplet Hunter-AE boot ROM failed. See \"${sc_dir_name}\""
            exit 1
          fi
        done
      fi
    fi
  done

  eval "${exe_go}"

  cd ${VERIF_ENV_CHIP}
fi

echo "### END `basename $0` ###"
exit 0
