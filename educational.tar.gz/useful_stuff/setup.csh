#! /bin/csh -f

#############################################################################
# Copyright 1996-2020 Synopsys, Inc.                                        #
#                                                                           #
# This Synopsys software and all associated documentation are proprietary   #
# to Synopsys, Inc. and may only be used pursuant to the terms and          #
# conditions of a written license agreement with Synopsys, Inc.             #
# All other use, reproduction, modification, or distribution of the         #
# Synopsys software or the associated documentation is strictly prohibited. #
#############################################################################

# Please customize the script below for your environment. 
# When there are multiple setup mechanisms, these are prefixed with '##' to not
# create confusion.

if ("$0" =~ "*setup*.csh") then
     echo "Please source '$0' instead of calling it directly"
     exit 1
endif

# TOP LEVEL Settings and aliases. Will not override user ones
setenv VDK_TOP `pwd`
alias myvdk   'cd $VDK_TOP'

source /remote/sge/default/zebutrain/common/settings.csh

# set ZEBU 
module use -a /tmp
module unload zebu

# 2021.09-2 Official
module unload zebu
#module load zebu/2021.09-2
source /u/product/patches/ZEBU/VCS2021.09.2.ZEBU.B4/19062024/INSTALL/ZEBU/zebu/S-2021.09-2-TZ-20240604_Full64/zebu_env.csh

setenv ZEBU_IP_ROOT /remote/vginterfaces1/zebu_ip/ZebuIpRoot_S-2023.03-SP1/

# using some DW IPs to adding:
module load syn

################
# PA Virtualizer
################
# Please change to the correct Virtualizer installation
module unload pa_virtualizer
module load pa_virtualizer/2023.03-2
source ${SNPS_VP_HOME}/setup.csh -vauth

# Hybrid extra settings:
# (Avoid issue when Zebu is killing some virtulizer threads)
setenv ZEBU_DONT_CANCEL_THREADS OK

## If the platform has many threads and there is a core dump, it only show a limited number of threads, this remove the limit.
#setenv SNPS_GDB_SC_THREAD_COUNT_LIMIT -1

# Enabling a few new LCA features:
setenv SNPS_VS_INTERRUPT_VISUALIZATION_LCA 

#################
#   ZHAL
#################

# 2023 SP1 Official
source /remote/vginterfaces1/zebu_hybridadaptor/officials/ZeBuHybridAdaptor_U-2023.03-SP1/zhal_env.csh

#################
# ZeBu Runtime
#################

# Set the ZEBU design directory
# No need to change
setenv ZEBU_DESIGN_DIR ${VDK_TOP}/zebu
setenv ZEBU_WORK $ZEBU_DESIGN_DIR/zebu.work

# Licensing
# Please change to the correct license servers (ARM, Virtualizer, ZeBu)
## for US: 
source /u/regress/INFRA_HOME/bin/zLicense.csh
setenv LM_LICENSE_FILE ${LM_LICENSE_FILE}:27090@eagle:27000@de02slslic1:26585@de02snpslmd1:26585@de02snpslmd2:27090@de02slslic1
# For Japan:
#setenv SNPSLMD_LICENSE_FILE ${LM_LICENSE_FILE}:26585@jp01snpslmd1:26585@jp01snpslmd2:26585@us01snpslmd5:7183@us01_vglic4
setenv SNPSLMD_LICENSE_FILE ${LM_LICENSE_FILE}

# ------- No changes needed beyond this point ---------------------------------------

# Update LD_LIBRARY_PATH to load all related dynamic libraries
# No need to change
setenv LD_LIBRARY_PATH ${ZEBU_IP_ROOT}/lib64:$ZEBU_ADAPTOR_PATH/lib64:.:${LD_LIBRARY_PATH}

# For 2020.03 need new version of Python - JM do not need this.
#setenv LD_LIBRARY_PATH $ZEBU_ROOT/cmlp/etc/python36_cmlp1/lib:$LD_LIBRARY_PATH
#setenv LD_LIBRARY_PATH $ZEBU_ROOT/cmlp/etc/python36_cmlp1/lib/python3.6/site-packages/cll:$LD_LIBRARY_PATH

# Env Variable to load the software image
# No need to change
setenv SNPS_HYBRID_PLATFORMTEST_FILE ${VDK_TOP}/software/PlatformTest/Debug/PlatformTest.elf
setenv T32SYS /u/ccmaster/coware/3rdparty/tools/lauterbach/T32

# Added to debug runtime
setenv ZEBU_ACE_SLAVE_TRACE 0
setenv ZEBU_AXI_MASTER_TRACE 0
setenv ZEBU_ALLOW_MULTI_LOAD 1

setenv ZEBU_DEBUG_STACK_USE_DL OK
setenv ZEBU_DEBUG_STACK_USE_GDB OK 
setenv ZEBU_DEBUG_STACK_USE_PSTACK OK

# VDK if we want to use blocking runfor command in TCL/PY callback then we have to set this env variable
setenv SNPS_VPX_LENIENT_CALLBACKS

# Directory for EDUT3 Linux Images.
#setenv IMAGE_PATH $VDK_TOP/images-2022-03-16
setenv IMAGE_PATH $VDK_TOP/images-v6.6.br_kernel

# root path directory for virtio mount
setenv VDK_VIRTIO_ROOT_PATH $VDK_TOP

#For Regressions
setenv SNPS_VPX_START_SIMULATION_TIMEOUT 600

setenv SNPS_VPSESSION_LAUNCH_TIMEOUT_SEC 600

#Setup DDR Interleaving
setenv VDK_INTERLEAVE_DDR false
#setenv VDK_INTERLEAVE_DDR true 
#setenv VDK_DDR_INTERLEAVE_NUM_BYTES 256
#setenv VDK_DDR_INTERLEAVE_NUM_BYTES 1024
#setenv VDK_DDR_INTERLEAVE_NUM_BYTES 4096

# Need to set for DMTCP
#setenv SNPS_CR_ENABLE 1


setenv VDK_INSTALL_PATH $VDK_TOP

# Disable Default Memory preloading
setenv ZEBU_DISABLE_DEFAULT_MEMORY_INIT_FILE YES

module load gcc/9.2.0
