#! /bin/csh -f 

# Basic command and command line arguments quick access.

#zRci --do $SCRIPT_DIR/zRci_R0.tcl | tee -i run.log
#zRci --do $SCRIPT_DIR/zRci_R0.tcl -- qiwc_dump | tee -i run.log
#zRci --do $SCRIPT_DIR/zRci_R0.tcl -- tarmac_enable | tee -i run.log
zRci --do $SCRIPT_DIR/zRci_R0.tcl -- qiwc_dump -- tarmac_enable | tee -i run.log
