#--------------------------------------------------------------------
# 
#--------------------------------------------------------------------

# phase_configure pre hook
if { [ file exists ${TCL_PATH}/phase_configure_pre.tcl ] } {
  puts "phase_configure pre hook"
  source ${TCL_PATH}/phase_configure_pre.tcl
}

# phase_configure post hook
if { [ file exists ${TCL_PATH}/phase_configure_post.tcl ] } {
  puts "phase_configure post hook"
  source ${TCL_PATH}/phase_configure_post.tcl
}
