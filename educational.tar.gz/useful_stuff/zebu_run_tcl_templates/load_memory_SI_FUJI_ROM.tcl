#--------------------------------------------------------------------
#--------------------------------------------------------------------
# Memory loading files
#--------------------------------------------------------------------
# RAM/ROM file path
#     set MEM_PATH simdata/mem

# Wait until stable
run 10ns


set file_chiplet "chiplet_en"
if { [file exists $file_chiplet ] ==1 } {
  set file "../testcase/${TEST_CASE}/dummy_rom/chiplet0/SI_Fuji-AE/rom_si_A.dat";
  if { [file exists $file ] ==1 } {
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uINTROM.uROM.U_SNIROMT001N16384W064B16CNSS001001SICRCROM01.u_ram_core.memory";
    memory -load $memory -file $file -radix hexa;;
  }
  if { [file exists $file ] ==1 } {
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uINTROM.uROM.U_SNIROMT001N16384W064B16CNSS001001SICRCROM01.u_ram_core.memory";
    memory -load $memory -file $file -radix hexa;;
  }

} else {
  set file "../testcase/${TEST_CASE}/dummy_rom/SI_Fuji-AE/rom_si_A.dat";
  if { [file exists $file ] ==1 } {
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uINTROM.uROM.U_SNIROMT001N16384W064B16CNSS001001SICRCROM01.u_ram_core.memory";
    memory -load $memory -file $file -radix hexa;;
  }
}


run 1ns
