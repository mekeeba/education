#--------------------------------------------------------------------
# For Backannotation sim (SDF gatelevel sim)
#--------------------------------------------------------------------


#  tcheck {TBENCH.XYZ.GEN_meta_reg_0_} RECREM -msg -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_0_} RECREM -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_0_} SETUPHOLD -msg -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_0_} SETUPHOLD -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_0_} RECREM -msg -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_0_} RECREM -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_0_} SETUPHOLD -msg -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_0_} SETUPHOLD -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_1_} RECREM -msg -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_1_} RECREM -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_1_} SETUPHOLD -msg -disable
#  tcheck {TBENCH.XYZ.GEN_meta_reg_1_} SETUPHOLD -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_1_} RECREM -msg -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_1_} RECREM -xgen -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_1_} SETUPHOLD -msg -disable
#  tcheck {TBENCH.XYZ.GEN_syncl_reg_1_} SETUPHOLD -xgen -disable
