#--------------------------------------------------------------------
# Memory loading files
#--------------------------------------------------------------------
# RAM/ROM file path
#     set MEM_PATH simdata/mem

#run -rising TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.auto_init_comp
#puts "\[TCL\]\[SI\]preload sp time=[senv time]"

set file "chiplet_en"
if { [file exists $file ] ==1 } {
  set num_of_chiplet 2
} else {
  set num_of_chiplet 1
}


set num_chiplet 0
while {$num_chiplet < $num_of_chiplet } {
  set num_wsram 0
  while {$num_wsram < 12} {
  
    if { [file exists $file ] ==1 } {
      set file_a_u "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_A_${num_wsram}U";
      set file_b_u "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_B_${num_wsram}U";
      set file_c_u "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_C_${num_wsram}U";
      set file_d_u "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_D_${num_wsram}U"; 
      set file_a_l "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_A_${num_wsram}L";
      set file_b_l "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_B_${num_wsram}L";
      set file_c_l "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_C_${num_wsram}L";
      set file_d_l "../testcase/${TEST_CASE}/chiplet${num_chiplet}/SI_Fuji-AE/ocm_si_fuji_D_${num_wsram}L"; 
    } else {
      set file_a_u "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_A_${num_wsram}U";
      set file_a_l "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_A_${num_wsram}L";
      set file_b_u "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_B_${num_wsram}U";
      set file_b_l "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_B_${num_wsram}L";
      set file_c_u "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_C_${num_wsram}U";
      set file_c_l "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_C_${num_wsram}L";
      set file_d_u "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_D_${num_wsram}U";
      set file_d_l "../testcase/${TEST_CASE}/testcase/SI_Fuji-AE/ocm_si_fuji_D_${num_wsram}L";
    }
 
    if { [file exists $file_a_l ] ==1 } {
      puts "load chiplet\[$num_chiplet\] ocm_si_fuji_A_${num_wsram}"
      if { $num_chiplet == 0 } {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem";
      } else {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem";
      }
      #memory -load $memory_l -file $file_a_l;
      memory -load $memory_u -file $file_a_u -radix hexa;
    }

    if { [file exists $file_b_l ] ==1 } {
      puts "load chiplet\[$num_chiplet\] ocm_si_fuji_B_${num_wsram}"
      if { $num_chiplet == 0 } {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem"
      } else {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem"
      }
      #memory -load $memory_l -file $file_b_l;
      memory -load $memory_u -file $file_b_u -radix hexa;
    }

    if { [file exists $file_c_l ] ==1 } {
      puts "load chiplet\[$num_chiplet\] ocm_si_fuji_C_${num_wsram}"
      if { $num_chiplet == 0 } {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem"
      } else {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem"
      }
      #memory -load $memory_l -file $file_c_l;
      memory -load $memory_u -file $file_c_u  -radix hexa;
    }

    if { [file exists $file_d_l ] ==1 } {
      puts "load chiplet\[$num_chiplet\] ocm_si_fuji_D_${num_wsram}"
      if { $num_chiplet == 0 } {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem"
      } else {
        #set memory_l "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.RAM_CONFIG_0.ROW\[0\].COLUMN\[0\].u_sram.u_mem.u0.mem_core_array";
        set memory_u "TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem"
      }
      #memory -load $memory_l -file $file_d_l;
      memory -load $memory_u -file $file_d_u  -radix hexa;
    }

    #if {![file isdirectory ocm_dump]} {
    #  file mkdir ocm_dump
    #}
    if { [file exists $file ] ==1 } {
      # For debug
      if { $num_chiplet == 0 } {
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_A_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_B_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_C_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_D_${num_wsram}U.dat
      } else {
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_A_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_B_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_C_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_D_${num_wsram}U.dat
      }  
    } else {
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_A_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_B_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_C_${num_wsram}U.dat
        memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem -start 0 -end 5120 -file ocm_dump_SI_ocm_D_${num_wsram}U.dat
    }
    incr num_wsram
  }
  incr num_chiplet
}

puts "SI_FUJI memory loading done"
#puts "\[TCL\]\[SI\]preload ep time=[senv time]"
