#--------------------------------------------------------------------
# Preload eFuse
#--------------------------------------------------------------------

set file "efuse_0.dat";
if { [file exists $file ] ==1 } {
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE0.fuse_data";
    memory -load $memory -file $file -radix hexa;
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE1.fuse_data";
    memory -load $memory -file $file -radix hexa;
}

set file "efuse_2.dat";
if { [file exists $file ] ==1 } {
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE2.fuse_data";
    memory -load $memory -file $file -radix hexa;
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE3.fuse_data";
    memory -load $memory -file $file -radix hexa;
}

set file "efuse_3.dat";
if { [file exists $file ] ==1 } {
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE3.fuse_data";
    memory -load $memory -file $file -radix hexa;
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE3.fuse_data_rir";
    memory -load $memory -file $file -radix hexa;
}

run 1ns
if {![file isdirectory ocm_dump]} {
  file mkdir ocm_dump
}
memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE0.fuse_data -file ocm_dump/eFuse0.dat
memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE1.fuse_data -file ocm_dump/eFuse1.dat
memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE2.fuse_data -file ocm_dump/eFuse2.dat
memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uNVM.FUSE3.fuse_data -file ocm_dump/eFuse3.dat
