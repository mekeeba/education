#--------------------------------------------------------------------
#
#--------------------------------------------------------------------

# phase_reset pre hook
if { [ file exists ${TCL_PATH}/phase_reset_pre.tcl ] } {
  puts "phase_reset pre hook"
  source ${TCL_PATH}/phase_reset_pre.tcl
}

# # create waveform
# if { [info exists ::env(WAVE_DUMP_ON)] } {
#   puts "load wave.tcl"
#   source ${TCL_PATH}/wave.tcl
# }

# phase_reset post hook
if { [ file exists ${TCL_PATH}/phase_reset_post.tcl ] } {
  puts "phase_reset post hook"
  source ${TCL_PATH}/phase_reset_post.tcl
}
