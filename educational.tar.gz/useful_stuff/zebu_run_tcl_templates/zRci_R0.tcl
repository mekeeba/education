#####################################
# Get Command line Parameters
#####################################
set TARMAC_ENABLE 0
set DUMP_ENABLE 0

foreach arg $argv {
  if {$arg == "qiwc_dump"} {
    puts "QIWC DUMPING ENABLED"
    set DUMP_ENABLE 1 
  } 
  if {$arg == "tarmac_enable"} {
    puts "TARMAC DUMPING ENABLED"
    set TARMAC_ENABLE 1 
  }
}

##################################################
# Get TEST NAME. Directory above the run directory
##################################################
set script_path $::env(PWD)
set script_path_neg_1 [ file dirname $script_path ]
set TEST_CASE [ exec basename $script_path_neg_1 ] 
puts "Using Test Case $TEST_CASE"

#####################################
# Constant Scopes For DDR
#####################################
set DDR0_SCOPE "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0"
set DDR1_SCOPE "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0"
set DDR2_SCOPE "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1"
set DDR3_SCOPE "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1"
set DDR4_SCOPE "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1"
set DDR5_SCOPE "TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1"

##################
# START ZEBU
##################
start_zebu

#######################
# TARMAC ENABLE START 
#######################
if { $TARMAC_ENABLE == 1 } {
  ccall -load $::env(ZEBU_HUNTER_TARMAC_PATH)/lib/hunterae_tarmac_dpi.so
  ccall -load $::env(ZEBU_KINFU_TARMAC_PATH)/lib/kinfu_tarmac_dpi.so
  ccall -enable_synchronization
  ccall -offline_spec $::env(SCRIPT_DIR)/zebu_offline_dpi 
  ccall -enable
}

######################
# Start Running clocks
# Deassert Reset
######################
run 1000
force TBENCH.xrst 1'b1 -freeze
run 100

######################
# Enable Dumping 
######################
if { $DUMP_ENABLE == 1 } {
    puts "MKAY Starting WaveForm Dump"
    set dut_fid [dump -file full_chip.ztdb -qiwc]
    dump -add_value_set {QIWC_PROBES} -fid $dut_fid
#    dump -interval 60 -fid $dut_fid
    dump -interval 60s -fid $dut_fid
    ###dump -interval {20000total_samples,10slices} -fid $dut_fid
    dump -enable -fid $dut_fid
}


#########################
# OCM State Machine Force 
#########################
#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_arb.init_state_next[1:0]} 2'b11 -freeze
#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11 -freeze
#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11 -deposit
force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11 -freeze

##########################
# DFI Timing Parameters
##########################

# DDR0
force $DDR0_SCOPE.zdfi_0.zebuCFG\[32:0\]    0x01020C0C08  -deposit
force $DDR0_SCOPE.zdfi_1.zebuCFG\[32:0\]    0x01020C0C08  -deposit

# DDR1
force $DDR1_SCOPE.zdfi_0.zebuCFG\[32:0\]    0x01020C0C08  -deposit
force $DDR1_SCOPE.zdfi_1.zebuCFG\[32:0\]    0x01020C0C08  -deposit

if { $::env(DESIGN_CONFIG) == "ZEBU_CONFIG_1" } {
  # DDR2
  force $DDR2_SCOPE.zdfi_0.zebuCFG\[32:0\]    0x01020C0C08  -deposit
  force $DDR2_SCOPE.zdfi_1.zebuCFG\[32:0\]    0x01020C0C08  -deposit

  # DDR3
  force $DDR3_SCOPE.zdfi_0.zebuCFG\[32:0\]    0x01020C0C08  -deposit
  force $DDR3_SCOPE.zdfi_1.zebuCFG\[32:0\]    0x01020C0C08  -deposit

  # DDR4
  force $DDR4_SCOPE.zdfi_0.zebuCFG\[32:0\]    0x01020C0C08  -deposit
  force $DDR4_SCOPE.zdfi_1.zebuCFG\[32:0\]    0x01020C0C08  -deposit

  # DDR5
  force $DDR5_SCOPE.zdfi_0.zebuCFG\[32:0\]    0x01020C0C08  -deposit
  force $DDR5_SCOPE.zdfi_1.zebuCFG\[32:0\]    0x01020C0C08  -deposit
}

#temp force 
#set {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uCRG_SI.uCRG_RSTCNT.u_CRG_RSTCNT_CORE_WRAP.u_CRG_RSTCNT_CORE.u_CRG_POST_SEQ.R_STNXT[14:0]} 15'h1

##########################
# Start Test Case 
##########################
source $::env(TEST_DIR)/$TEST_CASE/simdata/tcl/zebu/run.tcl

run 650ms
#run 650ms
#run 650ms
#run 650ms
#run 650ms

##########################
# Close Wave Dumping 
##########################
if { $DUMP_ENABLE == 1 } {
  puts "MKAY Closing the Wavefrom Dump"
  dump -disable -fid $dut_fid 
  dump -flush -fid $dut_fid 
  dump -close -fid $dut_fid 
}

##########################
# TUBE & Memory Dumping 
##########################
set num_wsram 0
while {$num_wsram < 12} {
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem -start 0 -end 1023 -file results_A_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem -start 0 -end 1023 -file results_B_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem -start 0 -end 1023 -file results_C_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem -start 0 -end 1023 -file results_D_${num_wsram}.dat
  incr num_wsram
}
puts "Dumping Tube Data"
memory -store TBENCH.uBind_apb_tube_wrap_hunter.uBind_apb_tube_0_0.u_apb_tube.RAM.mem -start 0 -end 1023 -file hunter_tube_0_0.data
memory -store TBENCH.uBind_apb_tube_wrap.uBind_apb_tube_0.u_apb_tube.RAM.mem -start 0 -end 1023 -file apb0_tube_0_0.data
memory -store TBENCH.uBind_apb_tube_wrap.uBind_apb_tube_1.u_apb_tube.RAM.mem -start 0 -end 1023 -file apb1_tube_0_0.data

##########################
# Close Tarmac 
##########################
if { $TARMAC_ENABLE == 1 } {
  ccall -flush
  ccall -close
}

##########################
# Close ZEBU 
##########################
finish 0
close_zebu
exit 0
