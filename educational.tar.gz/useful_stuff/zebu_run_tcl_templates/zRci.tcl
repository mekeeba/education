if {[llength $argv] < 2} {
    puts "This script should be called with Testname, please correct usage"
} else {
    puts "Running Test [lindex $argv 1]"

# start Zebu
start_zebu


#Start Running clocks
run 1000
force TBENCH.xrst 1'b1 -freeze
run 100

## From Temp Forces
force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uCPU.CFGRVBARADDR0\[39:2\] 32'h22340000 -freeze
force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uCPU.CFGRVBARADDR1\[39:2\] 32'h22340000 -freeze

## Hunter Forces
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucpu_ss_design_top.sysnoc_cpu_armmusecsid 1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucpu_ss_design_top.sysnoc_cpu_awmmusecsid 1 -freeze

#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucpu_ss_design_top.sysnoc_cpu_armmusid[19:0]}  20'h1 -freeze
#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucpu_ss_design_top.sysnoc_cpu_armmussid[19:0]} 20'h1 -freeze 


#force CRG RESETS
force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uCRG_AON.RESETn  1'b1 -freeze    
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uCRG_CPU.RESETn  1'b1 -freeze 
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uCRG_HSIF.RESETn 1'b1 -freeze 
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uCRG_CNOC.RESETn 1'b1 -freeze 
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uCRG_SENS.RESETn 1'b1 -freeze 
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uCRG_MEM.RESETn  1'b1 -freeze 
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER0.uDDR_CPU_SS0.uCRG_DDR_CPU0.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER0.uDDR_CPU_SS1.uCRG_DDR_CPU1.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_rt_hlb.uCRG_RT.RESETn   1'b1 -freeze   
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_eth_hlb.uCRG_ETH.RESETn 1'b1 -freeze
force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_isp_hlb.uCRG_ISP.RESETn 1'b1 -freeze
force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_rdr_hlb.uCRG_RDR.RESETn 1'b1 -freeze
force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_dsp_hlb.uCRG_DSP.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_eff_tdm_hlb.uCRG_EFF_TDM.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER1.uDDR_SENS_SS0.uCRG_DDR_SENS0.RESETn 1'b1 -freeze 
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER1.uDDR_SENS_SS1.uCRG_DDR_SENS1.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER1.uDDR_SENS_SS2.uCRG_DDR_SENS2.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER1.uDDR_SENS_SS3.uCRG_DDR_SENS3.RESETn 1'b1 -freeze
#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.ucr_ml_hlb.uCRG_ML.RESETn 1'b1 -freeze
###

#force TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER0.uDDR_CPU_SS0.uCRG_DDR_CPU0.RESETn 0x00000000FF -freeze

## Dump Enable
    puts "Mkay [lindex $argv 3]" 
    if {[lindex $argv 3] == "qiwc_dump"} {
    puts "Dumping Waveform"
    set dut_fid [dump -file full_chip.ztdb -qiwc]
    dump -add_value_set {QIWC_PROBES} -fid $dut_fid
    dump -interval 4 -fid $dut_fid
    ###dump -interval {20000total_samples,10slices} -fid $dut_fid
    dump -enable -fid $dut_fid
   }

force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_arb.init_state_next[1:0]} 2'b11 -freeze

  # if {[lindex $argv 1] == "DDR_LP0_1_Check_EMU"} {
  # puts "Testcase  [lindex $argv 1]"
  # set TEST_CASE [lindex $argv 1]
  # source ../testcase/$TEST_CASE/simdata/tcl/run_testcase_zebu.tcl
  # }

  # if {[lindex $argv 1] == "DDR_LP2_Check_5_EMU"} {
   set TEST_CASE [lindex $argv 1]
   puts "Testcase  [lindex $argv 1]"
   source ../testcase/$TEST_CASE/simdata/tcl/run_testcase_zebu.tcl
   #}
#run 650ms
#run 650ms
  if {[lindex $argv 3] == "qiwc_dump"} {
  puts "Closing the Wavefrom Dump"
  dump -disable -fid $dut_fid 
  dump -flush -fid $dut_fid 
  dump -close -fid $dut_fid 
  }

set num_wsram 0
while {$num_wsram < 4} {
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem_q -start 0 -end 1023 -file results_A_${num_wsram}_ALL0.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem_q -start 0 -end 1023 -file results_B_${num_wsram}_ALL0.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem_q -start 0 -end 1023 -file results_C_${num_wsram}_ALL0.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem_q -start 0 -end 1023 -file results_D_${num_wsram}_ALL0.dat
  incr num_wsram
}

}
finish 0
close_zebu
exit 0










#### For Referance ###
#memory -load "tb.ins_zHBM3_Ch0.zHBM3.mem_core_sp_PCh0.mem_logic" -file ../../src/dut/data0.hex -radix hexa
#memory -load "tb.ins_zHBM3_Ch0.zHBM3.mem_core_sp_PCh1.mem_logic" -file ../../src/dut/data1.hex -radix hexa
#get  tb.ins_zHBM3_Ch0.zHBM3.ins_ieee1500_wsp_hbm.ins_device_id.zebuReg\[31:28\]  -radix hexa 
#force tb.ins_zHBM3_Ch0.zHBM3.ins_ieee1500_wsp_hbm.ins_device_id.zebuReg\[31:28\] f -radix hexa -deposit

#set dut_fid [dump -file waves_tb.ztdb -fwc]
#dump -add_value_set Default -fid $dut_fid
#dump -interval auto -fid $dut_fid
#dump -enable -fid $dut_fid

#set qiwc_fid [dump -file wave_qiwc.ztdb -type qiwc]
#dump -add_value_set {qiwc_dump} -fid $qiwc_fid
#dump -enable -fid $qiwc_fid
#dump -fid $qiwc_fid
#run 1000000
#dump -close -fid $qiwc_fid
#run
#finish

####Analyzer
##ccall -load /global/gtsna_northeast6/madineni/HBM3/example.0313/ZHBM3_LOCAL/HW_IP/ZHBM3_Q-2021.06-2023_03_10/lib/libzHBM3_analyzer_64.so
##ccall -enable


#run 100 -clock tb.CK_4x_t
#run 100

#force tb.RESET_n 1 -radix hexa -deposit

#dump -disable -fid $dut_fid
#dump -flush -fid $dut_fid
#dump -close -fid $dut_fid

#puts "Basic DDR Test TestCase"

#close_zebu
#exit 0
