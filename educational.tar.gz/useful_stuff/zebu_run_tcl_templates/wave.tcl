

if { $env(set_tool) == "SYNOPSYS" } {
  if { $env(WAVE_DUMP_ON) == "1" } {
    #puts "---Synopsys wave on---"
    create fsdb
    fsdbDumpfile  wave.fsdb
    #fsdbDumpvars "+all"
    #fsdbDumpvars 0 TBENCH
    fsdbDumpvars 1 TBENCH
    fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP
    fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP
    fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C
    fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uNOC_SYS
    fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uNOC_MPU
    fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0
    fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1
    # fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M
    # fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM
    # fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0
    # fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1
    # fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2
    # fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3
    # fsdbDumpvars 1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.uNOC_MEM_FLAT.uCRG_MEM
    fsdbDumpvars 0 TBENCH.uDRAM_WRP
    fsdbDumpvars 0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top
  }
} else {
  if { $env(WAVE_DUMP_ON) == "1" } {
    if { $env(set_wave_format) == "shm" } {
      #puts "---Cadence wave on---"
      #database -open ./wave  -shm -incsize 1G
      database -open ./wave  -shm
      probe -create TBENCH         -depth all
      #probe -create TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top            -depth 2
    } else {
      call fsdbDumpfile  \"wave.fsdb\"
      call fsdbDumpvars 0 TBENCH
    }
  }
}
