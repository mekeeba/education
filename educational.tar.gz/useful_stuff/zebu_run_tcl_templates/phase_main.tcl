#--------------------------------------------------------------------
# phase main
#--------------------------------------------------------------------

# phase_main pre hook
if { [ file exists ${TCL_PATH}/phase_main_pre.tcl ] } {
  puts "phase_main pre hook"
  source ${TCL_PATH}/phase_main_pre.tcl
}

source ${TCL_PATH}/common_proc.tcl
#source ${TCL_PATH}/fileio_config.tcl
source ${TCL_PATH}/common_config.tcl

source ${TCL_PATH}/temporary_force.tcl
#source ${TCL_PATH}/load_memory_efuse.tcl
#source ${TCL_PATH}/load_memory_RT_FUJI.tcl
source ${TCL_PATH}/load_memory_SI_FUJI_ROM.tcl
set {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11
source ${TCL_PATH}/load_memory_SI_FUJI.tcl
set {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11
puts "TB_DETECT_PSEUDO_ERR_MASK_END"
source ${TCL_PATH}/run_testcase.tcl

# phase_main post hook
if { [ file exists ${TCL_PATH}/phase_main_post.tcl ] } {
  puts "phase_main post hook"
  source ${TCL_PATH}/phase_main_post.tcl
}
