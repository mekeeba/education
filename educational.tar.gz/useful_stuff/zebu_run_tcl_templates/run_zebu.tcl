

proc RT_fuji_Preload {TEST_CASE} {  
  set systemTime [clock seconds]
  puts "INFO: RT preloading start time : [clock format $systemTime -format %H:%M:%S]"
  set LLRAM TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM

    # 4 Banks and Each bank has 32K * 72 bits
    for { set i 0} {$i < 4} {incr i} {
    
      puts "INFO: Loading OCM ${i}"
      set file_A "$::env(TEST_DIR)/${TEST_CASE}/testcase/RT_Fuji-AE/ocm_rt_fuji_A_${i}"
      set file_B "$::env(TEST_DIR)/${TEST_CASE}/testcase/RT_Fuji-AE/ocm_rt_fuji_B_${i}"
      set file_C "$::env(TEST_DIR)/${TEST_CASE}/testcase/RT_Fuji-AE/ocm_rt_fuji_C_${i}"
      set file_D "$::env(TEST_DIR)/${TEST_CASE}/testcase/RT_Fuji-AE/ocm_rt_fuji_D_${i}"


      #set file_A "../testcase/smoke_test__crz_ss_ALL_reg/testcase/RT_Fuji-AE/ocm_rt_fuji_A_${i}"
      #set file_B "../testcase/smoke_test__crz_ss_ALL_reg/testcase/RT_Fuji-AE/ocm_rt_fuji_B_${i}"
      #set file_C "../testcase/smoke_test__crz_ss_ALL_reg/testcase/RT_Fuji-AE/ocm_rt_fuji_C_${i}"
      #set file_D "../testcase/smoke_test__crz_ss_ALL_reg/testcase/RT_Fuji-AE/ocm_rt_fuji_D_${i}"


      if { [file exists $file_A ] == 1 } {
          set memory "${LLRAM}.u_ocm_sram.gsram_i_0__gsram_j_${i}__smem.mem_q"
	  #set memory "${LLRAM}.u_ocm_sram.gsram_i\[0\].sram_bank.gsram_j\[${i}\].smem.mem_q"
          puts "RT-LOAD : ${memory} preload with ${file_A}"
          memory -load $memory -file $file_A;
      }
      
      if { [file exists $file_B ] == 1 } {
          set memory "${LLRAM}.u_ocm_sram.gsram_i_1__gsram_j_${i}__smem.mem_q"
	  #set memory "${LLRAM}.u_ocm_sram.gsram_i\[1\].sram_bank.gsram_j\[${i}\].smem.mem_q"
          puts "RT-LOAD : ${memory} preload with ${file_B}"
          memory -load $memory -file $file_B;
      }
      
      if { [file exists $file_C ] == 1 } {
          set memory "${LLRAM}.u_ocm_sram.gsram_i_2__gsram_j_${i}__smem.mem_q"
	  #set memory "${LLRAM}.u_ocm_sram.gsram_i\[2\].sram_bank.gsram_j\[${i}\].smem.mem_q"
          puts "RT-LOAD : ${memory} preload with ${file_C}"
          memory -load $memory -file $file_C;
      }
      
      if { [file exists $file_D ] == 1 } {
          set memory "${LLRAM}.u_ocm_sram.gsram_i_3__gsram_j_${i}__smem.mem_q"
	  #set memory "${LLRAM}.u_ocm_sram.gsram_i\[3\].sram_bank.gsram_j\[${i}\].smem.mem_q"
          puts "RT-LOAD : ${memory} preload with ${file_D}"
          memory -load $memory -file $file_D;
      }

    }

  run 1ns
  puts "INFO: RT preloading end time : [clock format $systemTime -format %H:%M:%S]"

}


#####################################
# Main
#####################################
puts "Running Test [lindex $argv 1]"


#####################################
# Get Command line Parameters
#####################################
set TARMAC_ENABLE 0
set DUMP_ENABLE 0

foreach arg $argv {
  if {$arg == "qiwc_dump"} {
    puts "QIWC DUMPING ENABLED"
    set DUMP_ENABLE 1 
  } 
  if {$arg == "tarmac_enable"} {
    puts "TARMAC DUMPING ENABLED"
    set TARMAC_ENABLE 1 
  }
}


# start Zebu
start_zebu
#start_zebu -designFeatures ./designFeatures

#######################
# TARMAC ENABLE START 
#######################
if { $TARMAC_ENABLE == 1 } {
  ccall -load $::env(ZEBU_HUNTER_TARMAC_PATH)/lib/hunterae_tarmac_dpi.so
  ccall -load $::env(ZEBU_KINFU_TARMAC_PATH)/lib/kinfu_tarmac_dpi.so
  ccall -enable_synchronization
  ccall -offline_spec $::env(SCRIPT_DIR)/zebu_offline_dpi 
  ccall -enable
}


global TEST_CASE
set TEST_CASE [lindex $argv 1]

puts "########################"
puts " $TEST_CASE "
puts "########################"

######################
# Enable Dumping 
######################
if { $DUMP_ENABLE == 1 } {
    puts "INFO: Starting WaveForm Dump"
    set dut_fid [dump -file full_chip.ztdb -qiwc]
    dump -add_value_set {QIWC_PROBES} -fid $dut_fid
#    dump -interval 60 -fid $dut_fid
    dump -interval 4 -fid $dut_fid
    ###dump -interval {20000total_samples,10slices} -fid $dut_fid
    dump -enable -fid $dut_fid
}


#Start Running clocks
run 1000
force TBENCH.xrst 1'b1 -freeze
run 100

#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_arb.init_state_next[1:0]} 2'b11 -freeze
#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11 -freeze
#force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11 -deposit
force {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_arb_ad.u_ocmad_arb.init_state_next[1:0]} 2'b11 -freeze

#temp force 
#set {TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uCRG_SI.uCRG_RSTCNT.u_CRG_RSTCNT_CORE_WRAP.u_CRG_RSTCNT_CORE.u_CRG_POST_SEQ.R_STNXT[14:0]} 15'h1

#source ../testcase/$TEST_CASE/simdata/tcl/zebu/run_testcase.tcl
source $::env(TEST_DIR)/$TEST_CASE/simdata/tcl/run.tcl

#RT_fuji_Preload $TEST_CASE

run 1600ms
#run 650ms
#run 650ms
#run 650ms
#run 650ms

if {[lindex $argv 3] == "qiwc_dump"} {
puts "Closing the Wavefrom Dump"
dump -disable -fid $dut_fid 
dump -flush -fid $dut_fid 
dump -close -fid $dut_fid 
}

set num_wsram 0
while {$num_wsram < 12} {
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem -start 'h0 -end 'h3FF -file results_A_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem -start 'h0 -end 'h3FF -file results_B_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem -start 'h0 -end 'h3FF -file results_C_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.u_ocmad.u_ocmad_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem -start 'h0 -end 'h3FF -file results_D_${num_wsram}.dat
  incr num_wsram
}

# Tubes dumping
# RT
#memory -store TBENCH.uBind_RT_FUJI_apb_tube_wrap.uBind_apb_tube_0.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file rt_apb0_tube_0.data
#memory -store TBENCH.uBind_RT_FUJI_apb_tube_wrap.uBind_apb_tube_1.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file rt_apb0_tube_1.data
#memory -store TBENCH.uBind_RT_FUJI_apb_tube_wrap.uBind_apb_tube_2.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file rt_apb0_tube_2.data
#memory -store TBENCH.uBind_RT_FUJI_apb_tube_wrap.uBind_apb_tube_3.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file rt_apb0_tube_3.data

# Hunter
memory -store TBENCH.uBind_apb_tube_wrap_hunter.uBind_apb_tube_0_0.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file hunter_tube_0_0.data

# SI
memory -store TBENCH.uBind_apb_tube_wrap.uBind_apb_tube_0.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file apb0_tube_0_0.data
memory -store TBENCH.uBind_apb_tube_wrap.uBind_apb_tube_1.u_apb_tube.RAM.mem -start 'h0 -end 'h3FF -file apb1_tube_0_0.data

# Storing RT OCM
#memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM.u_ocm_sram.gsram_i\[0\].gsram_j\[0\].smem.mem_q -start 'h0 -end 'h3FF -file rt_ocm0_mem_0.data
#memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM.u_ocm_sram.gsram_i\[0\].gsram_j\[1\].smem.mem_q -start 'h0 -end 'h3FF -file rt_ocm0_mem_1.data
#memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM.u_ocm_sram.gsram_i\[0\].gsram_j\[2\].smem.mem_q -start 'h0 -end 'h3FF -file rt_ocm0_mem_2.data
#memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM.u_ocm_sram.gsram_i\[0\].gsram_j\[3\].smem.mem_q -start 'h0 -end 'h3FF -file rt_ocm0_mem_3.data

puts "INFO: Dumping OCM RT memory ...."
set LLRAM TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM

# 4 Banks and Each bank has 32K * 72 bits
#for { set i 0} {$i < 4} {incr i} {

#    puts "INFO: Loading OCM ${i}"
#    set file_A "dump_ocm_rt_fuji_A_${i}"
#    set file_B "dump_ocm_rt_fuji_B_${i}"
#    set file_C "dump_ocm_rt_fuji_C_${i}"
#    set file_D "dump_ocm_rt_fuji_D_${i}"
  
#    set memory_A "${LLRAM}.u_ocm_sram.gsram_i_0__gsram_j_${i}__smem.mem_q"
#    set memory_B "${LLRAM}.u_ocm_sram.gsram_i_1__gsram_j_${i}__smem.mem_q"
#    set memory_C "${LLRAM}.u_ocm_sram.gsram_i_2__gsram_j_${i}__smem.mem_q"
#    set memory_D "${LLRAM}.u_ocm_sram.gsram_i_3__gsram_j_${i}__smem.mem_q"

#    memory -store $memory_A -start 'h0 -end 'h3FF -file $file_A
#    memory -store $memory_B -start 'h0 -end 'h3FF -file $file_B
#    memory -store $memory_C -start 'h0 -end 'h3FF -file $file_C
#    memory -store $memory_D -start 'h0 -end 'h3FF -file $file_D
#}

##########################
# Close Tarmac 
##########################
if { $TARMAC_ENABLE == 1 } {
  ccall -flush
  ccall -close
}

##########################
# Close ZEBU 
##########################

finish 0
close_zebu
exit 0

