#! /bin/csh -f

rems --zebu.work $ZEBU_WORK --timeout=7200 &
