#--------------------------------------------------------------------
#
#--------------------------------------------------------------------

# phase_shutdown pre hook
if { [ file exists ${TCL_PATH}/phase_shutdown_pre.tcl ] } {
  puts "phase_shutdown pre hook"
  source ${TCL_PATH}/phase_shutdown_pre.tcl
}

# last run
run 500ns

# memory dump
#puts "load dump_memory.tcl"
#source ${TCL_PATH}/dump_memory.tcl

# phase_shutdown post hook
if { [ file exists ${TCL_PATH}/phase_shutdown_post.tcl ] } {
  puts "phase_shutdown post hook"
  source ${TCL_PATH}/phase_shutdown_post.tcl
}
