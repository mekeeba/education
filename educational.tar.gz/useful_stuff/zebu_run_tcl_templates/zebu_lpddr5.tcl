# check if the correct no of Arguments are provided.
   if {[llength $argv] != 3} {
      puts "Usage : ben2hex.tcl <Input Binary file > <start_addr 1F000000>, <0|1> (forRBC_BRCn) \n"
      exit 1
   } 

# extarct the Input and Output Files. 
   set InputFh  [lindex $argv 0]
   set IntHexFile [lindex $argv 0]
   append IntHexFile .hex
   set StartAddr [lindex $argv 1]
   set RBC_BRCn  [lindex $argv 2]

# open the binary file for readding
  set InputFile [open $InputFh "rb"]
  if {[catch {set InputFile [open $InputFh "rb"]}]} {
   puts "Error : unable to open the input file $InputFile \n"
   exit 1
  }

# check the output file
  set OutputFile [open $IntHexFile "w"]
  if {[catch {set OutputFile [open $IntHexFile "w"]}]} {
   puts "Error : unable to open the outout file $IntHexFile\n"
   exit 1
  }


# read binary data 
  while {![eof $InputFile]} {
   set BinaryData [read $InputFile 16]
   #set HexData [binary encode hex $BinaryData]
   binary scan $BinaryData H* HexData
   #puts -nonewline $OutputFile $BinaryData
   puts $OutputFile $HexData
   #puts -nonewline $OutputFile $HexData  
 }
#puts "Debug $IntHexFile"
#exec sh -c {perl zebu_lpddr4_32g_x16_addr_mapping.pl $OutputFile 1F000000 0}
## Usage:
# % perl ./zebu_lpddr4_32g_x16_addr_mapping_text.pl rtu_execute_from_ddr.hex
# Please enter 8'h base address.(Example:1f000000): 07010000
# Please enter the RBC_BRCn value.(0 or 1): 0
# The log files: decode.log, u0_a.txt, u0_b.txt, u1_a.txt and u1_b.txt be generated successfully.
exec perl zebu_lpddr5_32g_x16_addr_mapping.pl $IntHexFile $StartAddr $RBC_BRCn
close $InputFile
close $OutputFile

 
