#--------------------------------------------------------------------
# Memory loading files
#--------------------------------------------------------------------
# RAM/ROM file path
#     set MEM_PATH simdata/mem

proc RT_fuji_Preload {} {

  puts "\[TCL\]\[RT\]preload sp time=[senv time]"

  set LLRAM TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uRT_SS.uKINFU_RT_TOP.uLLRAM
  for { set i 0} {$i < 32} {incr i} {
    set file "testcase/RT_Fuji-AE/ocm_rt_fuji_A_${i}"
    set gsram_i_n [expr $i / 8]
    set RAMR_n [expr $i % 8]
    if { [file exists $file ] ==1 } {
      set memory "${LLRAM}.u_ocm_sram.gsram_i\[${gsram_i_n}\].sram_bank.gsram_j\[0\].smem.genblk1.mem.RAMR\[${RAMR_n}].V.C\[0\].A.uCELL.U_SNIRAMTHSSP01024W072B04CNLS111101.u_ram_core.memory"

        puts "${memory} preload with ${file}"
        memory -read $memory -file $file;
      }
    }
    for { set i 0} {$i < 32} {incr i} {
      set file "ocm_rt_fuji_B_${i}"
      set file "testcase/RT_Fuji-AE/ocm_rt_fuji_B_${i}"
      set gsram_i_n [expr $i / 8]
      set RAMR_n [expr $i % 8]
      if { [file exists $file ] ==1 } {
        set memory "${LLRAM}.u_ocm_sram.gsram_i\[${gsram_i_n}\].sram_bank.gsram_j\[1\].smem.genblk1.mem.RAMR\[${RAMR_n}].V.C\[0\].A.uCELL.U_SNIRAMTHSSP01024W072B04CNLS111101.u_ram_core.memory"

        puts "${memory} preload with ${file}"
        memory -read $memory -file $file;
      }
    }

    for { set i 0} {$i < 32} {incr i} {
      set file "ocm_rt_fuji_C_${i}"
      set file "testcase/RT_Fuji-AE/ocm_rt_fuji_C_${i}"
      set gsram_i_n [expr $i / 8]
      set RAMR_n [expr $i % 8]
      if { [file exists $file ] ==1 } {
        set memory "${LLRAM}.u_ocm_sram.gsram_i\[${gsram_i_n}\].sram_bank.gsram_j\[2\].smem.genblk1.mem.RAMR\[${RAMR_n}].V.C\[0\].A.uCELL.U_SNIRAMTHSSP01024W072B04CNLS111101.u_ram_core.memory"

        puts "${memory} preload with ${file}"
        memory -read $memory -file $file;
      }
    }
    for { set i 0} {$i < 32} {incr i} {
      set file "ocm_rt_fuji_D_${i}"
      set file "testcase/RT_Fuji-AE/ocm_rt_fuji_D_${i}"
      set gsram_i_n [expr $i / 8]
      set RAMR_n [expr $i % 8]
      if { [file exists $file ] ==1 } {
        set memory "${LLRAM}.u_ocm_sram.gsram_i\[${gsram_i_n}\].sram_bank.gsram_j\[3\].smem.genblk1.mem.RAMR\[${RAMR_n}].V.C\[0\].A.uCELL.U_SNIRAMTHSSP01024W072B04CNLS111101.u_ram_core.memory"

        puts "${memory} preload with ${file}"
        memory -read $memory -file $file;
      }
    }


  run 1 ns

  puts "\[TCL\]\[RT\]preload ep time=[senv time]"

}

