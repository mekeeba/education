#--------------------------------------------------------------------
# Memory loading files
#--------------------------------------------------------------------
# RAM/ROM file path
#     set MEM_PATH simdata/mem

# Wait until stable

set num_wsram 0
while {$num_wsram < 4} {

  set file_a "testcase/SI_Fuji-AE/ocm_si_fuji_A_${num_wsram}";
  set file_b "testcase/SI_Fuji-AE/ocm_si_fuji_B_${num_wsram}";
  set file_c "testcase/SI_Fuji-AE/ocm_si_fuji_C_${num_wsram}";
  set file_d "testcase/SI_Fuji-AE/ocm_si_fuji_D_${num_wsram}";

  if { [file exists $file_a ] ==1 } {
    echo "load ocm_si_fuji_A_${num_wsram}"
    #set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.mem_q";
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory";
    memory -load $memory -file $file_a -radix hexa;
  }
  if { [file exists $file_b ] ==1 } {
    echo "load ocm_si_fuji_B_${num_wsram}"
    #set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.mem_q";
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory";
    memory -load $memory -file $file_b -radix hexa;
  }
  if { [file exists $file_c ] ==1 } {
    echo "load ocm_si_fuji_C_${num_wsram}"
    #set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.mem_q";
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory";
    memory -load $memory -file $file_c -radix hexa;
  }
  if { [file exists $file_d ] ==1 } {
    echo "load ocm_si_fuji_D_${num_wsram}"
    #set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.mem_q";
    set memory "TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory";
    memory -load $memory -file $file_d -radix hexa;
  }

  # For debugg
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[0\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory -start 0 -end 1023 -file dump_A_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[1\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory -start 0 -end 1023 -file dump_B_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[2\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory -start 0 -end 1023 -file dump_C_${num_wsram}.dat
  memory -store TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uSI_SS_HLB.usi_ss_top.uSI_SS_CORE.uOCM.u_ocm_sram.gsram_i\[${num_wsram}\].gsram_j\[3\].smem.genblk1.mem.RAMR\[0\].V.C\[0\].A.uCELL.U_SNIRAMTSPMB08192W072B08CQLS111101.u_ram_core.memory -start 0 -end 1023 -file dump_D_${num_wsram}.dat

  incr num_wsram
}
