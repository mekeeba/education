#--------------------------------------------------------------------
# Copyright(C) 2023 Socionext Inc. All Rights Reserved.
#--------------------------------------------------------------------

#tmp_force_CMN_PSTATE_LOCGC
#tmp_force_NOC_CPU_ADDRESS_MASK

#wait_for_dram_load

# create waveform
#if { [info exists ::env(WAVE_DUMP_ON)] } {
#    puts "load wave.tcl"
#    source ${TCL_PATH}/wave.tcl
#}

#trg_load 0 mem_load_all0
#trg_load 0 hunter_boot_ROM

#source ${TCL_PATH}/dram_dump_proc.tcl
#exe_proc_wait_for_dram_dump dump

#run



tmp_force_CMN_PSTATE_LOCGC
tmp_force_NOC_CPU_ADDRESS_MASK
tmp_force_CRG_CPU_PERI_RELEASE

#wait_for_dram_load

# create waveform
#if { [info exists ::env(WAVE_DUMP_ON)] } {
#    puts "load wave.tcl"
#    source ${TCL_PATH}/wave.tcl
#}

trg_load_zebu 0 $TEST_CASE mem_load_all0
trg_load_zebu 0 $TEST_CASE hunter_boot_ROM

#source ${TCL_PATH}/dram_dump_proc.tcl
#exe_proc_wait_for_dram_dump dump

run 650ms
