set suji_dir [exec pwd]
puts "$suji_dir"

set files [glob -dir $suji_dir *_*U]

foreach file $files {
   #set fileL [open "ocm_si_fuji_A_0L" r]
   #set fileU [open "ocm_si_fuji_A_0U" r]
   #set output_file [open "ocm_si_fuji_A_0" w]
   set fileU [open "$file" r]
   set fileL [open "[regsub {(.)$} $file "L"]" r]
   set output_file [open "[regsub {(.)$} $file ""]" w]
      #set file_example [regsub {(.)$} $file "U"] ( for debug)
      #puts "$file_example"

 while { [gets $fileU line1] >= 0 && [gets $fileL line2] >= 0} {
  set second_word [lindex [split $line2] 1]
  set first_word  [lindex [split $line2] 0]
  puts $output_file "$line1$second_word"
 }

}

close $fileL
close $fileU
close $output_file
