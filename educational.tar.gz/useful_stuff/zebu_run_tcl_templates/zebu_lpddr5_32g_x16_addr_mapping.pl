#!/usr/bin/perl
## Get the base address and RBC_BRCn information and check. 
if (@ARGV < 3) {
  print STDERR "Usage: $0 <Input Hex File> <address> <RBC_BRC -0/1>\n";
  print STDERR "example : perl zebu_lpddr4_32g_x16_addr_mapping.pl test.hex 1f000000 0 \n";
  exit 1;
}
#print "Please enter 8'h base address.(Example:1f000000): ";
#my $base_addr = <STDIN>;
my $base_addr = $ARGV[1];
#print "Please enter 8'h base address $base_addr";
chomp $base_addr;
if ((length ($base_addr)) != 8) {die "Wrong Base Address Format. Please Use 8 Hex Format\n";}
if ($base_addr =~ m/[g-zG-Z]/) {die "Wrong Base Address Format. Please Use Hex Format\n";}
#print "Please enter the RBC_BRCn value.(0 or 1): ";
#my $RBC_BRCn = <STDIN>;
my $RBC_BRCn = $ARGV[2];
#print "Please enter 8'h base address $RBC_BRCn";
chomp $RBC_BRCn;
if (($RBC_BRCn != 0) && ($RBC_BRCn != 1)) {die "Wrong RBC_BRC_n Value, Please Enter 0 or 1 Valule\n";}

## Read the binary file.
#my $filename = 'binary.txt';
my $filename = $ARGV[0];
open(my $fh, '<:encoding(UTF-8)', $filename)
  or die "Could not open file '$filename' $!";

## Collect the total binary data.
my $count=0;
my $total_binary;
my $row_data;
my $row_addr;
my $total_addr;
while (my $row = <$fh>) {
 chomp $row;
 #$row =~ s/\s+//g; 
 my @row_split = split /\s+/, $row;
 #my $row_data = join("",reverse(/(..)/g,$row_split[1]));
 #my $row_data = reverse(/(.{1})/g,$row_split[1]);
 $row_data = reverse($row_split[1]);
 $row_addr = $row_split[0];
 #print "Malli0 : $row_data\n";
 #print "Malli1 : $row_addr\n";
 my $row_addr = $row_split[0];
 $count = $count+1;
 $total_binary = $total_binary.$row_data;
 $total_addr   = $total_addr.$row_addr;
}
if ($total_binary =~ m/[g-zG-Z]/) {die "Invalid Characters in binary.txt, Please check the content.\n";}
if ($total_addr   =~ m/[g-zG-Z]/) {die "Invalid Characters in binary.txt, Please check the content.\n";}
close($fh);

## Open the file for dumping logs.
## Open the file for dumping logs.
my $directory = TestData;
if (! -e 'TestData') {
mkdir($directory) or die "No $directory directory, $!";   
print "Directory created \n";
}
my $decode_log="decode.log";
my $u0_a="./TestData/u0_a.txt", $u0_b="./TestData/u0_b.txt", $u1_a="./TestData/u1_a.txt", $u1_b="./TestData/u1_b.txt";
open(FHO_log,">$decode_log") || die "Can't open $decode_log!\n";
open(FHO_u0a,">$u0_a") || die "Can't open $u0_a!\n";
open(FHO_u0b,">$u0_b") || die "Can't open $u0_b!\n";
open(FHO_u1a,">$u1_a") || die "Can't open $u1_a!\n";
open(FHO_u1b,">$u1_b") || die "Can't open $u1_b!\n";
#print FHO_u0a "U0_A\n";
#print FHO_u0b "U0_B\n";
#print FHO_u1a "U1_A\n";
#print FHO_u1b "U1_B\n"; 

## Calculate the totay binary length and push byte into array.
my @byte_array;
my $binary_temp;
my $len = length($total_binary);
my $byte_len = $len/2;
#print "Total byte numbers=$byte_len\n";
for (my $i=0; $i <= $len; $i=$i+2) {
  $binary_temp = substr $total_binary, $i, 2;
  push @byte_array, $binary_temp;
}

my $ln_addr;
my $ln_addr_bin;
my @addr_array;
my $addr_len = length($total_addr);
my $addr_temp;
for (my $i=0; $i <= $addr_len; $i=$i+9) {
  $addr_temp = substr $total_addr, $i, 9;
  push @addr_array, $addr_temp;
}


## Combine the data as Word format and decode address
my $word_array;
my $count_byte = 0;
my $val_comb;
my %test_hash;
my $base_addr_dec;
my $actual_addr_dec, $actual_addr_hex, $actual_addr_bin;
 foreach my $val (@byte_array) {
    if ($count_byte <= 4) {
       $val_comb = ($val_comb.$val);
       $count_byte = $count_byte+1;
    }
    if ($count_byte == 4) { 
       push @word_array, $val_comb;
       $count_byte = 0;
       $val_comb = undef;
    }
 } 
my $word_len = $#word_array+1;
#print "Total word numbers=$word_len\n";
my $word_count = 0;
my $array_count = 0;
my $addr_array_count = 0;
my $addr_array_index = 0;
my $high_bit_data, $low_bit_data, $byte_0, $byte_1, $byte_2, $byte_3;
my $data_temp, $binary_length, $add_zero_bit;
my $addr_count_1=0, $addr_count_2=0;
   for (my $k=0; $k<$byte_len; $k=$k+1) {
     $base_addr_dec = hex($base_addr);
     $actual_addr_dec = $k+$base_addr_dec;
     $actual_addr_hex = sprintf("%x", $actual_addr_dec);
     if ($word_count ==0) { 
       $test_hash {$actual_addr_hex} = $word_array[$array_count];
       $data_temp =  $test_hash {$actual_addr_hex};
       $byte_0 = substr $data_temp, 6,2; 
       $byte_1 = substr $data_temp, 4,2; 
       $byte_2 = substr $data_temp, 2,2; 
       $byte_3 = substr $data_temp, 0,2; 
       #$high_bit_data = reverse($byte_3.$byte_2);
       #$low_bit_data  = reverse($byte_1.$byte_0);
       $low_bit_data = reverse($byte_3.$byte_2);
       $high_bit_data  = reverse($byte_1.$byte_0);
       #print "ACTUAL_ADDR_HEX=$actual_addr_hex\n";
       $actual_addr_bin=sprintf( "%b", hex( $actual_addr_hex));
       $binary_length = length($actual_addr_bin);
       #print "binary_length=$binary_length\n";
       $add_zero_bit = 32-$binary_length; 
       for (my $add_bit=0; $add_bit < $add_zero_bit; $add_bit=$add_bit+1) {
         $actual_addr_bin = ("0".$actual_addr_bin);
       }
       #print "ACTUAL_ADDR_BIN=$actual_addr_bin\n";
      
       ##Call decode sub
       $ln_addr = $addr_array[$addr_array_index]; 
       #&decode_addr ($actual_addr_bin);
       #$ln_addr_bin=sprintf( "%b", hex( $ln_addr)) 
       &decode_addr ($ln_addr); 
       $word_count = $word_count+1;
     }elsif ($word_count ==1 || $word_count ==2){
       $word_count = $word_count+1; 
     }elsif ($word_count ==3) {
       $word_count =0; 
       $array_count = $array_count+1;
     }
   }
close(FHO_log);
close(FHO_u0a);
close(FHO_u0b);
close(FHO_u1a);
close(FHO_u1b);
print "The log files: decode.log, u0_a.txt, u0_b.txt, u1_a.txt and u1_b.txt be generated successfully.\n";

## Sub for decode the address.
sub decode_addr {
  #my $r_31_16, $b_15_13, $c_12_8, $select_ch, $zrm_addr_bin, $zrm_addr_hex;
  my $r_30_14, $bg_6_5,$b_8_7, $c_13_9, $c_4_0, $select_ch, $zrm_addr_bin, $zrm_addr_hex;
  my $binary_addr = shift @_;

  my $binary_addr_dec      = (hex($binary_addr)>>2);
  my $binary_addr_hex      = sprintf("%x", $binary_addr_dec);
  my $addr_array_count_hex = sprintf("%x", $addr_array_count);
  my $ln_addr_dec = (hex($binary_addr_hex)+hex($addr_array_count_hex));
  my $ln_addr_hex = sprintf("%x", $ln_addr_dec);
  my $ln_addr_bin = sprintf( "%b", hex( $ln_addr_hex));

  $binary_length = length($ln_addr_bin);
  #print "binary_length=$binary_length\n";
  $add_zero_bit = 32-$binary_length; 
  for (my $add_bit=0; $add_bit < $add_zero_bit; $add_bit=$add_bit+1) {
       $ln_addr_bin = ("0".$ln_addr_bin);
   }
  #print ("malli01:$binary_addr \n");
  #print ("malli01:$binary_addr_hex \n");
  #print ("malli01:$ln_addr_hex \n");
  #print ("malli01:$ln_addr_dec \n");
  #print ("malli01:$ln_addr_bin \n");

## Cluster 1
  #$c_13_9    = substr $ln_addr_bin, 18, 5;   # 5bit Col
  #$c_4_0     = substr $ln_addr_bin, 27, 5;   # 5bit col
  #$bg_6_5    = substr $ln_addr_bin, 25, 2;   # 2bit bank
  #$b_8_7     = substr $ln_addr_bin, 23, 2;   # 2bit bank
  #$r_30_14   = substr $ln_addr_bin, 1, 17;   # 17bit row
  #$select_ch = substr $ln_addr_bin, 0, 1;    # 1bit channel [chip select] bit no 31

#Cluster 0
  $c_3_0    = substr $ln_addr_bin, 28, 4;   # 4bit Col
  $c_8_6    = substr $ln_addr_bin, 23, 3;   # 3bit col
  $c_31_29  = substr $ln_addr_bin,  0, 3;   # 3bit col
  $bg_5_4   = substr $ln_addr_bin, 26, 2;   # 2bit bank
  $b_10_9   = substr $ln_addr_bin, 21, 2;   # 2bit bank
  $r_27_11   = substr $ln_addr_bin, 4, 17;   # 17bit row 
  $select_ch = substr $ln_addr_bin, 3, 1;    # 1 bit channel  [chip select] bit no 28
##

  #print ("$select_ch\n");
  #print ("$r_30_14\n");
  #print ("$b_8_7\n");
  #print ("$bg_6_5\n");
  #print ("$c_4_0\n$c_13_9");
  #$zrm_addr_bin = ($bg_6_5.$b_8_7.$r_30_14.$c_13_9.$c_4_0);
  #print ("$zrm_addr_bin");


  if ($RBC_BRCn == 0) {
#D# this is for BRC mode
    #$zrm_addr_bin = ($b_15_13.$r_31_16.$c_12_8.$c_6_2);
    #$zrm_addr_bin = ($bg_6_5.$b_8_7.$r_30_14.$c_13_9.$c_4_0);
    $zrm_addr_bin = ($bg_5_4.$b_10_9.$r_27_11.$c_31_29.$c_8_6.$c_3_0);
    $zrm_addr_hex=sprintf("%x", oct( "0b$zrm_addr_bin"));
    if ($select_ch == 0) {
       print FHO_log "Array_Cnt=$addr_array_index. SW=$ln_addr. RBC_BRCn=$RBC_BRCn. CS_0_RANK_0. ZRM_ADDR:$zrm_addr_hex. RANK0_channel_A:$low_bit_data RANK0_channel_B:$high_bit_data\n";
       if ($addr_count_1 == 0) {
          #print FHO_u0a "\@$zrm_addr_hex\n";
	  #print FHO_u0b "\@$zrm_addr_hex\n";
       }
       print FHO_u0a "\@$zrm_addr_hex $low_bit_data\n";
       print FHO_u0b "\@$zrm_addr_hex $high_bit_data\n";
       $addr_count_1 = $addr_count_1+1;
    }elsif ($select_ch == 1) {
       print FHO_log "SW=$actual_addr_hex. RBC_BRCn=$RBC_BRCn. CS_1_RANK_1. ZRM_ADDR:$zrm_addr_hex. RANK1_channel_A:$low_bit_data RANK1_channel_B:$high_bit_data\n";
       if ($addr_count_2 == 0) {
          print FHO_u1a "\@$zrm_addr_hex\n";
	  print FHO_u1b "\@$zrm_addr_hex\n";
       }
       print FHO_u1a "$low_bit_data\n";
       print FHO_u1b "$high_bit_data\n";
       $addr_count_2 = $addr_count_2+1;
    }
  }elsif ($RBC_BRCn == 1) { 
    #$zrm_addr_bin = ($r_31_16.$b_15_13.$c_12_8.$c_6_2); 
    $zrm_addr_bin = ($r_30_14.$bg_6_5.$b_8_7.$c_13_9.$c_4_0);
    $zrm_addr_hex=sprintf("%x", oct( "0b$zrm_addr_bin"));
    if ($select_ch == 0) {
       print FHO_log "SW=$actual_addr_hex. RBC_BRCn=$RBC_BRCn. CS_0_RANK_0. ZRM_ADDR:$zrm_addr_hex. ZRM_ADDR_BIN:$zrm_addr_bin ADDR_BIN:$binary_addr b_15_13:$b_15_13 r_31_16:$r_31_16 c_12_8=$c_12_8 c_6_2=$c_6_2 RANK0_channel_A:$low_bit_data RANK0_channel_B:$high_bit_data\n";
       if ($addr_count_1 == 0) {
          print FHO_u0a "\@$zrm_addr_hex\n";
	  print FHO_u0b "\@$zrm_addr_hex\n";
       }
       print FHO_u0a "\@$zrm_addr_hex $low_bit_data\n";
       print FHO_u0b "\@$zrm_addr_hex $high_bit_data\n";
       $addr_count_1 = $addr_count_1+1;
    }elsif ($select_ch == 1) {
       print FHO_log "SW=$actual_addr_hex. RBC_BRCn=$RBC_BRCn. CS_1_RANK_1. ZRM_ADDR:$zrm_addr_hex. RANK1_channel_A:$low_bit_data RANK1_channel_B:$high_bit_data\n";  
       if ($addr_count_2 == 0) {
          print FHO_u1a "\@$zrm_addr_hex\n";
	  print FHO_u1b "\@$zrm_addr_hex\n";
       }
       print FHO_u1a "\@$zrm_addr_hex $low_bit_data\n";
       print FHO_u1b "\@$zrm_addr_hex $high_bit_data\n";
       $addr_count_2 = $addr_count_2+1;
    }
  }
## address array counter
  if ($addr_array_count < 15) {
      $addr_array_count = $addr_array_count+1;
   } elsif ($addr_array_count == 15) {
      $addr_array_count = 0;
      $addr_array_index = $addr_array_index +1;
    }
   else {
     $addr_array_count = 0;
  }

}
