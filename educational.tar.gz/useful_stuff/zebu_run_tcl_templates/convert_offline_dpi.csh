#! /bin/csh -f

setenv ZEBU_HUNTER_TARMAC_PATH /remote/vgzebucruiseproj2/projects/omni/SoC/R0.1/rtl/CHIPTOP_RTL_R0p1/CPU_SS_SPR_R1_09_30_24/dev/design/ip/hunterae_v6/logical/testbench/shared/tarmac/linux64 
setenv ZEBU_KINFU_TARMAC_PATH /remote/vgzebucruiseproj2/projects/omni/SoC/R0.1/rtl/CHIPTOP_RTL_R0p1/SI/ip/IP_CRZ/ARM/CPU_SI/kinfu/logical/testbench/shared/tarmac/linux-x86_64

setenv PATH ${ZEBU_HUNTER_TARMAC_PATH}/bin:${ZEBU_KINFU_TARMAC_PATH}/bin:${PATH}

#./SI/ip/IP_CRZ/ARM/CPU_SI/kinfu/logical/testbench/shared/tarmac/linux-x86_64/bin/kinfu_tarmac_decode
#./CPU_SS_SPR_R1_09_30_24/dev/design/ip/hunterae_v6/logical/testbench/shared/tarmac/linux64/bin/hunterae_tarmac_decode
#setenv FILENAME kinfu_tarmac.@UID@.log

setenv KINFU_TARMAC_FILENAME kinfu_tarmac@CPUID@.log
setenv HUNTERAE_TARMAC_FILENAME hunterae_tarmac@CPUID@.log

zdpiReport -synchronize \
-i dpi.ztdb \
-l ${ZEBU_ROOT}/lib/libZebuSvdpiWrapper.so  \
-l $ZEBU_HUNTER_TARMAC_PATH/lib/hunterae_tarmac_dpi.so \
-l $ZEBU_KINFU_TARMAC_PATH/lib/kinfu_tarmac_dpi.so \
-f $SCRIPT_DIR/zebu_offline_dpi \
-z $ZEBU_WORK
