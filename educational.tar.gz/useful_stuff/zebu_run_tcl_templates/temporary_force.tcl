#--------------------------------------------------------------------
# Temporary force setting file
#--------------------------------------------------------------------

set file_chiplet "chiplet_en"
set catch_force_err_print 0

proc catch_force {sig val} {
  global catch_force_err_print
  if { [catch {force $sig $val -freeze} err_msg] } {
    if { $catch_force_err_print == 1 } {
      puts "TCL Debug:catch_force:$err_msg"
    }
  }
}
proc catch_force_opt {sig val opt} {
  global catch_force_err_print
  if { [catch {force $sig $val $opt} err_msg] } {
    if { $catch_force_err_print == 1 } {
      puts "TCL Debug:catch_force:$err_msg"
    }
  }
}

# for SVA X (dwc_sensors_ag2_cts)
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_HLB.uCTS_wrapper.dwc_sensors_cts.catmon_en 1'b0
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_HLB.uCTS_wrapper.dwc_sensors_cts.trim_code\[5:0\] 6'd0
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_HLB.uCTS_wrapper.dwc_sensors_cts.en_x_chk 1'b0

# for preload Si Fuji-AE code
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uINTROM.CRC_SKIP 1'b1
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.si_ocmad_auto_init_dis 1'b0

# R0.1 Avoid X propergation to CPU_SS/RT_SS irq inputs signals.
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_rdr_ss.rdr_noise_est_irq 1'b0
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_rdr_ss.rdr_ipi_err_irq 1'b0
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_rdr_ss.rdr_sram_err_irq 1'b0
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_isp_ss.vse_int_dw200_fe_int 1'b0
catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_efpga_ss.u_efss.u_efpga_wrap.o_efpga_glb_out_irq\[15:0\] 16'h0

# DDR PHY FF initialize.
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
#ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit

if { [file exists $file_chiplet ] ==1 } {
# for SVA X (dwc_sensors_ag2_cts)
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_HLB.uCTS_wrapper.dwc_sensors_cts.catmon_en 1'b0
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_HLB.uCTS_wrapper.dwc_sensors_cts.trim_code\[5:0\] 6'd0
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_HLB.uCTS_wrapper.dwc_sensors_cts.en_x_chk 1'b0
# for preload Si Fuji-AE code
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uINTROM.CRC_SKIP 1'b1
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uSI_SS_HLB.uSI_SS.uOCMAD.si_ocmad_auto_init_dis 1'b0
# R0.1 Avoid X propergation to CPU_SS/RT_SS irq inputs signals.
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.ucr_rdr_ss.rdr_noise_est_irq 1'b0
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.ucr_rdr_ss.rdr_ipi_err_irq 1'b0
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.ucr_rdr_ss.rdr_sram_err_irq 1'b0
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.ucr_isp_ss.vse_int_dw200_fe_int 1'b0
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_S_TOP.uSCLST_S.ucr_efpga_ss.u_efss.u_efpga_wrap.o_efpga_glb_out_irq\[15:0\] 16'h0
# DDR PHY FF initialize.
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d0_d 0 -deposit
    #ZEBU#catch_force_opt TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.uSNIDDRL5XS_PHY_MTST_WRP.udwc_lpddr5xphy_top.pub_top.tub.iccm_wr_d1_d 0 -deposit
}

# Avoid X propergation to NOC_CENTRAL inputs signals.
proc tmp_force_NOC_CENTRAL_INPUT {} {
  puts "The X propergation of NOC input has already resolved with R0.1. (NOC_CENTRAL EAST)"
}

proc tmp_force_NOC_CENTRAL_EAST_INPUT {} {
  puts "The X propergation of NOC input has already resolved with R0.1. (NOC_CENTRAL EAST)"
}


proc tmp_force_NOC_CENTRAL_WEST_INPUT {} {
  puts "The X propergation of NOC input has already resolved with R0.1. (NOC_CENTRAL WEST)"
}

# Avoid X propergation to NOC_MEM inputs signals.
proc tmp_force_NOC_MEM_INPUT {} {
  puts "The X propergation of NOC input has already resolved with R0.1. (NOC_MEM)"
# The following NOC input signals ​​(ddrphy pready,pslver) are stable after CLK is supplied.
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PREADY_ddr2_phy_ctst_m 1'b1
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PREADY_ddr3_phy_ctst_m 1'b1
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PREADY_ddr4_phy_ctst_m 1'b1
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PREADY_ddr5_phy_ctst_m 1'b1
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PSLVERR_ddr2_phy_ctst_m 1'b0
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PSLVERR_ddr3_phy_ctst_m 1'b0
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PSLVERR_ddr4_phy_ctst_m 1'b0
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.PSLVERR_ddr5_phy_ctst_m 1'b0
}

# Avoid X propergation to NOC_MPU inputs signals.
proc tmp_force_NOC_MPU_INPUT {} {
  puts "The X propergation of NOC input has already resolved with R0.1. (NOC_MPU)"
# The following NOC input signals ​​(ddrphy pready,pslver) are stable after CLK is supplied.
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uNOC_MPU.PREADY_ddr0_phy_ctst_m 1'b1
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uNOC_MPU.PREADY_ddr1_phy_ctst_m 1'b1
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uNOC_MPU.PSLVERR_ddr0_phy_ctst_m 1'b0
#    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uNOC_MPU.PSLVERR_ddr1_phy_ctst_m 1'b0
}

# Avoid X propergation to CPU_SS irq inputs signals.
proc tmp_force_CPU_SS_IRQ_INPUT {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uPCIE_SS_PCIA_pcie0_msi_int_10 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.ucr_ml_ss.mlss_gia_crmla1_mbox_ext_irq\[63:0\] 0
}

# CPU_SS Bug work around. #44728#note-3 updated for zebu
proc tmp_force_NOC_CPU_ADDRESS_MASK {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CPU_NOC_TOP.noc_mpu_ddr_prog_paddr\[31:27\] 5'h15  -freeze;
}

# CPU_SS Bug work around. #44728#note-3 for Chiplet1
proc tmp_force_NOC_CPU_ADDRESS_MASK_CHP1 {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CPU_NOC_TOP.noc_mpu_ddr_prog_paddr\[31:27\] 5'h1D -freeze;
}

# CPU_SS Bug work around. #44728#note-3 for Chiplet1
proc tmp_force_NOC_CPU_ADDRESS_MASK_CHIPLET1 {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP_chiplet1.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CPU_NOC_TOP.noc_mpu_ddr_prog_paddr\[31:27\] 5'h1D -freeze;
}

# CPU_SS CMN PSTATE_LOGIC set updated for zebu 
proc tmp_force_CMN_PSTATE_LOCGC {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CMN_TOP.CMN_PREQ_LOGIC 0 -freeze;
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CMN_TOP.CMN_PSTATE_LOGIC\[4:0\] 0 -freeze;
    run 5us
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CMN_TOP.CMN_PSTATE_LOGIC\[4:0\] 5'h18 -freeze;
}

# DDR CLK gate, to avoid SRAM warning message.
proc tmp_force_DDR_DFICLK_GATE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
}

proc tmp_force_DDR_C0C1_DFICLK_GATE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uCRG_DDR.sig_uCRG_DDR_CSR_WRAP_CLKEN\[31:0\] 0
}

proc tmp_force_NOC_SYS_INPUT {} {
  puts "The X propergation of NOC input has already resolved with R0.1. (NOC_SYS)"
}

proc tmp_force_CRG_AON_RESET_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uCRG_AON.uCRG_AON_CSR_WRAP.SWRESETn_A\[21:0\] 22'h3fffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uCRG_AON.uCRG_AON_CSR_WRAP.SWRESETn_PO\[3:0\] 4'hf
}

proc tmp_force_CRG_HSIF_RESET_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uCRG_HSIF.uCRG_HSIF_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uCRG_HSIF.uCRG_HSIF_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_PERI_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uPERI_SS_HLB.uCRG_PERI.uCRG_PERI_CSR_WRAP.SWRESETn_A_WORM\[63:0\] 64'hffffffffffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uPERI_SS_HLB.uCRG_PERI.uCRG_PERI_CSR_WRAP.SWRESETn_A_WRM\[63:0\] 64'hffffffffffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uPERI_SS_HLB.uCRG_PERI.uCRG_PERI_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_MPU_RESET_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uCRG_MPU.uCRG_MPU_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uCRG_MPU.uCRG_MPU_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_CPU_PERI_RELEASE {} {
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CRG_CPU_PERI.uCRG_CPU_PERI_CSR_WRAP.SWRESETn_A 1'b1
    catch_force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_CPU_SS_TOP.U_CPU_SS.U_CRG_CPU_PERI.uCRG_CPU_PERI_CSR_WRAP.SWRESETn_PO 1'b1
}

proc tmp_force_CRG_UCIE_0_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_UCIE_0.U_CRG_UCIE_C.uCRG_UCIE_C_CSR_WRAP.SWRESETn_A\[8:0\] 9'h1ff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_UCIE_0.U_CRG_UCIE_C.uCRG_UCIE_C_CSR_WRAP.SWRESETn_PO 1'b1
}

proc tmp_force_CRG_UCIE_1_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_UCIE_1.U_CRG_UCIE_C.uCRG_UCIE_C_CSR_WRAP.SWRESETn_A\[8:0\] 9'h1ff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.ucpu_ss_design_top.U_UCIE_1.U_CRG_UCIE_C.uCRG_UCIE_C_CSR_WRAP.SWRESETn_PO 1'b1
}

proc tmp_force_CRG_UCIE_NC_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uucie_ss_hlb.u_CRG_UCIE_NC.uCRG_UCIE_NC_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uucie_ss_hlb.u_CRG_UCIE_NC.uCRG_UCIE_NC_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_CNOC_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_CNOC.uCRG_CNOC_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_CNOC.uCRG_CNOC_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DSP_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_DSP.uCRG_DSP_CSR_WRAP.SWRESETn_A\[31:0\] 32'hfffffff4
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_DSP.uCRG_DSP_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_EF_TDM_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_EF_TDM.uCRG_EF_TDM_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_EF_TDM.uCRG_EF_TDM_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_ISP.uCRG_ISP_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_ISP.uCRG_ISP_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_RDR_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_RDR.uCRG_RDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_RDR.uCRG_RDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_VC9000_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_VC9000.uCRG_VC9000_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uNOC_CENTRAL.uNOC_CENTRAL_FLAT.uCRG_SENS.uCRG_VC9000.uCRG_VC9000_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_ETH_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_eth_ss.ENET_PLL0.uCRG_ETH_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_eth_ss.ENET_PLL0.uCRG_ETH_CSR_WRAP.SWRESETn_PO\[31:0\] 32'hffffffff
}

proc tmp_force_CRG_MEM_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.uNOC_MEM_FLAT.uCRG_MEM.uCRG_MEM_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uNOC_MEM.uNOC_MEM_FLAT.uCRG_MEM.uCRG_MEM_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_ML_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.ucr_ml_ss.u_crmla1_crg.u_crmla1_crg.uCRG_ML_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
}

proc tmp_force_CRG_RT_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uCRG_RT.rt_ss_rst_n 1'b1
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uCRG_RT.rtss_axi_rst_n 1'b1
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uCRG_RT.rt_sys_rst_n 1'b1
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uCRG_RT.crg_rt_rst_n 1'b1
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uCRG_RT.uCRG_RT_CSR_WRAP.SWRESETn_A\[63:0\] 64'hffffffffffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uRT_SS_HLB.uRT_SS_WRAP.uCRG_RT.uCRG_RT_CSR_WRAP.SWRESETn_PO\[31:0\] 32'hffffffff
}

proc tmp_force_EFPGA_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.ucr_efpga_ss.efss_cnoc_efpgao_strmi_axi_rst_n 1'b1
}

proc tmp_force_CRG_PCIE_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uPCIE_SS.uPCIE_MAIN.uCRG_PCIE.uCRG_PCIE_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_S_TOP.uSCLST_S.uPCIE_SS.uPCIE_MAIN.uCRG_PCIE.uCRG_PCIE_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DDR_SS_C0_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DDR_SS_C1_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DDR_SS_NC0_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DDR_SS_NC1_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DDR_SS_NC2_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_CRG_DDR_SS_NC3_RELEASE {} {
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_A\[31:0\] 32'hffffffff
    force TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uCRG_DDR.uCRG_DDR_CSR_WRAP.SWRESETn_PO\[1:0\] 2'b11
}

proc tmp_force_ALL_SS_RELEASE {} {
    tmp_force_CRG_AON_RESET_RELEASE
    tmp_force_CRG_HSIF_RESET_RELEASE
    tmp_force_CRG_PERI_RELEASE
    tmp_force_CRG_MPU_RESET_RELEASE
    tmp_force_CRG_CPU_PERI_RELEASE
    tmp_force_CRG_UCIE_0_RELEASE
    tmp_force_CRG_UCIE_1_RELEASE
    tmp_force_CRG_UCIE_NC_RELEASE
    tmp_force_CRG_CNOC_RELEASE
    tmp_force_CRG_DSP_RELEASE
    tmp_force_CRG_EF_TDM_RELEASE
    tmp_force_CRG_RDR_RELEASE
    tmp_force_CRG_VC9000_RELEASE
    tmp_force_CRG_ETH_RELEASE
    tmp_force_CRG_MEM_RELEASE
    tmp_force_CRG_ML_RELEASE
    tmp_force_CRG_RT_RELEASE
    tmp_force_EFPGA_RELEASE
}
