#--------------------------------------------------------------------
# common procedure definition file
#--------------------------------------------------------------------

# for denali lpddr5
proc ddr_dump {ddr_ch dump_file} {
  puts "TCL_D : Dumpping : ${dump_file}_ch${ddr_ch}_rank\[01\]_dev\[01\].dat"
  run_dump ${ddr_ch} 0 0 ${dump_file}
  run 1 ns
}

# for micron lpddr5
proc trg_dump {ddr_ch s_addr e_addr dump_file} {
  puts "TCL_D : Dumpping ${s_addr}-${e_addr} : ${dump_file}_ch${ddr_ch}_dev\[01\].dat"
  run_dump ${ddr_ch} ${s_addr} ${e_addr} ${dump_file}
  run 1 ns
}

# for denali/micron lpddr5
proc run_dump {ddr_ch s_addr e_addr dump_file} {
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.enable_dump\[${ddr_ch}\] 1'b1
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.addr_min $s_addr
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.addr_max $e_addr
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.trig_dump 1'b1
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.trig_dump 1'b0
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.enable_dump\[${ddr_ch}\] 1'b0
  # for denali 16bit rank0
  if { [ file isfile dump_ddr_ch${ddr_ch}_rank0_dev0.dat ] == 1 } then {
    exec mv dump_ddr_ch${ddr_ch}_rank0_dev0.dat ${dump_file}_ch${ddr_ch}_rank0_dev0.dat
    exec mv dump_ddr_ch${ddr_ch}_rank0_dev1.dat ${dump_file}_ch${ddr_ch}_rank0_dev1.dat
  }
  # for denali 16bit rank1
  if { [ file isfile dump_ddr_ch${ddr_ch}_rank1_dev0.dat ] == 1 } then {
    exec mv dump_ddr_ch${ddr_ch}_rank1_dev0.dat ${dump_file}_ch${ddr_ch}_rank1_dev0.dat
    exec mv dump_ddr_ch${ddr_ch}_rank1_dev1.dat ${dump_file}_ch${ddr_ch}_rank1_dev1.dat
  }
  # for denali 8bit rank0
  if { [ file isfile dump_ddr_ch${ddr_ch}_rank0_dev2.dat ] == 1 } then {
    exec mv dump_ddr_ch${ddr_ch}_rank0_dev2.dat ${dump_file}_ch${ddr_ch}_rank0_dev2.dat
    exec mv dump_ddr_ch${ddr_ch}_rank0_dev3.dat ${dump_file}_ch${ddr_ch}_rank0_dev3.dat
  }
  # for denali 8bit rank1
  if { [ file isfile dump_ddr_ch${ddr_ch}_rank1_dev2.dat ] == 1 } then {
    exec mv dump_ddr_ch${ddr_ch}_rank1_dev2.dat ${dump_file}_ch${ddr_ch}_rank1_dev2.dat
    exec mv dump_ddr_ch${ddr_ch}_rank1_dev3.dat ${dump_file}_ch${ddr_ch}_rank1_dev3.dat
  }
  # for micron 16bit
  if { [ file isfile dump_ddr_ch${ddr_ch}_dev0.dat ] == 1 } then {
    exec mv dump_ddr_ch${ddr_ch}_dev0.dat ${dump_file}_ch${ddr_ch}_dev0.dat
    exec mv dump_ddr_ch${ddr_ch}_dev1.dat ${dump_file}_ch${ddr_ch}_dev1.dat
  }
  # for micron 8bit
  if { [ file isfile dump_ddr_ch${ddr_ch}_dev2.dat ] == 1 } then {
    exec mv dump_ddr_ch${ddr_ch}_dev2.dat ${dump_file}_ch${ddr_ch}_dev2.dat
    exec mv dump_ddr_ch${ddr_ch}_dev3.dat ${dump_file}_ch${ddr_ch}_dev3.dat
  }
  run 1 ns
}


# for zebu lpddr5
proc trg_load_zebu {ddr_ch TEST_CASE ld_file} {
    puts "TCL_D : load LPDDR5 #${ddr_ch}"
    set file_r0_d0 "../testcase/${TEST_CASE}/testcase/CS_Hunter-AE/${ld_file}.rank0_dev0.dat";
    set file_r0_d1 "../testcase/${TEST_CASE}/testcase/CS_Hunter-AE/${ld_file}.rank0_dev1.dat";
    set file_r1_d0 "../testcase/${TEST_CASE}/testcase/CS_Hunter-AE/${ld_file}.rank1_dev0.dat";
    set file_r1_d1 "../testcase/${TEST_CASE}/testcase/CS_Hunter-AE/${ld_file}.rank1_dev1.dat";
## DDR path:
   #DDR0
#TBENCH.uOMNITOP_WRAP.uOMNITOP.uOMNICORE.uLP5_CLUSTER0.uDDR_CPU_SS0.uSNIDDRL5XS_MCS3_WRP_0_0.ins_lpddr5_dfi0.zlpddr5.analyzer_en
set ddr0_0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi0.zlpddr5.mem_core_sp.mem_logic
set ddr0_1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi1.zlpddr5.mem_core_sp.mem_logic
set ddr0_2 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi2.zlpddr5.mem_core_sp.mem_logic
set ddr0_3 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi3.zlpddr5.mem_core_sp.mem_logic
  #DDR1
## DDR path:
set ddr1_0 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi0.zlpddr5.mem_core_sp.mem_logic
set ddr1_1 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi1.zlpddr5.mem_core_sp.mem_logic
set ddr1_2 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi2.zlpddr5.mem_core_sp.mem_logic
set ddr1_3 TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.ins_lpddr5_dfi3.zlpddr5.mem_core_sp.mem_logic

    puts "Loading Cluster0 DDR memory"
    memory -load $ddr0_0 -file $file_r0_d0 -radix hexa;
    memory -load $ddr0_1 -file $file_r0_d1 -radix hexa;
    memory -load $ddr0_2 -file $file_r1_d0 -radix hexa;
    memory -load $ddr0_3 -file $file_r1_d1 -radix hexa;
}

proc prog_load_zebu {ddr_ch ld_file} {
  puts "TCL_D : after detecting ddr_init_complete, load code LPDDR5 #${ddr_ch}"
}


# for denali/micron lpddr5
proc trg_load {ddr_ch ld_file} {
  puts "TCL_D : load LPDDR5 #${ddr_ch}"
  # for 16bit
  if { [ file isfile ${ld_file}.rank0_dev0.dat ] == 1 } then {
    exec mv ${ld_file}.rank0_dev0.dat load_ch${ddr_ch}_rank0_dev0.dat
    exec mv ${ld_file}.rank0_dev1.dat load_ch${ddr_ch}_rank0_dev1.dat
    exec mv ${ld_file}.rank1_dev0.dat load_ch${ddr_ch}_rank1_dev0.dat
    exec mv ${ld_file}.rank1_dev1.dat load_ch${ddr_ch}_rank1_dev1.dat
  }
  # for 8bit
  if { [ file isfile ${ld_file}.rank0_dev2.dat ] == 1 } then {
    exec mv ${ld_file}.rank0_dev2.dat load_ch${ddr_ch}_rank0_dev2.dat
    exec mv ${ld_file}.rank0_dev3.dat load_ch${ddr_ch}_rank0_dev3.dat
    exec mv ${ld_file}.rank1_dev2.dat load_ch${ddr_ch}_rank1_dev2.dat
    exec mv ${ld_file}.rank1_dev3.dat load_ch${ddr_ch}_rank1_dev3.dat
  }
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.enable_load\[${ddr_ch}\] 1'b1
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.trig_load\[${ddr_ch}\] 1'b1
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.trig_load\[${ddr_ch}\] 1'b0
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.enable_load\[${ddr_ch}\] 1'b0
  run 1 ns
}

# for denali/micron lpddr5, but can not use this proc due to not complete MR register setting.
proc prog_load {ddr_ch ld_file} {
  puts "TCL_D : after detecting ddr_init_complete, load code LPDDR5 #${ddr_ch}"
  # for 16bit
  if { [ file isfile ${ld_file}.rank0_dev0.dat ] == 1 } then {
    exec mv ${ld_file}.rank0_dev0.dat load_code_ch${ddr_ch}_rank0_dev0.dat
    exec mv ${ld_file}.rank0_dev1.dat load_code_ch${ddr_ch}_rank0_dev1.dat
    exec mv ${ld_file}.rank1_dev0.dat load_code_ch${ddr_ch}_rank1_dev0.dat
    exec mv ${ld_file}.rank1_dev1.dat load_code_ch${ddr_ch}_rank1_dev1.dat
  }
  # for 8bit
  if { [ file isfile ${ld_file}.rank0_dev2.dat ] == 1 } then {
    exec mv ${ld_file}.rank0_dev2.dat load_code_ch${ddr_ch}_rank0_dev2.dat
    exec mv ${ld_file}.rank0_dev3.dat load_code_ch${ddr_ch}_rank0_dev3.dat
    exec mv ${ld_file}.rank1_dev2.dat load_code_ch${ddr_ch}_rank1_dev2.dat
    exec mv ${ld_file}.rank1_dev3.dat load_code_ch${ddr_ch}_rank1_dev3.dat
  }
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.enable_load\[${ddr_ch}\] 1'b1
  run 1 ns
}

# for denali/micron lpddr5
proc enable_ddr_phy_ram_load {enb_bit} {
  puts "TCL_D : enable ddr phy ram data load, enable bit : ${enb_bit}"
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.enable_phy_ram_load\[5:0\] ${enb_bit}
}

# for denali/micron lpddr5
proc wait_for_dram_load {} {
  puts "TCL_D : run to CPU ddr_load H edge"
  run -rising TBENCH.uDRAM_WRP.lpddr5_dumpload.preload_timing
}

# for denali/micron lpddr5
proc wait_for_dram_dump {} {
  puts "TCL_D : run to CPU ddr_dump H edge"
  run -rising TBENCH.uDRAM_WRP.lpddr5_dumpload.dump_timing
}

# for denali/micron lpddr5
proc exe_proc_wait_for_dram_dump {cmd} {
  puts "TCL_D : stop by CPU ddr_dump H edge then excute command : ${cmd}"
  stop -once -condition { TBENCH.uDRAM_WRP.lpddr5_dumpload.dump_timing == 1'b1 } -command ${cmd}
}

# for micron lpddr5
proc memory_init_load {ddr_ch val rand} {
  puts "TCL_D : unwritten memory value set, set LPDDR5 #${ddr_ch} val:${val} random:${rand}"
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.load_value $val
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.random_value $rand
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.memory_init_load\[${ddr_ch}\] 1'b1
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.memory_init_load\[${ddr_ch}\] 1'b0
  run 1 ns
}

# for denali lpddr5
proc denali_lpddr5_addressmap_linkecc_off {ddr_ch} {
  puts "TCL_D : Denali LPDDR5 Address Map changes LinkECC OFF, set LPDDR5 #${ddr_ch}"
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.inlineecc_disable_memory\[${ddr_ch}\] 1'b1
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.inlineecc_disable 1'b1
  run 1 ns
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.inlineecc_disable 1'b0
  force TBENCH.uDRAM_WRP.lpddr5_dumpload.inlineecc_disable_memory\[${ddr_ch}\] 1'b0
  run 1 ns
}

proc disable_tarmac {} {
#  run 1 us
#  force TBENCH.g_FUJI_AE_cpu\[0\].u_FUJI_AE_noram.u_follower.tarmac_enable 1'b0
#  run 10 us
}

proc enable_tarmac {} {
#run 10 us
#  force TBENCH.g_FUJI_AE_cpu\[0\].u_FUJI_AE_noram.u_follower.tarmac_enable 1'b1
#run 1 us
}

set catch_force_err_print 1
proc catch_force {sig val} {
  global catch_force_err_print
  if { [catch {force $sig $val} err_msg] } {
    if { $catch_force_err_print == 1 } {
      puts "TCL pseudo error $err_msg : $sig"
    }
  }
}


