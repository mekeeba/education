#--------------------------------------------------------------------
#
#--------------------------------------------------------------------

#set TCL_PATH ../testcase/$ simdata/zebu/tcl
set TCL_PATH ../testcase/$TEST_CASE/simdata/tcl

# <<This run sequence is refer to the UVM.>>
puts "TB_DETECT_PSEUDO_ERR_MASK_START"
# Phase 1 Reset
source ${TCL_PATH}/phase_reset.tcl
# Phase 2 Configure
source ${TCL_PATH}/phase_configure.tcl
# Phase 3 Main
source ${TCL_PATH}/phase_main.tcl
# Phase 4 Shutdown
source ${TCL_PATH}/phase_shutdown.tcl

# simulation end
#exit
