#! /bin/csh -f 

################################################################
### Check to see if the input ZTDB was used
################################################################
set input_ztdb = $argv
if (! $?input_ztdb) then       
  echo "Input ZTDB Is Undefined"
  exit 1
else
  if ("$input_ztdb" == "")  then
      echo "Input ZTDB Is Empty Exiting"
      exit 1
  else 
      echo "Using Input ZTDB $input_ztdb"
  endif
endif

# Run SimZilla command
set output_fsdb = `echo $input_ztdb | gawk -F"." '{print $1}'`_zSimzilla.fsdb
set output_zwd = `echo $input_ztdb | gawk -F"." '{print $1}'`_zSimzilla.zwd
set output_log = `echo $input_ztdb | gawk -F"." '{print $1}'`_zSimzilla.log
#xterm -hold -T "zSimzilla Conversion Xterm" -e "zSimzilla --zebu-work $ZEBU_WORK --ztdb $input_ztdb --fsdb $output_fsdb --timescale 1ns" &

#set GRID_CMD = "qrsh -V -P zebucae -cwd -now n -verbose -l h_rt=7200,mem_free=50G -pe mt 10" 
#set GRID_CMD = '"qrsh -V -P zebucae -cwd -now n -verbose -noshell -l mem_free=32G -pe mt 4"'

#zSimzilla --zebu-work $ZEBU_WORK --ztdb $input_ztdb --fsdb $output_fsdb --timescale 1ns --threads 10 --jobs 10000 --command "qrsh -V -P zebucae -cwd -now n -verbose -l h_rt=7200,mem_free=50G -pe mt 10" --log zSim_fsdb.log
#zSimzilla --zebu-work $ZEBU_WORK --ztdb $input_ztdb --fsdb $output_fsdb --timescale 1ns --threads 10 --jobs 10000 --command "qrsh -V -P zebucae -cwd -now n -verbose -noshell -l mem_free=32G -pe mt 4" --log zSim_fsdb.log

#qrsh -P zebucae -l mem_free=64G -cwd -V -noshell -now no -verbose -pe mt 8 zSimzilla --threads 8 --jobs 20 -z $ZEBU_WORK -i $input_ztdb --zwd $output_zwd --timescale 1ns --log $output_log -c "qrsh -P zebucae -l mem_free=64G -cwd -V -noshell -now no -verbose -pe mt 8"

#bsub -app comp_zebucae -I -R "rusage[mem=64G]" zSimzilla --threads 8 --jobs 20 -z $ZEBU_WORK -i $input_ztdb --fsdb $output_fsdb --timescale 1ns --log $output_log -c 'bsub -app comp_zebucae -I -R "rusage[mem=64G]"'
bsub -app comp_zebucae -I -R "rusage[mem=64G]" zSimzilla --threads 8 --jobs 20 -z $ZEBU_WORK -i $input_ztdb --zwd $output_zwd --timescale 1ns --log $output_log -c 'bsub -app comp_zebucae -I -R "rusage[mem=64G]"'
