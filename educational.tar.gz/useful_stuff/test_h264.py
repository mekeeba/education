#import some required standard Python modules
import time, os
#import the Regression Test infrastructure
import vdk_test_infra
from os import path

# Helper utility for debug output
def dbg( s ):
    print(s)

def run_video():
    print("Linaro-2014.10 Booted : O.K. \n")
    uart1 = vpx.get_node("/H264/Motherboard_ARM_Base/UART0_PHY")
    uart1.send_command('push "cd scripts \n" ')
    uart1.send_command('push "./run \n" ')
    vpx.remove_all_breakpoints()
    print("Running Video using VideoOut transactor \n")

def on_sim_crunch():
    global uart_phy
    global bp_running
    print('MEASURING: Sim crunch')
    vpx.remove_breakpoints([bp_crunch])
    uart_phy = vpx.get_node('/H264/Motherboard_ARM_Base/UART0_PHY')
    bp_running = vpx.create_time_breakpoint(1)
    bp_running.set_callback('on_sim_running()')

def on_sim_running():
    global bp_match
    print('MEASURING: Sim running')
    vpx.remove_breakpoints([bp_running])
    print("creating UART match breakpoint")
    bp_match = vpx.create_breakpoint('update','/H264/Motherboard_ARM_Base/UART0_PHY/string_match_detected')
    bp_match.set_callback('on_uart_string()')
 
def on_uart_string():
    global the_match_strings
    mstr = the_match_strings[0]
    the_match_strings = the_match_strings[1:]
    print('MEASURING: UART string "%s" detected, (next up "%s")'%(mstr,(the_match_strings[0] if len(the_match_strings) else '<empty>')))
    print_stats()
    if mstr == 'root@genericarmv8:~#':
        uart_phy.send_command(['push','cd scripts\n'])
        uart_phy.send_command(['push','./run\n'])

#################### Test Classes #########################
class hybrid_test(vdk_test_infra.VDKTestBase):
    
    def before_test_run(self, vpconfig):
        self.report("Initialization Done")
        vpconfig.set_environment_variable('SNPS_VP_PROFILE','1')

    #This function runs the test
    def test_run(self):
        
        # The simulation launch is complete
        #in_c = vpx.create_breakpoint("initial_crunch" )
        #vpx.wait_interrupted()
        #assert in_c.is_hit()
        #vpx.continue_simulation()
        #bp_crunch = vpx.create_breakpoint('initial_crunch')
        #bp_crunch.set_callback('on_sim_crunch()')

        start_real_time = time.time()
        start_sim_time = float(vpx.get_current_time_int()) / 1000000000000.0
        # Check that we reached Initial Crunch
        # Continue Simulation
        # Check that Linux has booted OK 
        # Send commands to UART/LCD ? => To run the video (cd scripts/run.sh)
        # Check that the video is actually been displayed in the video XTOR
        # Stop Simulation
        # Close simulation and print report
        #vpx.continue_simulation()
        #bp1 = vpx.create_sw_breakpoints("/H264/CPU_SS/ARM_CPU_SS/CLUSTER_0/cpu0", "0xffffffc0000920c8")
        bp1 = vpx.create_time_breakpoint(21, 's')
        bp1.set_callback("run_video()")
        #bp1[0].set_callback( "run_video(__sim__)" )
        #dbg( "created breakpoint " + bp1[0].get_symbolic_name() )
        
        vpx.runfor("50 s")

        end_real_time = time.time()
        end_sim_time = float(vpx.get_current_time_int()) / 1000000000000.0
        elapsed_real_time = end_real_time - start_real_time
        elapsed_sim_time = end_sim_time - start_sim_time
        #rtf = elapsed_real_time / elapsed_sim_time
        print("Benchmark complete: ")
        print(" Elapsed Real Time [s]: " + str(elapsed_real_time))
        print(" Elapsed Sim Time [s]: " + str(elapsed_sim_time))
        #print(" RTF: " + str(rtf))
        vpx.stop_simulation()

    def after_test_run(self, vpconfig):
        self.report("Carry out some post-test actions")


def run(vdk_name, vpconfig_name):

    vdk = vdkcreator.load(vdk_name)
    vpconfig = vdk.get_vp_config(vpconfig_name)
    benchmark = MyBenchmark()
    benchmark.before_test_run(vpconfig)
    vpconfig.run(False)
    benchmark.test_run()
    # Reverting VPConfig changes
    vpconfig.reset()
    vpconfig.dispose()