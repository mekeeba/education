#! /bin/csh -f

set VLOGAN_OPTIONS=( -full64 -sverilog) 

# Enabme Hybrid
if ( "$CRZ_ZEBU_HYBRID" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+ZEBU_HYBRID)
endif

# Using Zebu default ZRM
if ( "$CRZ_HYBRID_FASTMEM" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+ZRM_FASTMEM)
endif

# Selecting DDR CLUSTER 0
if ( "$CRZ_DDR_CLUSTER0" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+DDR_CLUSTER0)
endif

# Selecting DDR CLUSTE 1
if ( "$CRZ_DDR_CLUSTER1" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+DDR_CLUSTER1)
endif

# Selecting PCIE
if ( "$CRZ_PCIE" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_PCIE)
endif

# Selecting MLA
if ( "$CRZ_MLA" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_MLA)
endif

# Selecting SI
if ( "$CRZ_SI" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_SI)
endif

# Selecting UCIE
if ( "$CRZ_UCIE" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_UCIE)
endif

# Selecting HUNTER CPU
if ( "$CRZ_CPU_SS" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_HUNTER_CPU)
endif

# Selecting ETH
if ( "$CRZ_ETH" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_ETH)
endif

# Selecting ISP
if ( "$CRZ_ISP" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_ISP)
endif

# Selecting RDR
if ( "$CRZ_RDR" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_RDR)
endif

# Selecting DSP
if ( "$CRZ_DSP" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_DSP)
endif

# Selecting RT
if ( "$CRZ_RT" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_RT)
endif

# Selecting PERI
if ( "$CRZ_PERI" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_PERI)
endif

# Fastmem DDR cluster 0
if ( "$CRZ_FM_DDR_SS_0" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+FM_DDR_SS_0)
endif

# Fastmem DDR cluster 1
if ( "$CRZ_FM_DDR_SS_1" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+FM_DDR_SS_1)
endif

# Fastmem
if ( "$CRZ_XTOR_FASTMEM" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_XTOR_FASTMEM)
endif

# MIPI Xtors
if ( "$CRZ_XTOR_MIPI" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_XTOR_MIPI)
endif

# ETHERNET Xtors
if ( "$CRZ_XTOR_ETH" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_XTOR_ETH)
endif

# AMBA Xtors
if ( "$CRZ_XTOR_AMBA" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_XTOR_AMBA)
endif

# VC9000
if ( "$CRZ_VC9000" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_VC9000)
endif

# TDM EFUSE
if ( "$CRZ_EF_TDM" == "YES") then
	set VLOGAN_OPTIONS = ($VLOGAN_OPTIONS +define+CRZ_EF_TDM)
endif


vlogan ${VLOGAN_OPTIONS} \
       -work work \
       +error+1000 \
       -error=noMPD \
       +libext+.svh+.vh+.sv+.v+.vp+.svp \
       +warn=ZEBUUC-XMRTRAN-NYIIA  \
       +incdir+$DIR_TB_ROOT/02_model/DDR \
       -skip_translate_body=pragma+synopsys \
       -l $VCS_LOG_DIR/vlogan_TBENCH.log \
       -zebu_string \
       +v2k \
       +define+DUMP_LEVEL=$DUMP_LEVEL \
       +define+ZRM_NEW_LATENCY \
       +define+EMU \
       +define+EMULATION \
       +define+HW_ZEBU \
       +define+CRG_SRR_CRESET_ON \
       +define+CRUISE_FPGA \
       +define+USE_ZEBU_IP \
       +define+ZEBU_NO_RTB \
       +define+ZEBU_SYNTH \
       +define+SNPS_ZHAL_ZRM_MIN_DYN_LAT=1 \
       -timescale=1ns/1ps \
       -file $DIR_TB_ROOT/03_filelist/TOP_EMU.f \
       -file $DIR_TB_ROOT/03_filelist/TBENCH_EMU.f \
       $DESIGN_SRC/patches/dumpvars.sv \
       $DESIGN_SRC/patches/usermod.sv \
       $DESIGN_SRC/patches/RESET.v \
       $DESIGN_SRC/patches/zebu_clkgen.sv \
       $DESIGN_SRC/patches/snps_gtech.v \
       $DESIGN_SRC/patches/cdc_sync_rstn_ckg.sv \
       $DESIGN_SRC/patches/prj_mux.sv \
       $DESIGN_SRC/patches/prj_clk_gate.sv \
       $CDN_CPUSS_DIR/dev/design/ip/emu_bbox/ABKRTAL2A.v \
       $CDN_CPUSS_DIR/dev/design/ip/emu_bbox/ABKRTAL3A.v \
       $DIR_TB_ROOT/02_model/apb_tube/apb_tube.v \
       $DIR_TB_ROOT/02_model/apb_tube/tubeRAM.v \
       $DESIGN_SRC/patches/bind_apb_tube_wrap_si_fuji.sv \
       $DESIGN_SRC/patches/bind_apb_tube_wrap_rt_fuji.sv \
       $DESIGN_SRC/patches/bind_apb_tube_wrap_cs_hunter.sv \
       $DESIGN_SRC/patches/TBENCH.sv
