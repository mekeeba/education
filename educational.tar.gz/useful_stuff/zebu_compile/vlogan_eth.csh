#! /bin/csh -f

vlogan -full64 \
       -sverilog \
       +error+1000 \
       -error=noMPD \
       -work ETH \
       +libext+.svh+.vh+.sv+.v+.vp+.svp \
       +warn=ZEBUUC-XMRTRAN-NYIIA  \
       -skip_translate_body=pragma+synopsys \
       -l $VCS_LOG_DIR/vlogan_ETH.log \
       +v2k \
       -timescale=1ns/1ps \
       -file $DIR_TB_ROOT/03_filelist/emu_syn_fl/eth_emu_syn_vlg.f \
       +define+HW_ZEBU \
       +define+CRUISE_FPGA
