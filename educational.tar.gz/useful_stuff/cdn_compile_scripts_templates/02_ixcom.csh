#! /bin/csh -f

source ./setup.csh
source ./avip_setup.csh

unsetenv XCELIUM_INCISIVE_COMPATIBILITY_MODE
unsetenv XE_HOST_FILE

setenv EXAMPLE_DIR ${AVIP_ROOT}/cdn_usb_avip/examples/tba/USB3.1/otg/pureC/cdn_usb31_otgH_otgD_UASP_test
unsetenv F_FILES_DIR
setenv F_FILES_DIR ${EXAMPLE_DIR}/avip_run_scripts/xm_hwRun_pd_dpi_f_files

setenv HDL_IXC_INLINE 1
setenv XE_ALT_XLM 1

ixcom \
  +sv \
  +1xua \
  -ua \
  -timescale 1fs/1fs \
  -rtlchk warn \
  -top WORK.cfg_TBENCH \
  -top WORK.emu_clkgen \
  +xe_alt_xlm \
  +dut+TBENCH+emu_clkgen+mt35xu02g \
  -externalNetlist nl-config.spec \
  +hwOnlyRtlTop+mt35xu02g \
  -xmelabargs "-warn_multiple_driver" \
  +gfifoDisp+jedec_lpddr5x_x8_16Gb+jedec_lpddr5x_16Gb+edge_detection_monitor+creg \
  +enableDispInLoopBC+creg \
  +tran_relax \
  -64 \
  -xmelabargs "-vhdlsparsearray 1000000" \
  -xmvhdlargs "-vhdlsparsearray 1000000" \
  +max_error_count+10000 \
  +rtlCommentPragma \
  -enablePkgSearch \
  -vaelabargs "-parallel 2" \
  -xmvlogargs "-delay_trigger" \
  -xmelabargs "-atstar_lsp"
