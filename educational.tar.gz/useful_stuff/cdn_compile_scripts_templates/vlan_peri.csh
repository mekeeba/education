#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_PERI.log \
-work WORK_PERI \
+rtlCommentPragma \
-sv  +timescale+1ps/1ps \
+define+TRNG_BBOX \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/peri_emu_syn_vlg.f \
+libext+.v+.vp+.sv+.svp 
