#setenv SOC_OMNI_REL ""

setenv SOC_OMNI $SOC_OMNI_REL/soc-omni
setenv SOC_COMMON $SOC_OMNI_REL/soc-common
setenv SOC_TOP $SOC_OMNI

# DSP related pointers
setenv OMNI_DSPNOC_DIR $SOC_OMNI_REL/data/omni/ip/arteris/dsp_noc/20240918_noc_5_3_new_npp
setenv OMNI_Q8_DIR $SOC_OMNI_REL/data/omni/cadence/design/q8_dsp
setenv OMNI_V341_DIR $SOC_OMNI_REL/data/omni/cadence/design/v341_FS3

# ISP related pointers
setenv OMNI_ISPONOC_DIR $SOC_OMNI_REL/data/omni/ip/arteris/isp_noc_outer/20240927
setenv OMNI_ISPINOC_DIR $SOC_OMNI_REL/data/omni/ip/arteris/isp_noc_inner/20240829
setenv OMNI_ISPDUNEIP_DIR $SOC_OMNI_REL/data/omni/ip/dune
setenv OMNI_DW200_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/DW200-FS/Vivante_dw200-fs_hardware_4_1_2_rc0a_obf/rtl
setenv OMNI_JPEGE_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/JPEGENC
setenv OMNI_JPEGD_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/JPEGDEC/jpegdec_1.15
setenv OMNI_C78_DIR $SOC_OMNI_REL/data/omni/arm/Mali-C78AE/20240724/IV023-r1p0-00eac1-1/hardware/malic78ae/logical
setenv OMNI_CSI_PHY_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/MIPI_CD_RX_2T2L/N3AE
setenv OMNI_CSI_HOST_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/MIPI_CSI2/coreConsultant/i_DWC_mipi_csi2_v4_host
setenv OMNI_VC9000E_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/VC9000E/Hantro_vc9000e_hardware_3_3_0_rc0a_obf/vc9000e/hardware/
setenv OMNI_TICO_ENC_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240929/Raw_Comp/sources
setenv OMNI_TICO_DEC_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240929/Raw_De-comp/sources


#Ethernet Related pointers
setenv ETH_PHY_PATH $SOC_OMNI_REL/data/omni/synopsys/dwc_32g_phy_tsmc3eff_x4ns/20240403/gen/synopsys/dwc_32g_phy_tsmc3eff_x4ns/3.03a
setenv ETH_DW_SS_PATH $SOC_OMNI_REL/data/omni/synopsys/dwc_eth_ss/20240702
setenv ETH_PCS_PATH $SOC_OMNI_REL/data/omni/synopsys/dwc_eth_ss/20240702/cruise_omni_eco/config/Cruise_10G_i_DWC_xpcs/src
setenv ETH_MAC_PATH $SOC_OMNI_REL/data/omni/synopsys/dwc_eth_ss/20240702/cruise_omni_eco/config/cfg_Cruise_Omni_xgmac/src
setenv ETH_NOC_PATH $SOC_OMNI_REL/data/omni/ip/arteris/noc_eth_ss/20240813

# TDM_TOF 
setenv OMNI_TDTFNOC_DIR $SOC_OMNI_REL/data/omni/ip/arteris/noc_tdm_tof/20240910

# OMNI NOC - For Ethernet SS
setenv OMNI_NOC $SOC_OMNI_REL/data/omni/ip/arteris


#Achronix eFPGA
setenv OMNI_EFPGA_DIR $SOC_OMNI_REL/data/omni/sni/ip/20240903/eFPGA/N3AE/VERI

# libararies paths 
setenv OMNI_LIB_PKG $SOC_OMNI_REL/data/omni/sni/ip/20240903
#setenv SOC_LIB_PKG $OMNI_LIB_PKG
setenv OMNI_PRIMC_DIR $OMNI_LIB_PKG/PrimitiveLIB
setenv CRUISE_CRG_DIR $OMNI_LIB_PKG/CRG/omni_rtl.crg

# Memories
setenv OMNI_MEM_SYNP_DIR /data/libraries/memories/tsmc/n3ae/v0.5/synopsys/20240617
setenv OMNI_MEM_SYNP_VDIR /data/libraries/memories/tsmc/n3ae/v0.5/synopsys/20240617/VERILOG/tt_0p750v_25c_typical

