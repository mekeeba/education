#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_RT_SS.log \
-work WORK_RT_SS \
+rtlCommentPragma \
-sv  +timescale+1ps/1ps \
+define+SOC_OMNI \
+define+SYNTHESIS \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/rt_ss_emu_syn_vlg.f \
+libext+.v+.vp+.sv+.svp 
