#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_MOD_1.log \
-work WORK_MOD_1 \
-sv  +timescale+1ps/1ps \
+rtlCommentPragma \
+define+MMP_SNI_rev03_mc_reg_2 \
+define+MMP_LPDDR5_DEBUG_DISPLAY_SDL \
-v ${IXCOM_HOME}/share/vxe/etc/ixcom/IXCclkgen.sv \
-incdir ${MMP_HOME}/utils/cdn_mmp_utils/sv \
${MMP_HOME}/utils/cdn_mmp_utils/sv/cdn_mmp_utils.sv \
${DIR_TB_ROOT}/02_model/lpddr5x/jedec_lpddr5x_2x16Gb_2r_x16.v \
${DIR_TB_ROOT}/02_model/lpddr5x/jedec_lpddr5x_16Gb.vp \
+libext+.v+.vp+.sv+.svp 
