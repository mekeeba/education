#! /bin/csh -f

source ./setup.csh
source ./avip_setup.csh

unsetenv XCELIUM_INCISIVE_COMPATIBILITY_MODE
unsetenv XE_HOST_FILE

setenv XE_ALT_XLM 1

ixcom \
  +sv \
  -ua \
  -ixclkgen ixclkgen.cmd \
  -timescale 1fs/1fs \
  -rtlchk warn \
  +1xua \
  +tran_relax \
  +max_error_count+10000 \
  -enablePkgSearch \
  -xmvlogargs "-delay_trigger" \
  -xmelabargs "-atstar_lsp"

