#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_PCIE_SS.log \
-work WORK_PCIE \
+rtlCommentPragma \
-sv  +timescale+1ps/1ps \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/pcie_emu_syn_vlg.f \
+libext+.v+.vp+.sv+.svp 

