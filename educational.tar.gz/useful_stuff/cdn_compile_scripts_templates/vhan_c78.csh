#! /bin/csh -f

source ./setup.csh
source ./avip_setup.csh
source ./SourceMe.csh
unsetenv XE_HOST_FILE

ixcom -clean

vhan \
-l vhan_C78.log \
-work WORK_C78 \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/c78_emu_syn_vhdl.f
