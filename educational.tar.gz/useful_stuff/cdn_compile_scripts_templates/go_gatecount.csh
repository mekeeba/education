#!/bin/csh -f

source /sni/home/emumgr/cadence/cadtools/palladium/setup/wxe.setup

#gateCount -d 5 hdldb SI_SS_CORE | tee gateCount_SI_SS.log
#gateCount -d 5 hdldb SCP_SS | tee gateCount_SCP.log
#gateCount -d 5 hdldb PERI_SS | tee gateCount_PERI.log
#gateCount -d 5 hdldb F_USB32G2X1H | tee gateCount_USB.log
#gateCount -d 5 hdldb cr_eth_ss |tee gateCount_ETH.log
#gateCount -d 5 hdldb cr_tdtf_ss |tee gateCount_TDTF.log
#gateCount -d 5 hdldb cr_vc9000e_ss |tee gateCount_VC9000e.log
#gateCount -d 5 hdldb cpu_ss_design_top |tee gateCount_CPU_SS.log
#gateCount -d 5 hdldb SNIDDRL5XS_MCS3_WRP_0 |tee gateCount_DDR_SS_0.log
#gateCount -d 5 hdldb SNIDDRL5XS_MCS3_WRP_1 |tee gateCount_DDR_SS_1.log
#gateCount -d 8 hdldb OMNITOP |tee gateCount_TOP.log
#gateCount -d 5 hdldb cr_rt_ss |tee gateCount_RT.log
#gateCount -d 5 hdldb cr_gocm_ss |tee gateCout_GOCM.log
#gateCount -d 5 hdldb cr_ml_ss |tee gateCout_ML.log
#gateCount -d 5 hdldb cr_efpga_ss |tee gateCout_FPGA.log
#gateCount -d 5 hdldb cr_rdr_ss |tee gateCout_RDR.log
gateCount -d 5 hdldb cr_isp_ss |tee gateCout_ISP.log
