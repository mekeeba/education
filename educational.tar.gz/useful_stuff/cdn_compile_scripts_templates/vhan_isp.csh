#! /bin/csh -f

source ./setup.csh
source ./avip_setup.csh
source ./SourceMe.csh
unsetenv XE_HOST_FILE

ixcom -clean

vhan \
-l vhan_ISP.log \
-work WORK_ISP \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/cr_isp_ss_emu_syn_vhdl.f

