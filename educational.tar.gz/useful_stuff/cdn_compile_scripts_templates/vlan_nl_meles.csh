#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh

unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-netlist \
-l vlan_meles.log \
-work WORK_NL_MELES \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/meles_emu_syn_nl.f \
+libext+.v+.vp+.sv+.svp 
