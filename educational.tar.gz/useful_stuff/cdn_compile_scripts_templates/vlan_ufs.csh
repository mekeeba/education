#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_UFS_HLB.log \
-work WORK_UFS \
+rtlCommentPragma \
-sv +timescale+1ps/1ps \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/ufs_hlb_emu_syn_vlg.f \
+libext+.v+.vp+.sv+.svp 

