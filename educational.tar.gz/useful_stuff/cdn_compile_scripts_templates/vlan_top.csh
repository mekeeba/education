#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_TOP.log \
-sv  +timescale+1ps/1ps \
+rtlCommentPragma \
${IXCOM_HOME}/share/vxe/etc/ixcom/IXCclkgen.sv \
-file ${DIR_TB_ROOT}/03_filelist/TBENCH_EMU.f \
./emu_clkgen.sv \
-file ${DIR_TB_ROOT}/03_filelist/TOP_EMU.f \
-64 \
+libext+.v+.vp+.sv+.svp

