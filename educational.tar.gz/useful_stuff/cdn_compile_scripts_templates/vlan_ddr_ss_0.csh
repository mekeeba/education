#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_DDR_SS_0.log \
-work WORK_DDR_SS_0 \
-sv  +timescale+1ps/1ps \
+rtlCommentPragma \
+define+MMP_SNI_DDR_C \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/DDR_SS_C_emu_syn_vlg.f \
-incdir ${MMP_HOME}/utils/cdn_mmp_utils/sv \
${MMP_HOME}/mmp_plus/dfi/DFIPHY_5/dfiphy5_pd.vp \
${DIR_TB_ROOT}/02_model/DDR/dfiphy5_lpddr5_dual_rank_r0.v \
+libext+.v+.vp+.sv+.svp 
