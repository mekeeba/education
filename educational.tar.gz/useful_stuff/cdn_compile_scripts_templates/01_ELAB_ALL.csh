#! /bin/csh -f

./vhan_c78.csh
./vhan_isp.csh
./vlan_cpu_ss.csh
./vlan_cr_dsp_ss.csh
./vlan_cr_efpga_ss.csh
./vlan_cr_gocm_ss.csh
./vlan_cr_ml_ss.csh
./vlan_cr_rdr_ss.csh
./vlan_ddr_ss_0.csh
./vlan_ddr_ss_1.csh
./vlan_eth.csh
./vlan_isp.csh
./vlan_pcie.csh
./vlan_peri.csh
./vlan_rt_ss.csh
./vlan_si_ss.csh
./vlan_tdtf_ss.csh
./vlan_ufs.csh
./vlan_usb.csh
./vlan_vc9000.csh
./vlan_dma_hlb.csh
./vlan_ucie_top.csh
./vlan_top.csh
./vlan_ddr_mmp_0.csh
./vlan_ddr_mmp_1.csh
./vlan_nl_meles.csh
grep Errors\ : ./*.log
grep Errors\ : ./*.log |wc
