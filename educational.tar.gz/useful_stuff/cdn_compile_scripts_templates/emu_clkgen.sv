
// This is an auto-generated file using the ixclkgen utility
//
// Command-line specified:
//   ixclkgen
//     -input clkSources.qel 
//     -output emu_clkgen.sv 
//     -hierarchy  
//     -module emu_clkgen 
//     -timescale 1fs 
//
// NOTE: Please refer to product user guide for clock modeling in IXCOM. Try:
//   ixclkgen -help
//   for usage and quick guide to compiling generated clock module.
////////////////////////////////////////////////////////////////////////////////
`timescale 1 fs / 1 fs
`define IXCclkgenTs 1 fs / 1 fs
module emu_clkgen;
  wire reg_FCLK_0__0;
  wire reg_CLK4000_0__1;
  wire reg_CLK3600_0__2;
  wire reg_CLK3000_0__3;
  wire reg_CLK2666_0__4;
  wire reg_CLK2400_0__5;
  wire reg_CLK1900_6;
  wire reg_CLK1600_0__7;
  wire CLK25TCXO_8;
  wire CLK38_4TCXO_9;
  wire CLK100TCXO_10;

`ifdef IXCOM_COMPILE
  initial $ixc_ctrl("map_delays");
  initial $ixc_ctrl("hotswap_top");
`endif

  // Generate logic for clock sources
  ixc_master_clock #(117702) ixcg_0(reg_FCLK_0__0  );
  IXCcake1x #(4000000, 4248000, 0) ixcg_1(reg_CLK4000_0__1, reg_FCLK_0__0);
  IXCcake1x #(3600000, 4248000, 0) ixcg_2(reg_CLK3600_0__2, reg_FCLK_0__0);
  IXCcake1x #(3000000, 4248000, 0) ixcg_3(reg_CLK3000_0__3, reg_FCLK_0__0);
  IXCcake1x #(2666000, 4248000, 0) ixcg_4(reg_CLK2666_0__4, reg_FCLK_0__0);
  IXCcake1x #(2400000, 4248000, 0) ixcg_5(reg_CLK2400_0__5, reg_FCLK_0__0);
  IXCcake1x #(1900000, 4248000, 0) ixcg_6(reg_CLK1900_6, reg_FCLK_0__0);
  IXCcake1x #(1600000, 4248000, 0) ixcg_7(reg_CLK1600_0__7, reg_FCLK_0__0);
  IXCcake1x #(25000, 4248000, 0) ixcg_8(CLK25TCXO_8, reg_FCLK_0__0);
  IXCcake1x #(38400, 4248000, 0) ixcg_9(CLK38_4TCXO_9, reg_FCLK_0__0);
  IXCcake1x #(100000, 4248000, 0) ixcg_10(CLK100TCXO_10, reg_FCLK_0__0);

  // Bind clock sources to generated clock signal
  ixc_cakebind ixcb_0 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_FCLK[0], reg_FCLK_0__0);
  ixc_cakebind ixcb_1 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK4000[0], reg_CLK4000_0__1);
  ixc_cakebind ixcb_2 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK3600[0], reg_CLK3600_0__2);
  ixc_cakebind ixcb_3 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK3000[0], reg_CLK3000_0__3);
  ixc_cakebind ixcb_4 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2666[0], reg_CLK2666_0__4);
  ixc_cakebind ixcb_5 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2400[0], reg_CLK2400_0__5);
  ixc_cakebind ixcb_6 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK1900, reg_CLK1900_6);
  ixc_cakebind ixcb_7 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK1600[0], reg_CLK1600_0__7);
  ixc_cakebind ixcb_8 (TBENCH.uTBENCH_CTRL.uOSC.CLK25TCXO, CLK25TCXO_8);
  ixc_cakebind ixcb_9 (TBENCH.uTBENCH_CTRL.uOSC.CLK38_4TCXO, CLK38_4TCXO_9);
  ixc_cakebind ixcb_10 (TBENCH.uTBENCH_CTRL.uOSC.CLK100TCXO, CLK100TCXO_10);

  // Generate logic for clock assigns
  wire reg_FCLK_1__11;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_0 (reg_FCLK_1__11, reg_FCLK_0__0);
  ixc_cakebind ixca_0 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_FCLK[1], reg_FCLK_1__11);

  wire reg_FCLK_2__12;
  ixc_posedge_clk_divider #(1, 4, 2) ixcd_1 (reg_FCLK_2__12, reg_FCLK_0__0);
  ixc_cakebind ixca_1 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_FCLK[2], reg_FCLK_2__12);

  ixc_cakebind ixca_2 (TBENCH.uTBENCH_CTRL.uOSC.r_CTLCLK, TBENCH.uTBENCH_CTRL.ucrg_clk.reg_FCLK[2]);

  wire reg_CLK4000_1__14;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_3 (reg_CLK4000_1__14, reg_CLK4000_0__1);
  ixc_cakebind ixca_3 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK4000[1], reg_CLK4000_1__14);

  wire reg_CLK2200_15;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_4 (reg_CLK2200_15, reg_CLK4000_0__1);
  ixc_cakebind ixca_4 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2200, reg_CLK2200_15);

  wire reg_CLK3600_1__16;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_5 (reg_CLK3600_1__16, reg_CLK3600_0__2);
  ixc_cakebind ixca_5 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK3600[1], reg_CLK3600_1__16);

  wire reg_CLK3000_1__17;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_6 (reg_CLK3000_1__17, reg_CLK3000_0__3);
  ixc_cakebind ixca_6 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK3000[1], reg_CLK3000_1__17);

  wire reg_CLK300_18;
  ixc_posedge_clk_divider #(1, 10, 3) ixcd_7 (reg_CLK300_18, reg_CLK3000_0__3);
  ixc_cakebind ixca_7 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK300, reg_CLK300_18);

  wire reg_CLK2666_1__19;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_8 (reg_CLK2666_1__19, reg_CLK2666_0__4);
  ixc_cakebind ixca_8 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2666[1], reg_CLK2666_1__19);

  wire reg_CLK1300_20;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_9 (reg_CLK1300_20, reg_CLK2666_0__4);
  ixc_cakebind ixca_9 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK1300, reg_CLK1300_20);

  wire reg_CLK2400_1__21;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_10 (reg_CLK2400_1__21, reg_CLK2400_0__5);
  ixc_cakebind ixca_10 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2400[1], reg_CLK2400_1__21);

  ixc_cakebind ixca_11 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2500, reg_CLK2400_0__5);

  wire reg_CLK1600_1__23;
  ixc_posedge_clk_divider #(1, 2, 1) ixcd_12 (reg_CLK1600_1__23, reg_CLK1600_0__7);
  ixc_cakebind ixca_12 (TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK1600[1], reg_CLK1600_1__23);

  ixc_cakebind ixca_13 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi0.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_14 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C0.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi1.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_15 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi0.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_16 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_C_TOP.uSCLST_C.uDDR_SS_C1.uSNIDDRL5XS_MCS3_WRP_0.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi1.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_17 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi0.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_18 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC0.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi1.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_19 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi0.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_20 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC1.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi1.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_21 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi0.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_22 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC2.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi1.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_23 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi0.DAT_CLK, reg_FCLK_0__0);

  ixc_cakebind ixca_24 (TBENCH.uOMNITOP_WRAP.uOMNITOP.uSCLST_M_TOP.uSCLST_M.uDDR_SS_NC3.uSNIDDRL5XS_MCS3_WRP_1.uSNIDDRL5XS_PHY_WRP.u_dfiphy5_lpddr5_dfi1.DAT_CLK, reg_FCLK_0__0);

`ifdef IXCOM_COMPILE
  initial begin
    $ixc_ctrl("hotswap_top");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_FCLK[0]", "ixcg_0", "4248000kHz", "B1", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK4000[0]", "ixcg_1", "4000000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK3600[0]", "ixcg_2", "3600000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK3000[0]", "ixcg_3", "3000000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2666[0]", "ixcg_4", "2666000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK2400[0]", "ixcg_5", "2400000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK1900", "ixcg_6", "1900000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.ucrg_clk.reg_CLK1600[0]", "ixcg_7", "1600000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.uOSC.CLK25TCXO", "ixcg_8", "25000kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.uOSC.CLK38_4TCXO", "ixcg_9", "38400kHz", "C ", "0");
    $ua_cmd("cakeClk", "TBENCH.uTBENCH_CTRL.uOSC.CLK100TCXO", "ixcg_10", "100000kHz", "C ", "0");
  end
`endif
endmodule // emu_clkgen

module ixc_master_clock(phi1);
   parameter phase_length = 1;
   output phi1;

   reg clk = 0;

   always
     #(phase_length) clk = ~clk;

   ixc_1xbufsrc m1(phi1, clk);

`ifdef IXCOM_COMPILE
  initial $ixc_ctrl("map_delays");
  initial $ixc_ctrl("hotswap_top");
`endif

endmodule // ixc_master_clock

module ixc_posedge_clk_divider(clkOut, clkIn);
  parameter Sz = 1;
  parameter Divisor = 2;
  parameter Bits = 1;
  output [Sz-1:0] clkOut;
  input  [Sz-1:0] clkIn;

  reg [Bits-1:0] counter = Divisor / 2;
  reg          clk = 0;

  always @(posedge clkIn)
  begin
    if (counter == 1)
      begin
        clk = ~clk;
        counter = Divisor / 2;
      end
    else
      counter = counter - 1;
  end

  ixc_clkbind #(Sz) icb(clkOut, clk);

`ifdef IXCOM_COMPILE
  initial $ixc_ctrl("hotswap_top");
`endif

endmodule // _ixc_posedge_clkgen_divider
