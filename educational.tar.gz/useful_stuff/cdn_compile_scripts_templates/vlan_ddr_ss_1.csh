#! /bin/csh -f

source ./SourceMe.csh
source ./setup.csh
source ./avip_setup.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_DDR_SS_1.log \
-work WORK_DDR_SS_1 \
+rtlCommentPragma \
-sv  +timescale+1ps/1ps \
+define+MMP_SNI_DDR_NC \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/DDR_SS_NC_emu_syn_vlg.f \
-incdir ${MMP_HOME}/utils/cdn_mmp_utils/sv \
${DIR_TB_ROOT}/02_model/DDR/dfiphy5_lpddr5_dual_rank_r0.v \
+libext+.v+.vp+.sv+.svp 
