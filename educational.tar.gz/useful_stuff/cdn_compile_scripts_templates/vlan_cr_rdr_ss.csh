#! /bin/csh -f

source ./setup.csh
source ./avip_setup.csh
source ./SourceMe.csh
unsetenv XE_HOST_FILE

ixcom -clean

vlan \
-l vlan_cr_rdr_ss.log \
-work WORK_cr_rdr_ss \
-sv +timescale+1ps/1ps \
+rtlCommentPragma \
-file ${DIR_TB_ROOT}/03_filelist/emu_syn_fl/cr_rdr_ss_emu_syn_vlg.f \
+libext+.v+.vp+.sv+.svp 

