# Please set $ROOT to the directory of GIT repository, before source this file
setenv ROOT           "<release_data_path>"
setenv DIR_RTL_ROOT   "${ROOT}"
setenv DIR_VERIF_ROOT "${ROOT}/std_project_fe.omni_fe_fs_verif"

#-----------------------------------------------------------------------
# Testbench Path
#-----------------------------------------------------------------------
setenv DIR_TB_ROOT    "${DIR_VERIF_ROOT}/verif_emu/testbench"
setenv VERIF_ENV_CHIP "${DIR_TB_ROOT}/../../verif_top"

setenv SOC_LIB_PKG ${DIR_RTL_ROOT}/LIB_PKG
setenv SOC_OMNI_REL ${DIR_RTL_ROOT}/OmniRTLRelease_R0

#<emu>. ${SOC_OMNI_REL}/rel_setenv.sh
source ./rel_setenv.csh

################################
#Overwrite Environment Variables
################################
setenv CDN_CPUSS_DIR ${DIR_RTL_ROOT}/CPU_SS_SPR_R1_09_30_24
setenv RF_TOP $CDN_CPUSS_DIR/dev
setenv IP_AREA $CDN_CPUSS_DIR/IP_AREA
setenv MEM_AREA_3A $CDN_CPUSS_DIR/MEM_AREA_9_17
setenv TSMCHOME ${DIR_RTL_ROOT}/LIB_PKG/N3AE_v0.5_Phase1
setenv OMNI_MEM_SYNP_DIR $SOC_OMNI_REL/data/libraries/memories/tsmc/n3ae/v0.5/synopsys/20240617
setenv OMNI_MEM_SYNP_VDIR $SOC_OMNI_REL/data/libraries/memories/tsmc/n3ae/v0.5/synopsys/20240617/VERILOG/tt_0p750v_25c_typical
################################

setenv OMNI_TOP_DIR ${DIR_RTL_ROOT}/TOP
setenv OMNI_CRG_DIR ${DIR_RTL_ROOT}/CRG
setenv OMNI_NOC_DIR ${DIR_RTL_ROOT}/NOC
setenv OMNI_SI_DIR ${DIR_RTL_ROOT}/SI
setenv OMNI_PERI_DIR ${DIR_RTL_ROOT}/PERI
setenv OMNI_USB_DIR ${DIR_RTL_ROOT}/USB
setenv OMNI_UFS_DIR ${DIR_RTL_ROOT}/UFS
setenv OMNI_DDR_DIR ${DIR_RTL_ROOT}/DDR
setenv OMNI_PCIE_DIR ${DIR_RTL_ROOT}/PCIE
setenv OMNI_RT_DIR ${DIR_RTL_ROOT}/RT
setenv OMNI_DMA_DIR ${DIR_RTL_ROOT}/DMA
setenv OMNI_UCIe_DIR ${DIR_RTL_ROOT}/UCIE
setenv OMNI_TOPGLUE_DIR ${DIR_RTL_ROOT}/TOPGLUE
setenv NOC_PATH ${OMNI_NOC_DIR}
setenv DMA_SS_PATH ${OMNI_DMA_DIR}

setenv DWC_SENSORS_AG2_PD "${SOC_LIB_PKG}/SNPS_SLM/dwc_sensors_ag2_pd_tsmcn3a/macro"
setenv DWC_SENSORS_AG2_VM "${SOC_LIB_PKG}/SNPS_SLM/dwc_sensors_ag2_vm_tsmcn3a/macro"
setenv DWC_SENSORS_AG2_DTS2 "${SOC_LIB_PKG}/SNPS_SLM/dwc_sensors_ag2_dts2_tsmcn3a/macro"
setenv DWC_SENSORS_AG2_DTS2_RS "${SOC_LIB_PKG}/SNPS_SLM/dwc_sensors_ag2_dts2rs_tsmcn3a/macro"
#setenv DWC_SENSORS_AG2_DTS2RS ${DWC_SENSORS_AG2_DTS2_RS}

setenv CM3_PATH ${SOC_LIB_PKG}/ARM_CM3

setenv UCIe_ROOT ${SOC_LIB_PKG}/CDNS_UCIe_AXI/cadence_ucie_ios_cruise_ucie_axi_std256_strm_20240819_R005_v0p5
setenv UCIe_PHY_ROOT ${SOC_LIB_PKG}/CDNS_UCIe_AXI/cdn_sd1804uw_t3ga_16_vcs130_1xa1xb1xc1xd1ya1yb4y2yy2z_r100v1p0c

