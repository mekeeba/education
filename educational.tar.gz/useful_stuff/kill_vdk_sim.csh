#! /bin/csh -f

ps -u $USER | grep sim | awk '{print $1}' | xargs kill -9
