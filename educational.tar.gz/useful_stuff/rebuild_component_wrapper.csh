#! /bin/csh -f 

# input Component Check
set component_name = $argv
if (! $?component_name) then       
  echo "Input component_name name Is Undefined"
  exit 1
else
  if ("$component_name" == "")  then
      echo "Input component_name name Is Empty Exiting"
      exit 1
  else 
      echo "Rebuilding $component_name"
  endif
endif

# Workspace Check
if (! $?VDK_WORKSPACE) then       
  echo "VDK_WORKSPACE Is Undefined Exiting"
  exit 1
else
  if ("$VDK_WORKSPACE" == "")  then
      echo "VDK_WORKSPACE Is Empty Exiting"
      exit 1
  else 
      echo "Using Workspace $VDK_WORKSPACE"
  endif
endif

# Rebuild the target component
vssh -d $VDK_WORKSPACE -c .synopsys_temp -s $VDK_TOP/rebuild_component.py --pyargs $component_name
rm -rf .synopsys_temp
