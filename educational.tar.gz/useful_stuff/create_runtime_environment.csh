# Check if host is correct.
if ( $HOST != "scs12-rt06" & $HOST != "scs12-rt07" & $HOST != "scs12-rt08" & $HOST != "scs12-rt09"  ) then
  echo "ERROR: On wrong host to run ZS4U"
  echo "Please ssh to scs12-rt06 scs12-rt07 scs12-rt08 scs12-rt09"
  echo "Then resource VDK_WS_SETUP.csh"
  exit 1
endif 


# Set top level Workarea directory where the VS workspace will be created.
setenv VDK_TOP `pwd`
mkdir hybrid_dsp_edut_runtime
cd hybrid_dsp_edut_runtime
echo "INFO: Your runtime environment will be created at: $VDK_TOP/hybrid_dsp_edut_runtime"

# Set Release Directory. This is where users can pull for common resources.
#setenv VDK_RELEASE_DIR /projects/prj1/RELEASE/ZS5_OMNI_EPP/OMNI_HYB_DSP_EDUT_08022024
setenv VDK_RELEASE_DIR /remote/vgzebucruiseproj2/janvier/omni/MS42A/run/hybrid_dsp_runtime

# Set for creating new workspaces
setenv VDK_INSTALL_PATH $VDK_RELEASE_DIR

echo "Copying Tool Setup File"
cp -r $VDK_RELEASE_DIR/setup.csh .

echo "Copying Linux Images"
cp -r $VDK_RELEASE_DIR/images-v5.10.59.br_kernel .
cp -r $VDK_RELEASE_DIR/images-v5.15.br_kernel .
cp -r $VDK_RELEASE_DIR/images-v5.15.cruise_kernel .
cp -r $VDK_RELEASE_DIR/images-v6.6.br_kernel .

echo "Copying Design Features and Link for Zebu Work Directory"
cp -r $VDK_RELEASE_DIR/zebu .

echo "Copying Trigger Setup"
cp -r $VDK_RELEASE_DIR/zrci_trigger .

# Copy over workspace creation scripts
echo "Copying VS workspace automation scripts"
cp $VDK_RELEASE_DIR/create_new_workspace.csh .
cp $VDK_RELEASE_DIR/vdk_create_new_workspace.py .

echo 'Setup complete. To create a new VS workspace : source VDK_TOOL_SETUP.csh; ./create_new_workspace.csh \$new_workspace_name'
