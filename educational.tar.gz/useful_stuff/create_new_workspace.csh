#! /bin/csh -f

set workspace_name = $argv
if (! $?workspace_name) then       
  echo "Input workspace name Is Undefined"
  exit 1
else
  if ("$workspace_name" == "")  then
      echo "Input workspace name Is Empty Exiting"
      exit 1
  else 
      echo "Creating new workspace $workspace_name"
  endif
endif

if (-d $workspace_name) then 
  echo "Workpace $workspace_name exists aborting. Not taking the chance to overwrite"
  exit 1
endif


echo "Creating New VDK Workspace."
vssh -d $workspace_name -c .synopsys -s $VDK_TOP/vdk_create_new_workspace.py
#vs -d test_workspace -c .test -s $VDK_TOP/vdk_create_new_workspace.py &
