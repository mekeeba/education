##### GENERIC DESIGNS MAKEFILE HELPER ########
# INPUTS:
#   - DESIGN_DIR_PATH : Specify the design location
#   - DESIGN_NAME     : Specify the design name
#
#   - [UTF_FILE_PATH] : Specify the design build utf file. 
#                       Defaults to '$(DESIGN_DIR_PATH)/src/$(UTF_FILENAME)'
#   - [UTF_FILENAME]  : Specify the design build utf filename if UTF_FILE_PATH is not specified. Defaults to 'hw.utf'
#
#   - [USE_DESIGN_BUILD_CACHE] : If set as 1. The design build is copyied from $DESIGN_BUILD_CACHE if available
#                                instead of building it, in which case, the build DB is finally copyied to the $DESIGN_BUILD_CACHE (if successfull).
#   - [DESIGN_BUILD_CACHE]     : Specify designs build (DB) Cache directory. This is only used if $USE_DESIGN_BUILD_CACHE is 1.
#                           Defaults to '/remote/fr65zhaldevp/tests/hw_build'.
#   - [DESIGN_BUILD_OUTPUTDIR] : Specify design build output directory. The design is first build in this location.
#                           If $USE_DESIGN_BUILD_CACHE is 1, the BD is copyied to $DESIGN_BUILD_CACHE.
#                           Defaults to $DESIGN_DIR_PATH.
#
#   - [ZCUI_ENV]   : can be used to add env variables to define before running zCui.
##############################################

THIS_DIR := $(dir $(abspath $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))))
include $(THIS_DIR)/variables.mk

#############--- Check inputs ---#############

UTF_FILENAME  ?= hw.utf
UTF_FILE_PATH ?= $(DESIGN_DIR_PATH)/src/$(UTF_FILENAME)

#############--- Build Options ---############
FCONF := $(shell echo $(FILE_CONF) | sed 's/\.tcl//').tcl


ZEBU_VCS_FLAGS ?=  

# Always define ZEBU_NO_RTB except in SEM  
ifeq ($(HW_TYPE),SEM)
  ZEBU_VCS_FLAGS  += +define+SEM
  ZEBU_VCS_FLAGS  += +define+SNPS_ZHAL_SEM
else
  ZEBU_VCS_FLAGS  += +define+ZEBU_NO_RTB
endif

ifeq ($(shell expr $(NORM_ZEBUIP_VER) \< 2020030000),1)
  ZEBU_VCS_FLAGS += "+define+ZEBUIP_VER_LT_20_03"
endif

ZCUI_ENVIRON_1  = DESIGN_DIR_PATH=$(DESIGN_DIR_PATH)        # Specify design directory to locate sources
ZCUI_ENVIRON_1 += FILE_CONF=$(FCONF)                        # Specify the architecture_file

# Use zcei clock mode in design if needed: RTL clock mode is default
ifeq ($(HW_CLOCK_MODE),ZCEI)
  ZEBU_VCS_FLAGS  += +define+ZCEI_CLOCK
  ZCUI_ENVIRON_1  += ZCEI_CLOCK_ENABLED=1
endif

ZCUI_ENVIRON_1 += ZEBU_VCS_FLAGS="$(ZEBU_VCS_FLAGS)"        # VCS command arguments
ZCUI_ENVIRON_1 += $(ZCUI_ENV)                               # add test specific variables


#############--- Build Utilities ---#############

ifeq ($(DESIGN_BUILD_CACHE),)

  # Default designs build cache
  DESIGN_BUILD_CACHE := /remote/fr65zhaldevp/tests/hw_build

  CACHE_CP    := /remote/fr65zhaldevp/bin/svc-zhal-cp
  CACHE_RM    := /remote/fr65zhaldevp/bin/svc-zhal-rm
  CACHE_MKDIR := /remote/fr65zhaldevp/bin/svc-zhal-mkdir
  CACHE_CHMOD := /remote/fr65zhaldevp/bin/svc-zhal-chmod
  
else

  CACHE_CP    ?= cp
  CACHE_RM    ?= rm
  CACHE_MKDIR ?= mkdir
  CACHE_CHMOD ?= chmod
  
endif

# Design build cache location
DB_CACHE_DIR := $(DESIGN_BUILD_CACHE)/$(BUILD_DIRNAME)/$(DESIGN_NAME)

#TODO use lock on the CACHE..

# Build design in $(DB_DIR)
define f_build_design
	@echo "Building the Design in $(DB_DIR) ..."	
	rm -rf $(DB_DIR); mkdir -p $(DB_DIR)
	set -e; cd $(DB_DIR) && $(ZCUI_ENVIRON) zCui -u $(UTF_FILE_PATH) $(ZCUI_OPTS)
	cd $(DB_ZCUI_WORK)/zebu.work; if [ -e dpixtor.mk ]; then $(MAKE) -f dpixtor.mk; fi
endef

# Copy DB from CACHE -> $(DB_DIR)
define f_copy_design
	@echo "Copying the Design build from cache $(DESIGN_BUILD_CACHE) ..."
	rm -rf "$(DB_DIR)"
	mkdir -p "$(DB_DIR)" && cp -Tr "$(DB_CACHE_DIR)" "$(DB_DIR)"
	chmod -R u+w "$(DB_DIR)"
endef

# Copy DB from $(DB_DIR) -> CACHE
define f_cache_design
	@echo "Caching Design build in cache $(DESIGN_BUILD_CACHE) ..."	
	#TODO check if $(DB_DIR) is not corrupted before copying (i.e. has a non-empty 'zcui.work/zebu.work/zrdb' dir and ('zcui.work/zebu.work/U0/M0' or 'zcui.work/zebu.work/U0M0')

	chmod -R +r "$(DB_DIR)"  # some generated files are not readable by other users 
	$(CACHE_RM) -rf "$(DB_CACHE_DIR)"
	$(CACHE_MKDIR) -p "$(DB_CACHE_DIR)" && $(CACHE_CP) -Tr "$(DB_DIR)"  "$(DB_CACHE_DIR)"
	$(CACHE_CHMOD) -R ugo-w  "$(DB_CACHE_DIR)"
endef

#############--- Build Targets ---#############
.PHONY: design design_gui $(DB_ZCUI_WORK)

ifneq ($(HW_TYPE),SEM)
  design    : ZCUI_OPTS = --nogui --compile
  design_gui: ZCUI_OPTS =
  design design_gui: ZCUI_ENVIRON = $(ZCUI_ENVIRON_1)
else
  design    : ZCUI_OPTS = --sem --nogui
  design_gui: ZCUI_OPTS = --sem
  design design_gui: ZCUI_ENVIRON = $(ZCUI_ENVIRON_1) SEM=1 ZCUI_EXPERT="enableSEM"
endif

design design_gui design_sem: $(DB_ZCUI_WORK)
	@echo "Building Design done"

$(DB_ZCUI_WORK):
  ifeq ($(CLEAN_DESIGN_BUILD_FIRST),1)
	rm -rf "$(DB_DIR)"
  endif

  ifneq ($(call f_file-exists,$(DB_DIR)/build_done),) # if a design build is already availbale
	echo "Design build already exists."
  else
  ifeq ($(USE_DESIGN_BUILD_CACHE),1)
    ifneq ($(call f_file-exists,$(DB_CACHE_DIR)/*),) # if a design build is availbale in CACHE
	#TODO also check if $(DB_CACHE_DIR) is not corrupted
	$(call f_copy_design)
    else
	$(call f_build_design)
	$(call f_cache_design) || true # Ignore errors
    endif
  else
	$(call f_build_design)
  endif
	touch $(DB_DIR)/build_done
	# Sync all cached file data of current user
	sync
  endif

#############--- Clean Targets ---#############
.PHONY: clean_design get_db_dir

get_db_dir:
	@echo $(DB_DIR)

clean_design:
	@ echo "Cleaning up Design Build ..."
	rm -rf $(DB_DIR)

ifeq ($(USE_DESIGN_BUILD_CACHE),1)
get_cache_dir:
	@echo $(DB_CACHE_DIR)

clean_cache:
    ifneq ($(call f_file-exists,$(DB_CACHE_DIR)/*),) # if a design build is availbale in CACHE
	@echo "Delete remote cache in $(DESIGN_BUILD_CACHE) ..."
	$(CACHE_CHMOD) -R ugo+w "$(DB_CACHE_DIR)"
	$(CACHE_RM) -rf "$(DB_CACHE_DIR)"
    endif
endif


ifeq ("$(PROTOCOMPILER)","1")
ZEBUWORK := zcui.work
PC_WORK := protocompiler_work
SRC_DIR := src
compile_haps:
	rm -rf $(PC_WORK) $(ZEBUWORK) zExportRuntime.cmd	
	mkdir $(PC_WORK)                                              
	cd $(PC_WORK) && REMOTECMD="$(REMOTECMD)"  protocompiler100 \
		-license_feature FpgaInternalBeta:FpgaInternalParts \
		-batch $(DESIGN_DIR_PATH)/$(SRC_DIR)/pc_files/run_pc.tcl
	zExportRuntime -p $(ZEBUWORK) \
			-u  $(PC_WORK)/ucdb \
			-sg $(PC_WORK)/fpga \
			-rt $(PC_WORK)/runtime
	echo "$(DB_DIR)"
	mkdir -p $(DB_DIR)
	cp -rf zcui.work $(DB_DIR)
endif
