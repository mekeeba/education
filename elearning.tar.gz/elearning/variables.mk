MIN_MAKE_VERSION := 4.2
ifneq ($(firstword $(sort $(MAKE_VERSION) $(MIN_MAKE_VERSION))),$(MIN_MAKE_VERSION))
  $(error GNU Make verion higher or equal $(MIN_MAKE_VERSION) is required!  You are running version $(MAKE_VERSION))
endif

_THIS_DIR := $(dir $(abspath $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))))
COMMON_INFRA_DIR := $(shell readlink -f "$(_THIS_DIR)/..")

#####################################################################
### Utility Funtions

###########
# Return non-null if a file exists
f_file-exists = $(wildcard $1)

###########
# $1: variable to replace spaces between its words by a $2
# $2: new word separator
f_spaces_to = $(subst $() $(),$2,$(strip $1))

###########
# $1: variable from which to remove duplicated words
f_remove_duplicates = $(if $1,$(firstword $1) $(call uniq,$(filter-out $(firstword $1),$1)))

###########
# $1: variable with paths to prepend (pre) to env LD_LIBRARY_PATH
# $2: variable with paths to append (post to env LD_LIBRARY_PATH 
f_make_ldlib_path = $(call f_remove_duplicates,$(call f_spaces_to,$1,:):$$LD_LIBRARY_PATH:$(call f_spaces_to,$2,:))

###########
# Should be called with $(shell )
define _s_get_zebuip_version 
[[ -f $(ZEBU_IP_ROOT)/version/Banner ]] 
  && $(ZEBU_IP_ROOT)/version/Banner | cut -d= -f2 | sed "s/ //g" 
  || { [[ -f $(ZEBU_IP_ROOT)/bin/Banner ]]
    &&  $(ZEBU_IP_ROOT)/bin/Banner | cut -d= -f2 | sed "s/ //g"
    || basename $(ZEBU_IP_ROOT) | sed "s/ZebuIpRoot_//"
  ;}
endef

###########
# Return 1 if comparison is true, empty otherwise
# $1: current version
# $2: comparison operator (-eq, -ne, -gt, -ge, -lt, -le)
# $3: reference version
v_compare = $(shell [ $1 $2 $3 ] && echo 1)

# Return 1 if comparison is true, empty otherwise
# $1: comparison operator (-eq, -ne, -gt, -ge, -lt, -le)
# $2: reference version
v_comp_zebu   = $(call v_compare,$(NORM_ZEBU_VER),$1,$2)
v_comp_zebuip = $(call v_compare,$(NORM_ZEBUIP_VER),$1,$2)
v_comp_zhal   = $(call v_compare,$(NORM_ZHAL_VER),$1,$2)
v_comp_vz     = $(call v_compare,$(NORM_VZ_VER),$1,$2)

###########
# Should be only used in the recipe of "check_requirements" target to declare env requirement for a given test.
# $1: shell condition expression. Can use the placeholders: _z_ for $NORM_ZEBU_VER, 
#     _x_ for $NORM_ZEBUIP_VER, _a_ for $NORM_ZHAL_VER, _v_ for $NORM_VZ_VER and _h_ for lowercase($HW_TYPE) 
# $2: reason message
# Examples:
#   $(call require, _z_ -ge 2021090001 && _z_ -lt 2024030000, This test is only supported for ZEBU versions [21.09-1; 24.03[)
#   $(call require, _h_ == orion || _h_ ==  ep1, This test is only supported on ZS4 and EP1)
#   $(call require, (_z_ == 2021090001 && (_h_ == zs5 || _h_ == ep1)) || (_z_ -gt 2021090001 && (_h_ == zs5 || _h_ == ep2 || _h_ == orion)), This test is not supported on this setup)
require = @if [[ $(call _expand_cond,$1) ]]; then true; else echo "[REQUIRE_MISSED] Test requirements not met on this setup: $2"; exit 123; fi

_expand_cond = $(shell echo '$1' | sed -e "s/_z_/$(NORM_ZEBU_VER)/g" -e "s/_x_/$(NORM_ZEBUIP_VER)/g" \
	-e "s/_a_/$(NORM_ZHAL_VER)/g" -e "s/_v_/$(NORM_VZ_VER)/g" \
	-e "s/_h_/$(shell echo $(HW_TYPE) | tr A-Z a-z)/g")


#####################################################################
# INPUTS params:
USE_DESIGN_BUILD_CACHE ?= 1


# 1 => a design is required, 0 => no design required
TEST_HAS_DESIGN = 1

#--- Check ZEBU/IP env is setup correctly ---
#! NOTE: _ZHALT_xxx variables are internal and should not be exported or used outside of this makefile !
_ZHALT_ZEBU_VERSION	 ?= $(shell cat "$(ZEBU_ROOT)/version/version.txt")
ZEBU_SYSTEM_PLATFORM ?= $(shell cat "$(ZEBU_SYSTEM_DIR)/config.dff" | grep -m 1 Platform | sed 's/^.*Platform.*=\s*\"\(.*\)\".*/\1/' | tr -d ' ' | awk '{print toupper($$0)}')
ifeq ($(ZEBU_SYSTEM_PLATFORM),)
   ZEBU_SYSTEM_PLATFORM=SEM
   export ZEBU_SYSTEM_DIR=/remote/vginterfaces1/zebu_system_dir/CONFIG.TD/ZEBU_L0_SEM
   export FILE_CONF=$(ZEBU_SYSTEM_DIR)/config/zse_configuration.tcl
endif

_ZHALT_ZEBUIP_VERSION ?= $(shell $(_s_get_zebuip_version))
_ZHALT_ZHAL_VERSION   ?= $(shell cat "$(ZEBU_ADAPTOR_PATH)/../version/version.txt")
_ZHALT_VZ_VERSION     ?= $(shell vs -version | head -1)

# Tags to be used for compiled db name
PLATFORM_TAG        := $(ZEBU_SYSTEM_PLATFORM)
ZEBU_TAG            := $(_ZHALT_ZEBU_VERSION)
ZEBUIP_TAG          := $(_ZHALT_ZEBUIP_VERSION)


#####################################################################
### Used only by targets.mk i.e. a TEST
ifneq ($(TEST_DIR),)

  # Test resources paths
  SRC_DIR          := $(TEST_DIR)/src
  COMMON_DIR       := $(TEST_DIR)/../../common
  DESIGN_DIR_PATH  := $(COMMON_DIR)/design
  
  TEST_NAME        ?= $(notdir $(patsubst %/,%,$(TEST_DIR)))
  
  RUN_DIR_NAME     ?= run_$(PLATFORM_TAG)_z$(ZEBU_TAG)_x$(ZEBUIP_TAG)_$(TEST_NAME)
  RUN_DIR          ?= $(TEST_DIR)/$(RUN_DIR_NAME)
  
  export ZEBU_DESIGN_DIR := $(RUN_DIR)

  # TEST use a design
  ifneq ($(wildcard $(COMMON_DIR)/design/.*),)
    DESIGN_DIR_PATH ?= $(COMMON_DIR)/design
  else
    TEST_HAS_DESIGN = 0
  endif

#####################################################################
### Used only by designs.mk i.e. a DESIGN
else

  ifeq ($(DESIGN_DIR_PATH),)
    $(error no DESIGN_DIR_PATH is specified!)
  endif

endif


#####################################################################
### Need by Both designs and targets.mk (unless test is design-less)
ifeq ($(TEST_HAS_DESIGN),1) # or ifneq ($(DESIGN_DIR_PATH),) ?

  DESIGN_NAME ?= $(notdir $(shell dirname $(dir $(shell readlink -f "$(DESIGN_DIR_PATH)"))))

  ifndef HW_TYPE
    HW_TYPE := $(ZEBU_SYSTEM_PLATFORM)
    export HW_TYPE
  endif

  ifeq ($(_ZHALT_ZEBU_VERSION),)
    $(error could not determine _ZHALT_ZEBU_VERSION nor is it specified!)
  endif

  ifeq ($(ZEBU_SYSTEM_PLATFORM),)
    $(error could not determine ZEBU_SYSTEM_PLATFORM nor is it specified!)
  endif

  ifeq ($(_ZHALT_ZEBUIP_VERSION),)
    $(error could not determine _ZHALT_ZEBUIP_VERSION nor is it specified!)
  endif

  NORM_ZEBU_VER  := $(shell $(COMMON_INFRA_DIR)/utils/normalize_version.py "$(_ZHALT_ZEBU_VERSION)")
  NORM_ZEBUIP_VER:= $(shell $(COMMON_INFRA_DIR)/utils/normalize_version.py "$(_ZHALT_ZEBUIP_VERSION)")
  NORM_ZHAL_VER  := $(shell $(COMMON_INFRA_DIR)/utils/normalize_version.py "$(_ZHALT_ZHAL_VERSION)")
  NORM_VZ_VER    := $(shell $(COMMON_INFRA_DIR)/utils/normalize_version.py "$(_ZHALT_VZ_VERSION)")

  export NORM_ZEBU_VER
  export NORM_ZEBUIP_VER
  export NORM_ZHAL_VER
  export NORM_VZ_VER

  #XXX to be removed: should use NORM_ZEBUIP_VER directly
  ifeq ($(shell expr $(NORM_ZEBUIP_VER) \< 2020030000),1)
    export ZEBUIP_VER_LT_20_03 := 1
  endif

  # Set compiled design db name 
  # BUILD_DIRNAME MUST NOT CONTAINS $(DESIGN_NAME) !!!!!!!!!! Reason: The Cache dir $(DB_CACHE_DIR) does not use the same hierarchie mechanism
  BUILD_DIRNAME := build_$(PLATFORM_TAG)_z$(ZEBU_TAG)_x$(ZEBUIP_TAG)

  # Disable build cache when using SEM
  ifeq ($(HW_TYPE),SEM)
     USE_DESIGN_BUILD_CACHE := 0
  endif

  DESIGN_BUILD_OUTPUTDIR ?= $(DESIGN_DIR_PATH)

  #--- Design Build location ---
  DB_DIR       := $(DESIGN_BUILD_OUTPUTDIR)/$(BUILD_DIRNAME)_$(DESIGN_NAME)
  DB_ZCUI_WORK := $(DB_DIR)/zcui.work

endif


#####################################################################
### MISC
.PHONY: printenv check_requirements

printenv:
	@echo "-------------------------------------"
	@echo "ZEBU_ADAPTOR_PATH   : $(ZEBU_ADAPTOR_PATH)"
	@echo "ZEBU_ROOT           : $(ZEBU_ROOT)"
	@echo "ZEBU_IP_ROOT        : $(ZEBU_IP_ROOT)"
	@echo "SNPS_VP_HOME        : $(SNPS_VP_HOME)"
	@echo "COWARE_CXX_COMPILER : $(COWARE_CXX_COMPILER)"
	@echo "VCS_HOME            : $(VCS_HOME)"
	@echo "VERDI_HOME          : $(VERDI_HOME)"
	@echo "ZEBU_SYSTEM_DIR     : $(ZEBU_SYSTEM_DIR)"
	@echo "PROXIMA_ROOT (ZC)   : $(PROXIMA_ROOT)"
	@echo "-------------------------------------"
	@echo "REMOTECMD           : $(REMOTECMD)"
	@echo "LM_LICENSE_FILE     : $(LM_LICENSE_FILE)"
	@echo "SNPSLMD_LICENSE_FILE: $(SNPSLMD_LICENSE_FILE)"
	@echo "-------------------------------------"
	@echo "LD_LIBRARY_PATH     :"
	@echo "$(LD_LIBRARY_PATH)" | sed "s/:/\n/g" | sed "s/^/   /"
	@echo "PATH                :"
	@echo "$(PATH)" | sed "s/:/\n/g" | sed "s/^/   /"
	@echo "-------------------------------------"
	@echo "NORM_ZHAL_VER       : $(NORM_ZHAL_VER) ($(_ZHALT_ZHAL_VERSION))"
	@echo "NORM_ZEBU_VER       : $(NORM_ZEBU_VER) ($(_ZHALT_ZEBU_VERSION))"
	@echo "NORM_ZEBUIP_VER     : $(NORM_ZEBUIP_VER) ($(_ZHALT_ZEBUIP_VERSION))"
	@echo "NORM_VZ_VER         : $(NORM_VZ_VER) ($(_ZHALT_VZ_VERSION))"
	@echo "ZEBU_SYSTEM_PLATFORM: $(ZEBU_SYSTEM_PLATFORM)"

#! should not have a recipe by default!
check_requirements:

