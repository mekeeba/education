import os


def add_tlmc_parameter(tlmcP, name, type, default_val):
    try:
        tlmc_param = tlmcP.add_parameter()
        tlmc_param.set_name(name)
        tlmc_param.set_type(type)
        tlmc_param.set_default_value(default_val)
    except:
        print_message("Parameter "+name+" already present, skipping it")

def add_tlmc_interface(tlmcP, name, type):
    try:
        tlmc_param = tlmcP.add_interface()
        tlmc_param.set_name(name)
        tlmc_param.set_type(type)
    except:
        print_message("Interface "+name+" already present, skipping it")

# Print messages on SimulationOutput and Console    
def print_message(message):
    print(message)
    #vpx.print_sim(message)
    
    
def update_mmc_tlmc():

    print_message('VDK-INFO : Updating MMC Adaptor')

    mmc_name =  "xtor_mmc_device_svs_adaptor"
    mmc = tlmcreator.load_model('xtor_mmc_device_svs_adaptor')

    # Adding Parameters
    add_tlmc_parameter(mmc, "StartCardPresent", "unsigned int", "1")
    add_tlmc_parameter(mmc, "cardType", "std::string", "\"MMCv4.4\"")
    add_tlmc_parameter(mmc, "cardName", "std::string", "\"mmc_linux\"")
    add_tlmc_parameter(mmc, "cardFile", "std::string", "\"card0.ext2.bin\"")
    add_tlmc_parameter(mmc, "configNum", "unsigned int", "0")
    add_tlmc_parameter(mmc, "Monitor", "bool", "false")

    # Adding Interfaces:

    add_tlmc_interface(mmc, "CardDetect", "sc_core::sc_in<unsigned int>")
    add_tlmc_interface(mmc, "WriteProtect", "sc_core::sc_in<unsigned int>")
    add_tlmc_interface(mmc, "PowerOn", "sc_core::sc_in<bool>")

    # Instances & Callbacks:

    mmc_adaptor = mmc.get_instance('adaptor')

    mmc_adaptor.get_callback('on_run_start').set_enabled(True)
    mmc_adaptor.get_callback('on_board_close').set_enabled(True)

    mmc.save()

    linux_src = os.environ['ZEBU_DESIGN_DIR'] +'../../software/mmc_include/card/VDK_Card_Linux2.hh'
    linux_dst = eclipse.get_workspace_path()  +"/xtor_mmc_device_svs_adaptor/VDK_Card_Linux2.hh"

    shutil.copy2(linux_src, linux_dst)

    mmc_base_src = os.environ['ZEBU_DESIGN_DIR'] + "../../software/mmc_include/mmc_adaptor/"
    mmc_base_dst = eclipse.get_workspace_path()  + "/xtor_mmc_device_svs_adaptor"

    shutil.copy2(mmc_base_src + mmc_name + ".cc", mmc_base_dst + "/"+ mmc_name + ".cc")
    shutil.copy2(mmc_base_src + mmc_name + ".h", mmc_base_dst + "/"+ mmc_name + ".h")

    mmc.save()
    mmc.build()


def setup_mmc(vdk, hybrid_cbb):
 
    # MMC Adaptor is only available on latest version
    # We check if the project has been created to updated it accordingly.
    ###########################################
    # Update VMMC Adaptor TLMC
    ###########################################
    print_message("VDK-INFO : Updating MMC Adaptor...")
    update_mmc_tlmc()
    # After adding interfaces and parameters to the MMC adaptor we need to update the model.
    vdk.update_all()
    print_message("VDK-INFO : Updating MMC Adaptor Done")
    print_message("VDK-INFO :  Integrating additional components...")
    
    # DesignWare eMMC Socket IP
    card_socket = root.add_building_block('i_DW_MMC_Socket', 'Synopsys', 'DESIGNWARE_MOBILESTORAGE', 'CardSocket')
    card_socket.get_parameter_group('DWSLL', 'EXTRA_PROPERTIES').get_parameter('Param_StartCardPresent').set_value(0)
    vdk.add_connection(card_socket.get_interface("Reset"),vdk.get_instance('/SYSRST').get_interface("RST"))

    emmc = hybrid_cbb.get_instance("ZebuIp_i_mmc")
    
    # DesignWare eMMC Socket to external Reset
    # Connect DesignWare eMMC Socket <-> ZeBu eMMC Adaptor
    vdk.add_connection(emmc.get_interface('CardDetect'), card_socket.get_interface('CardSocket').get_interface_in_slot('CardPresent'))
    vdk.add_connection(emmc.get_interface('WriteProtect'), card_socket.get_interface('CardSocket').get_interface_in_slot('WriteProtect'))
   
    # stub ZeBu eMMC Adaptor Port
    emmc.get_interface('PowerOn').stub_with('Synopsys','VDKC_MODELS','signal_drive')
    emmc.get_interface('PowerOn').get_stub().get_parameter('DT').set_value('bool')
    emmc.get_interface('PowerOn').get_stub().get_parameter('output_value').set_value(1)
    emmc.get_parameter('cardFile').set_value('$(ZEBU_DESIGN_DIR)/card0.ext2.bin')  
