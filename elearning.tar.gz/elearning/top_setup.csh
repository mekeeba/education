
#! /bin/csh -f

# Where is this file?
if ("$0" =~ "*setup*.csh") then
     echo "Please source '$0' instead of calling it directly"
     exit 1
endif

# Get this setup root directory
set called=($_)
if ("$called" != "") then
   set script_fn  = `readlink -f $called[2]`
   set __here = `dirname "$script_fn"`
else
   set __here = `pwd`
endif

cd $__here

# Release mode
# Officals | nightly | prerelease | OST
setenv ZEBU_BUILD_MODE	"officials"
setenv ZHAL_BUILD_MODE	"officials"
setenv VZER_BUILD_MODE	"officials"
setenv ZEBU_IP_BUILD_MODE	"officials"
source $__here/../configs/setup.csh
