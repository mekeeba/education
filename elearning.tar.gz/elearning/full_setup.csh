
#! /bin/csh -f

# Where is this file?
if ("$0" =~ "*setup*.csh") then
     echo "Please source '$0' instead of calling it directly"
     exit 1
endif

# Get this setup root directory
set called=($_)
if ("$called" != "") then
   set script_fn  = `readlink -f $called[2]`
   set __here = `dirname "$script_fn"`
else
   set __here = `pwd`
endif

cd $__here
set config_root = $__here/..

# ZEBU GRID (for compilation)
source /u/regress/INFRA_HOME/sourceme.csh
source /remote/sge/default/zebutrain/common/settings.csh

#######################################
########### END USER INPUTS ###########
#######################################

# Sites' zebu configuration
if ( $SITE == "FR" ) then
	set ZEBU_CONFIG_SITE 	 = fr65zebu_config
	set ZS4_HW_CONFIG_HOST   = vgfr65zeburt75
	set ZS5_HW_CONFIG_HOST   = vgfr65zeburt101
	set H100_HW_CONFIG_HOST  = vgfr65zeburt25

else if ( $SITE == "US" ) then
	set ZEBU_CONFIG_SITE 	 = us01zebu_config
	set ZS4_HW_CONFIG_HOST   = vgzeburt327
	set ZS5_HW_CONFIG_HOST   = vgzeburt480
else
	# Make FR default site
	set ZEBU_CONFIG_SITE 	 = fr65zebu_config
	set ZS4_HW_CONFIG_HOST   = vgfr65zeburt75
	set ZS5_HW_CONFIG_HOST   = vgfr65zeburt101
	set H100_HW_CONFIG_HOST  = vgfr65zeburt25
endif

if ( $SEM_MODE == "SEMC" ) then
	set SEM_CONFIG_HOST  = ZEBU_L0_SEM
	
	# Disabling libraries license management
	setenv ZEBU_ENABLE_LIB_LIC_MNGT false
	setenv XTOR_SVS_ENABLE_LIB_LIC_MNGT false	
else if ( $SEM_MODE == "SEMB" ) then
	set SEM_CONFIG_HOST  = SEMBEH
else
	# If SEM_MODE is not specified, use SEMC
	set SEM_CONFIG_HOST  = ZEBU_L0_SEM
	
	# Disabling libraries license management
	setenv ZEBU_ENABLE_LIB_LIC_MNGT false
	setenv XTOR_SVS_ENABLE_LIB_LIC_MNGT false	
endif

# SNPS designWares
module unload syn
module load syn


# ZEBU
if ( $ZEBU_BUILD_MODE == "officials" ) then
	module unload zebu
	module load zebu/$ZEBU_MODULE_VERSION
else if ( $ZEBU_BUILD_MODE == "OST" 		)  then
	source /slowfs/vgzeburelease3/$ZHAL_BUILD_MODE/ZEBU2021.09-2-OST2/zebu/S-2021.09-2/zebu_env.csh
else if ( $ZEBU_BUILD_MODE == "zebu_nightly")  then
	# ZEBU 21.09-2
	if  	( $SITE == "FR" ) then
		source /remote/vgeven2/$ZEBU_BUILD_MODE/linux64_VCS2021.09_fr65/VCS2021.09.231011/VCS2021.09_zs4/zebu_env.csh
	else if ( $SITE == "US" ) then
		source /remote/vgzeburelease3/$ZEBU_BUILD_MODE/linux64_VCS2021.09/VCS2021.09.230927/VCS2021.09_zs4/zebu_env.csh
	else
		echo "ERROR: You haven't provided the site or the site provided is not supported yet. Choose a site in this list : US | FR"
	endif
else
	echo "ERROR: Please, set a build mode for Zebu. Candidates are: officials | OST | zebu_nightly."
endif


# ZEBU IP
if  	( $ZEBU_IP_BUILD_MODE == "officials"	)  then
	setenv ZEBU_IP_ROOT /remote/vginterfaces1/zebu_ip/ZebuIpRoot_$ZEBU_IP_OFFICIAL_VER
else if ( $ZEBU_IP_BUILD_MODE == "OST"  		)  then
else if ( $ZEBU_IP_BUILD_MODE == "nightly"  	)  then
	setenv ZEBU_IP_ROOT /remote/vginterfaces1/zebu_ip/ZebuIpRoot_$ZEBU_IP_NIGHTLY_VER
else if ( $ZEBU_IP_BUILD_MODE == "prerelease" 	)  then
else
	echo "ERROR: Please, set a build mode for ZebiIP"
endif


# PA / Virtualizer
if ( $VZER_BUILD_MODE == "officials" ) then
	module unload pa_virtualizer
	module load pa_virtualizer/$VZER_FINAL_VERSION
	source ${SNPS_VP_HOME}/setup.csh -vze
else if ( $VZER_BUILD_MODE == "nightly" 	)  then
else if ( $VZER_BUILD_MODE == "prerelease"  )  then
else if ( $VZER_BUILD_MODE == "OST" 		)  then
else
	echo "ERROR: Please, set a build mode for Virtualizer"
endif


# ZHAL
if  	( $ZHAL_BUILD_MODE == "officials" 	)  then
	source /remote/vginterfaces1/zebu_hybridadaptor/$ZHAL_BUILD_MODE/ZeBuHybridAdaptor_$ZHAL_BASE_VERSION/zhal_env.csh
else if ( $ZHAL_BUILD_MODE == "prerelease"  )  then
	source /remote/vginterfaces1/zebu_hybridadaptor/$ZHAL_BUILD_MODE/ZeBuHybridAdaptor_$ZHAL_BASE_VERSION/zhal_env.csh
else if ( $ZHAL_BUILD_MODE == "nightly" 	)  then
	source /remote/vginterfaces1/zebu_hybridadaptor/$ZHAL_BUILD_MODE/ZeBuHybridAdaptor_$ZHAL_NIGHTLY_VERSION/zhal_env.csh
else
	echo "ERROR: Please, set a build mode for ZHAL"
endif


# HW CONFIGURATION
if  	( $HW_TYPE == "SEMC" )  then
	setenv ZEBU_SYSTEM_DIR /remote/vginterfaces1/zebu_system_dir/CONFIG.TD/$SEM_CONFIG_HOST
else if ( $HW_TYPE == "ZS4" )  then
	setenv ZEBU_SYSTEM_DIR /remote/$ZEBU_CONFIG_SITE/CONFIG.TD.ZEBU/$ZS4_HW_CONFIG_HOST
else if ( $HW_TYPE == "ZS5" )  then
	setenv ZEBU_SYSTEM_DIR /remote/$ZEBU_CONFIG_SITE/CONFIG.TD.ZEBU/$ZS5_HW_CONFIG_HOST
else if ( $HW_TYPE == "H100")  then
	setenv ZEBU_SYSTEM_DIR /remote/$ZEBU_CONFIG_SITE/CONFIG.TD.ZEBU/$H100_HW_CONFIG_HOST
else
	echo "ERROR: Please, set your targetted hardware type (ZS4 | ZS5  | H100 | SEM etc...)"
endif

setenv FILE_CONF $ZEBU_SYSTEM_DIR/config/zse_configuration.tcl

# Load Python
module unload python
module load python/$PYTHON_VER

# Load GCC
# module unload gcc
# module load gcc/$GCC_VER
setenv PATH /depot/qsc/QSCS/bin:$PATH

# T32 Debugger
setenv T32SYS /u/ccmaster/coware/3rdparty/tools/lauterbach/T32

# LD_LIBRARY_PATH
setenv LD_LIBRARY_PATH $ZEBU_IP_ROOT/lib64:$ZEBU_ADAPTOR_PATH/lib64:.:${LD_LIBRARY_PATH}
setenv LD_LIBRARY_PATH /depot/boost_1_54_0/amd64/lib:$LD_LIBRARY_PATH

# Use the right make version
setenv PATH /depot/make-$MAKE_VER/bin:$PATH

# use GTK from VS
setenv LD_LIBRARY_PATH $config_root/common/libs:$LD_LIBRARY_PATH

# For JPEG library
setenv LD_LIBRARY_PATH $ZEBU_IP_ROOT/third_party_sw/jpeg/linux64:$LD_LIBRARY_PATH


# Binutils
setenv PATH /global/freeware/Linux/3.10/binutils-2.33.1/bin:$PATH


# Licenses US | FR
if  	( $SITE == "FR" ) then
	setenv LM_LICENSE_FILE 6280@fr65-lic1
else if ( $SITE == "US" ) then
	setenv LM_LICENSE_FILE 7183@us01vglmd5:7183@us01vglmd7:7183@us01vglmd8:7183@us01vglmd10:7183@us01vglmd4:7183@us01vglmd9:7183@us01vglmd1:7183@us01vglmd11::1714@us01misclmd2:1714@us01vgmisclmd1:1717@vgeve2:6280@us01vglmd3p1:28518@us01misclmd1
else
	echo "WARNING: Licenses are not correctly set for this site. Get appropriated licences for your site : $SITE"
endif


###################################################
########### DISPLAY TOOLS' COMBINATION ############
###################################################
echo "\nTools combination :"
echo "	ZEBU       : $ZEBU_ROOT"
echo "	ZEBU-IP    : $ZEBU_IP_ROOT"
echo "	ZHAL       : $ZEBU_ADAPTOR_PATH"
echo "	VITUALIZER : $SNPS_VP_HOME\n"
