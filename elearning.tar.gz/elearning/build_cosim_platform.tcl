#!/bin/env pcsh

set srcDir $env(SRC_DIR)
set THIS_DIR [file normalize [file dirname [info script]]]

#########################################################
# This can be called from the build script "${srcDir}/project.tcl"
proc build_module {HERE srcDir modelName} {
   upvar THIS_DIR THIS_DIR
   global env;

   set env(OUT_DIR) $HERE
   set env(SRC_DIR) $srcDir 
   set env(MODEL_NAME) $modelName

   exec pcsh $THIS_DIR/build_module.tcl >&@stdout
}

#########################################################
if { [file exists "${srcDir}/create_test.tcl"] == 1} {
    # A test can have a custom pcsh build script  
    puts "Using ${srcDir}/create_test.tcl ..."
    source "${srcDir}/create_test.tcl"
} else {
    puts "Using default build script ..."

    # Default build script 
    source "${srcDir}/project.tcl"
    
    ::pct::create_simulation_build_project .
    ::pct::set_simulation_build_project_setting Debug "Optimize Level" "Optimize more (-O2)" 
    ::pct::set_simulation_build_project_setting Debug "Backdoor Mode" true 
    ::pct::set_simulation_build_project_setting Debug "Disable Elaboration" false 
    # Disable build cache ~/.ccache
    ::pct::set_simulation_build_project_setting Debug "Cache Objects" false
    ::pct::set_simulation_build_project_setting Debug {Export Type} {STATIC NETLIST}
    ::pct::set_simulation_build_project_setting Debug {HDL Simulator} vcs
    ::pct::set_simulation_build_project_setting Debug {Cosim timeout} 10
    ::pct::set_simulation_build_project_setting Debug {Delta Cycle Synchronization} false
    ::pct::set_simulation_build_project_setting Debug {HDL Max Nesting} 10

    ::pct::set_simulation_build_project_setting Debug {Verilog Compile Options} -timescale=10ns/10ps
    ::pct::set_simulation_build_project_setting Debug {Verilog Timescale} ps
    ::pct::export_simulation 
    ::scsh::open-project
    ::scsh::cosim::enable_hdl_sdi
    ::scsh::build-options -skip-elab off
    ::scsh::build
    ::scsh::elab sim

    puts "SystemC Platform Ready"
}
