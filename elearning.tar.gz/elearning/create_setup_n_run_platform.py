import sys, time, shutil, traceback, os

ws = eclipse.get_workspace_path()
scriptsDir = os.path.join(os.environ['ZEBU_DESIGN_DIR'], '../../scripts')
sys.path.append(scriptsDir)

vdk_name="startingKitVDK"
hybrid_bb_name = 'ZebuCockpit_BB'

global uart_console

# Type: timed / breakpoints
hw_sw_sync_reset_mode = "timed"

# Add emmc configuration
sys.path.append(os.environ['ZEBU_DESIGN_DIR']+'../../software/scripts/emmc.py')
# from emmc import *
import emmc


# Print messages on SimulationOutput and Console    
def print_message(message):
    print(message)
    #vpx.print_sim(message)
    

##################################################
# Create Platform VDK with ARMv8 Starting Point  #
##################################################
def create_hybrid_vdk(vdk_name):

    if vpx.version().find('T-2022.06') == -1 and vpx.version().find('U-2023.03') == -1 and True:
    	print_message("VDK-WARNING : Unsupported Virtualizer Version: {vpx.version()}")
    else:
    	print_message("VDK-INFO : Creating Hybrid platform")
	
    # Select the Armv8 Starting Point Template: This template comes with two vpconfigs by default
    vpConfigs_lst = ['PlatformTest']
    arm_template = vdkcreator.get_template('ARMv8_VDK_Starting_Point').configure().set_vp_configs(vpConfigs_lst)

    # Create the VDK using the create_vdk function. User must provide vdk name and base line template
    vdk = vdkcreator.create_vdk(name=vdk_name, template=arm_template)

    # Get the root of the vdk project hierarchy.
    root = vdk.get_root()
    return root, vdk


##################################
# Create Hybrid Building Blocks  #
##################################
def create_hybrid_bb(vdk_root):
    hbb = vdk_root.add_building_block(hybrid_bb_name,"Synopsys","ZebuHybrid","ZHAL_CBB")
    return hbb


#################################
# Setup Hybrid Building Blocks  #
#################################
def setup_n_generate_hbb(hybrid_cbb):

    # Get initial configuration of the Hybrid Building Block
    cbb_config = hybrid_cbb.get_configuration()

    # User need to duplicate the configuration in order to make changes to the buiding block.
    tmp_config = cbb_config.duplicate()

    # From configuration we get a vector with the ZHAL_CBB categories:Zebu Hybrid, Zebu Testbench and Zebu Monitor
    zb_category = tmp_config.get_parameter('Zebu Category').get_values()

    # Create a vector with the parameters of the Zebu Hybrid Category
    zb_hybrid = zb_category[0].get_parameter('hybrid_interfaces').get_values()

    # Finally we set the values for the different parameters:

    # For the Bus Target Adaptor enable the Hybrid Register Server && Provide its location path/name
    zb_hybrid[0].get_parameter("hybridregserver").set_value("True")
    zb_hybrid[0].get_parameter("hybridregserver_CSV").set_value("$ZEBU_DESIGN_DIR/register_server/registerserver.csv")

    # Configure the FastMem Base Address Parameter - Size is automatically set based on Zebu DataBase.
    fm_reg = zb_hybrid[2].get_parameter("mapping").get_values()
    mem_0 = fm_reg[0].get_parameter('Region').get_values()
    mem_0[0].get_parameter("base_address").set_value("0x51000000")

    # For the Signal In XTOR (VDK to DUT): Set the type to reset.
    zb_hybrid[3].get_parameter('Type').set_value('interrupts')

    # For the Signal Out XTOR (DUT to VDK): Set the type to Interrutps.
    zb_hybrid[4].get_parameter('type').set_value('reset_from_zebu')

    # We now generate the ZHAL_CBB, based on the modified confuration.
    hybrid_cbb.regenerate(tmp_config,'generate')


#####################################
# Configure Hybrid Building Blocks  #
##################################### 
def configure_hbb_if(hybrid_cbb, vdk):

    mem_initiator ='AMBA_initiator_i_axi_slave_if'
    mem_initiator_con = vdk.add_connection(hybrid_cbb.get_interface(mem_initiator),vdk.get_instance('/DRAM').get_interface("MEM"))
    mem_initiator_con.set_decoding_info(start = '0x00000000', size='0x4000000',offset='0x00000000')
    
    # Memory Target
    mem_target = 'data_in'
    mem_target_con = vdk.add_connection(hybrid_cbb.get_interface(mem_target),vdk.get_instance('/SharedMemoryMap').get_interface("intf"))
    mem_target_con.set_undecoded()

    # Interrupt Output (From DUT)
    irq_out = 'SBSig_from_dut_i_sig_i_if'
    irq_out_con = vdk.add_connection(hybrid_cbb.get_interface(irq_out),vdk.get_instance('/CPU_SS/GIC').get_interface("IRQS"))
    # To specify the IRQ lines (start) and number (size):
    irq_out_con.set_decoding_info(start='1',size='2')

    # Connect reset from DUT 
    reset_in = 'SBSig_from_dut_i_sig_r_if'
    reset_in_con = vdk.add_connection(hybrid_cbb.get_interface(reset_in),vdk.get_instance('/CPU_SS').get_interface("Reset"))

    # Reset Input (to DUT)
    #reset_in = 'SBSig_to_dut_i_sigout1_if'
    #reset_in_con = vdk.add_connection(hybrid_cbb.get_interface(reset_in),vdk.get_instance('/SYSRST').get_interface("RST"))


    
 
##############################
# Update Platform VP Config  #
############################## 
def update_vpconfig(vdk):

    print_message("VDK-INFO : Updating vpconfigs... ")
    # Open the PlatformTest vpconfig
    vpcfg = vpx.open_vpconfig( ws + "/"+ vdk_name +"/vpconfigs/PlatformTest/PlatformTest.vpcfg")    
    # Set the new test_image path
    test_image = '$(ZEBU_DESIGN_DIR)/../../software/PlatformTest/Debug/PlatformTest.elf'    
    # Override existing value
    vpcfg.set_parameter_value_override( "/"+ vdk_name +"/CPU_SS", "EXTRA_PROPERTIES", "/ImageInfo/initial_image", test_image )   
    # Save
    vpcfg.save()
    print_message("VDK-INFO : vpconfigs update ..... done")

###########################
# Create Hybrid platform  #
###########################
def create_startingKit_platform(vdk_name):

    # Create platform VDK
    root, vdk = create_hybrid_vdk(vdk_name)

    # Create Hybrid Building Blocks
    hybrid_cbb = create_hybrid_bb(root)

    # Setup Hybrid Building Blocks
    setup_n_generate_hbb(hybrid_cbb)

    # Configure and generate HBB
    configure_hbb_if(hybrid_cbb, vdk)
    
    # Setup MMC if included
    if (eclipse.exists('xtor_mmc_device_svs_adaptor')):
    	setup_mmc(vdk, hybrid_cbb)
	
    vdk.save()
    vdk.build()

    return vdk 


# Update count register value
def update_count_register(value):  
    count_reg = zhal.find_signal('hybrid_tb.hybrid_top.count_reg')
    count_reg.write_word32(value)   

# Resume platform run            
def resume_platform_run():
    vpx.continue_simulation()
    
    
# Function to auto-type command on UART console
def uart_console_autotype(command_line, delay_interval):
    print_message('SCRIPT-INFO: Typing: '+command_line)
    uart_console.send_command('push "'+command_line+'" ')
    add_delay(delay_interval)

# Auto-run test #1
def auto_run_test_1():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("1\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)

# Auto-run test #2 
def auto_run_test_2():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("2\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)

# Auto-run test #3    
def auto_run_test_3():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)

# Auto-run test #4    
def auto_run_test_4():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("4\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1) 


def add_delay(delay_interval):
    time.sleep(delay_interval)
    
# Switch schecduler to Sync Mode           
def switch_to_sync_mode():
    scheduler_mode = zhal.get_scheduler_mode()
    print_message("VDK-INFO : Current scheduler mode is : "+scheduler_mode)
    if (scheduler_mode == 'SYNC'):
    	print_message("VDK-INFO : The scheduler is already set to SYNC mode")
    else:
    	set_scheduler = zhal.set_scheduler_mode(False)
    	if (set_scheduler == True):
            print_message("VDK-INFO : The scheduler has been set to SYNC mode")
    	else:
            print_message("VDK-ERROR: An error happened when trying to switch the scheduler to SYNC mode")
	    
	        
def switch_to_freerunning_mode():
    print_message("VDK-INFO : Switching to FREE running mode")
    scheduler_mode = zhal.get_scheduler_mode()
    print_message("VDK-INFO : Current scheduler mode is : "+scheduler_mode)
    if (scheduler_mode == 'FREE'):
        print_message("VDK-INFO : The scheduler is already set to FreeRunning mode")
    else:
    	set_scheduler = zhal.set_scheduler_mode(True)
    	if (set_scheduler == True):
            print_message("VDK-INFO : The scheduler has been set to FREE RUNNING mode")
    	else:
            print_message("ERROR: An error occured when trying to switch the scheduler to FREE RUNNING mode")

	
def release_sw_reset():
    print_message("VDK-INFO : Releasing software reset from HW")
    sw_lock_reset_signal = zhal.find_signal("hybrid_tb.i_rst_gen.security_rst_n")
    sw_lock_reset_signal.write("0x1")
  
    
# Create the startingKit platform        
vdk = create_startingKit_platform(vdk_name)
update_vpconfig(vdk)

# Run the platform
vpc = vpx.open_vpconfig(ws + "/"+ vdk_name +"/vpconfigs/PlatformTest/PlatformTest.vpcfg")
vpc.run(blocking = False)

# Get UART console
uart_console = vpx.get_node("/"+ vdk_name +"/Periphs/UART_PHY")
hw_long_reset_enable = zhal.find_signal("hybrid_tb.i_rst_gen.force_hw_rst_usage")

# HW/SW Sync using breakpoints
if hw_sw_sync_reset_mode == "breakpoints":
    zhal.set_scheduler_mode(False)
    hw_long_reset_enable.write("0x1")
    switch_to_sync_mode()

    # Using breakpoint Method         
    bp=vpx.create_time_breakpoint(2097153, 'ps')
    bp.set_callback('release_sw_reset()')

    # Using breakpoint Method         
    bp=vpx.create_time_breakpoint(2097665, 'ps')
    bp.set_callback('switch_to_freerunning_mode()')

# HW/SW Sync using time-run    
else:
    zhal.set_scheduler_mode(False)
    hw_long_reset_enable.write("0x1")
    switch_to_sync_mode()
    vpx.runfor(2097153, 'ps')
    release_sw_reset()
    vpx.runfor(512, 'ps')
    switch_to_freerunning_mode()


resume_platform_run()
add_delay(5)
auto_run_test_1()
auto_run_test_2()
