
`define USER_WIDTH_MACRO 8

// AXI4
`define AXI4_ADDR_WIDTH         32
`define AXI4_AWID_WIDTH       	16
`define AXI4_AWLEN_WIDTH      	8
`define AXI4_AWSIZE_WIDTH     	3
`define AXI4_BURST_WIDTH      	2
`define AXI4_AWLOCK_WIDTH     	1
`define AXI4_ACACHE_WIDTH     	4
`define AXI4_ACPROT_WIDTH     	3
`define AXI4_DATA_WIDTH       	64
`define AXI4_WSTRB_WIDTH      	8
`define AXI4_BID_WIDTH	      	16
`define AXI4_BRESP_WIDTH      	2
`define AXI4_ARID_WIDTH       	16
`define AXI4_ARLEN_WIDTH      	8
`define AXI4_ARSIZE_WIDTH     	3
`define AXI4_BURST_WIDTH      	2
`define AXI4_ARLOCK_WIDTH     	1
`define AXI4_ACACHE_WIDTH     	4
`define AXI4_ACPROT_WIDTH     	3
`define AXI4_RID_WIDTH	      	16
`define AXI4_RRESP_WIDTH      	2

// ACELITE
`define ACELITE_ADDR_WIDTH		32
`define ACELITE_AWID_WIDTH		16
`define ACELITE_AWLEN_WIDTH 	8
`define ACELITE_AWSIZE_WIDTH	3
`define ACELITE_BURST_WIDTH 	2
`define ACELITE_AWLOCK_WIDTH	1
`define ACELITE_ACACHE_WIDTH	4
`define ACELITE_ACPROT_WIDTH	3
`define ACELITE_DATA_WIDTH		64
`define ACELITE_WSTRB_WIDTH 	8
`define ACELITE_BID_WIDTH		16
`define ACELITE_BRESP_WIDTH 	2
`define ACELITE_ARID_WIDTH		16
`define ACELITE_ARLEN_WIDTH 	8
`define ACELITE_ARSIZE_WIDTH	3
`define ACELITE_BURST_WIDTH 	2
`define ACELITE_ARLOCK_WIDTH	1
`define ACELITE_ACACHE_WIDTH	4
`define ACELITE_ACPROT_WIDTH	3
`define ACELITE_RID_WIDTH		16
`define ACELITE_RRESP_WIDTH 	2

// AXI3
`define AXI3_ADDR_WIDTH 		32
`define AXI3_AWID_WIDTH 		16
`define AXI3_AWLEN_WIDTH		4
`define AXI3_AWSIZE_WIDTH		3
`define AXI3_BURST_WIDTH		2
`define AXI3_AWLOCK_WIDTH		2
`define AXI3_ACACHE_WIDTH		4
`define AXI3_ACPROT_WIDTH		3
`define AXI3_DATA_WIDTH 		64
`define AXI3_WSTRB_WIDTH		8
`define AXI3_BID_WIDTH			16
`define AXI3_BRESP_WIDTH		2
`define AXI3_ARID_WIDTH 		16
`define AXI3_ARLEN_WIDTH		4
`define AXI3_ARSIZE_WIDTH		3
`define AXI3_BURST_WIDTH		2
`define AXI3_ARLOCK_WIDTH		2
`define AXI3_ACACHE_WIDTH		4
`define AXI3_ACPROT_WIDTH		3
`define AXI3_RID_WIDTH			16
`define AXI3_RRESP_WIDTH		2



`timescale 1ns/1ns
module hw_top;
   parameter DDWIDTH= (`USER_DATA_WIDTH <= 32) ? 32 : `USER_DATA_WIDTH;
   parameter DAWIDTH	=	22;
   parameter XDWIDTH=(DDWIDTH < 128) ? 256 : 2 * DDWIDTH ;
   parameter DATA_WIDTH = DDWIDTH;
   parameter ADDR_WIDTH = 32;
   parameter ID_WIDTH   = 16;
   
   parameter WSTRB_WIDTH = DATA_WIDTH/8;   
   
   parameter AXI4_BLEN_WIDTH = 8 ;
   parameter AXI3_BLEN_WIDTH = 4 ;
     
   parameter USER_WIDTH   = `USER_WIDTH_MACRO ;
   parameter XTOR_DEBUG_WIDTH     = 10 ;


// Global signals
   wire                   	ACLK;                       	// AXI Clock
   reg                    	ARESETn;                    	// AXI Reset
   wire                   	Reset;

// AXI4 extra signals
   wire [3:0]           	AXI4_AWQOS0,       AXI4_AWQOS1;
   wire [3:0]             	AXI4_ARQOS0,       AXI4_ARQOS1;
   wire [3:0]           	AXI4_AWREGION0,    AXI4_AWREGION1;
   wire [3:0]             	AXI4_ARREGION0,    AXI4_ARREGION1;
   wire [USER_WIDTH-1:0]    AXI4_BUSER0,       AXI4_BUSER1; 
   wire [USER_WIDTH-1:0]  	AXI4_RUSER0,       AXI4_RUSER1; 
   wire [USER_WIDTH-1:0]  	AXI4_AWUSER0,      AXI4_AWUSER1;
   wire [USER_WIDTH-1:0]    AXI4_ARUSER0,      AXI4_ARUSER1;
   wire [USER_WIDTH-1:0]    AXI4_WUSER0,       AXI4_WUSER1;

// ACELite extra signals
   wire  [USER_WIDTH-1:0] 	ACELITE_BUSER;    
   wire  [USER_WIDTH-1:0] 	ACELITE_RUSER;    
   wire [3:0]             	ACELITE_AWQOS;    
   wire [3:0]             	ACELITE_ARQOS;    
   wire [3:0]             	ACELITE_AWREGION; 
   wire [3:0]             	ACELITE_ARREGION; 
   wire [USER_WIDTH-1:0]  	ACELITE_AWUSER;   
   wire [USER_WIDTH-1:0]  	ACELITE_ARUSER;   
   wire [USER_WIDTH-1:0]  	ACELITE_WUSER;    
   wire [USER_WIDTH-1:0]  	ACELITE_RUSER;    
   wire [USER_WIDTH-1:0]  	ACELITE_BUSER;    
   wire [2:0]             	ACELITE_AWSNOOP;  
   wire [3:0]             	ACELITE_ARSNOOP;  
   wire [1:0]             	ACELITE_AWDOMAIN; 
   wire [1:0]             	ACELITE_ARDOMAIN; 
   wire [1:0]             	ACELITE_AWBAR;    
   wire [1:0]             	ACELITE_ARBAR;    

// AXI3_WID
   wire [15:0]             	AXI3_WID;

   wire resetcounter;
   reg [15:0] resetcnt;


`ifdef AXI2MEM_MEM_IF

// S0
wire 									shared_mem0_do_oe;
wire  [DAWIDTH+$clog2(DDWIDTH/8)-1:0] 	shared_mem0_addr;
wire  									shared_mem0_read;
wire  									shared_mem0_write;

wire [DATA_WIDTH-1:0] 					shared_mem0_data_to_ctrl;
wire [DATA_WIDTH-1:0] 					shared_mem0_ctrl_data_out;
wire [DATA_WIDTH/8-1:0] 				shared_mem0_wstrb;

// S1
wire 									shared_mem1_do_oe;
wire  [DAWIDTH+$clog2(DDWIDTH/8)-1:0] 	shared_mem1_addr;
wire  									shared_mem1_read;
wire  									shared_mem1_write;

wire [DATA_WIDTH-1:0] 					shared_mem1_data_to_ctrl;
wire [DATA_WIDTH-1:0] 					shared_mem1_ctrl_data_out;
wire [DATA_WIDTH/8-1:0] 				shared_mem1_wstrb;

// S2
wire 									shared_mem2_do_oe;
wire  [DAWIDTH+$clog2(DDWIDTH/8)-1:0] 	shared_mem2_addr;
wire  									shared_mem2_read;
wire  									shared_mem2_write;

wire [DATA_WIDTH-1:0] 					shared_mem2_data_to_ctrl;
wire [DATA_WIDTH-1:0] 					shared_mem2_ctrl_data_out;
wire [DATA_WIDTH/8-1:0] 				shared_mem2_wstrb;

// S3
wire 									shared_mem3_do_oe;
wire  [DAWIDTH+$clog2(DDWIDTH/8)-1:0] 	shared_mem3_addr;
wire  									shared_mem3_read;
wire  									shared_mem3_write;

wire [DATA_WIDTH-1:0] 					shared_mem3_data_to_ctrl;
wire [DATA_WIDTH-1:0] 					shared_mem3_ctrl_data_out;
wire [DATA_WIDTH/8-1:0] 				shared_mem3_wstrb;

`endif


// Memory read latency
wire  [4-1:0] 	do_latport;
genvar k;
generate
   for (k=0; k<4;k++)
      zebu_bb_wb_reg #(0) i_DO_LAT (.Q(do_latport[k]));      
endgenerate




   always@ (posedge ACLK or posedge resetcounter)
   begin
        if(resetcounter) begin
            resetcnt <= 16'h0000;
            ARESETn <= 1'b0;
        end else if (resetcnt[2] == 1'b1) begin
            ARESETn <= 1'b1;
        end else begin
            resetcnt <= resetcnt + 1;
            ARESETn <= 1'b0;
        end
    end

`ifndef SPNS_ZHAL_SEM
   initial begin : fwc_probe
	(* fwc *) $dumpvars(0, hw_top);
   end

   initial begin : qiwc_probe
	(* qiwc *) $dumpvars(0, hw_top);
   end
`else

   initial
     begin
        $fsdbDumpfile("dump.fsdb");
        $fsdbDumpvars(0,":hw_top","+mda","+struct","+all","+parameter");
        $fsdbDumpon;
        $fsdbDumpflush;
     end
     
`endif

zebu_clk_reset_gen i_zebu_clk_reset_gen(.clock(ACLK), .reset(resetcounter), .resetn());

// SRAM viewed as one block
localparam MRANK_NB = 4;
   
   mrank_itf   #(.DWIDTH(DDWIDTH),.AWIDTH(DAWIDTH))   mitfs[MRANK_NB]();
   FastMem #(.MRANK_NB (MRANK_NB)) i_fastmem (
      // DRAM side I/O
      .do_latport(do_latport) 
      ,.mitfs(mitfs)
    ); 
	
`ifdef AXI2MEM_MEM_IF

 // RAM 0
assign  hw_top.mitfs[0].clk    	=  hw_top.i_sram_0.clk;
assign  hw_top.mitfs[0].addr   	=  hw_top.i_sram_0.addr;
assign  hw_top.mitfs[0].re     	=  hw_top.i_sram_0.re;
assign  hw_top.mitfs[0].we     	=  hw_top.i_sram_0.we;
assign  hw_top.mitfs[0].be     	=  hw_top.i_sram_0.be;
assign  hw_top.mitfs[0].din    	=  hw_top.i_sram_0.din;
assign  hw_top.i_sram_0.dout	=  hw_top.mitfs[0].dout;
assign  hw_top.i_sram_0.do_oe	=  hw_top.mitfs[0].do_oe;

// RAM 1
assign  hw_top.mitfs[1].clk   	=  hw_top.i_sram_1.clk;
assign  hw_top.mitfs[1].addr  	=  hw_top.i_sram_1.addr;
assign  hw_top.mitfs[1].re    	=  hw_top.i_sram_1.re;
assign  hw_top.mitfs[1].we    	=  hw_top.i_sram_1.we;
assign  hw_top.mitfs[1].be    	=  hw_top.i_sram_1.be;
assign  hw_top.mitfs[1].din     =  hw_top.i_sram_1.din;
assign  hw_top.i_sram_1.dout	=  hw_top.mitfs[1].dout;
assign  hw_top.i_sram_1.do_oe	=  hw_top.mitfs[1].do_oe;

// RAM 2
assign  hw_top.mitfs[2].clk     =  hw_top.i_sram_2.clk;
assign  hw_top.mitfs[2].addr  	=  hw_top.i_sram_2.addr;
assign  hw_top.mitfs[2].re    	=  hw_top.i_sram_2.re;
assign  hw_top.mitfs[2].we    	=  hw_top.i_sram_2.we;
assign  hw_top.mitfs[2].be   	=  hw_top.i_sram_2.be;
assign  hw_top.mitfs[2].din   	=  hw_top.i_sram_2.din;
assign  hw_top.i_sram_2.dout	=  hw_top.mitfs[2].dout;
assign  hw_top.i_sram_2.do_oe	=  hw_top.mitfs[2].do_oe;

// RAM 3
assign  hw_top.mitfs[3].clk     =  hw_top.i_sram_3.clk;
assign  hw_top.mitfs[3].addr  	=  hw_top.i_sram_3.addr;
assign  hw_top.mitfs[3].re    	=  hw_top.i_sram_3.re;
assign  hw_top.mitfs[3].we   	=  hw_top.i_sram_3.we;
assign  hw_top.mitfs[3].be   	=  hw_top.i_sram_3.be;
assign  hw_top.mitfs[3].din 	=  hw_top.i_sram_3.din;
assign  hw_top.i_sram_3.dout	=  hw_top.mitfs[3].dout;
assign  hw_top.i_sram_3.do_oe	=  hw_top.mitfs[3].do_oe;
 
`else	

assign mitfs[0].clk = ACLK;
assign mitfs[1].clk = ACLK;
assign mitfs[2].clk = ACLK;
assign mitfs[3].clk = ACLK;

`endif	


// MANAGER 0 -> AXI4
// Write Address Channel from Manager 1
  wire                       		awvalid_m0;
  wire  [`AXI4_ADDR_WIDTH-1:0] 		awaddr_m0;
  wire  [`AXI4_AWID_WIDTH-1:0]    	awid_m0;
  wire  [`AXI4_AWLEN_WIDTH-1:0] 	awlen_m0;
  wire  [`AXI4_AWSIZE_WIDTH-1:0]  	awsize_m0;
  wire  [`AXI4_BURST_WIDTH-1:0]   	awburst_m0;
  wire  [`AXI4_AWLOCK_WIDTH-1:0]  	awlock_m0;
  wire  [`AXI4_ACACHE_WIDTH-1:0]  	awcache_m0;
  wire  [`AXI4_ACPROT_WIDTH-1:0]  	awprot_m0;

  wire                      		awready_m0;
  
// Write Data Channel from Manager 1
  wire                       		wvalid_m0;
  wire  [DATA_WIDTH-1:0]  			wdata_m0;
  wire  [WSTRB_WIDTH-1:0]   		wstrb_m0;
  wire                       		wlast_m0;
  wire                      		wready_m0;

// Write Response Channel from Manager 1
  wire                      		bvalid_m0;
  wire  [`AXI4_BID_WIDTH-1:0]   	bid_m0;
  wire	[`AXI4_BRESP_WIDTH-1:0] 	bresp_m0;
  wire                       		bready_m0;

// Read Address Channel from Manager 1
  wire                       		arvalid_m0;
  wire  [`AXI4_ARID_WIDTH-1:0]    	arid_m0;
  wire  [`AXI4_ADDR_WIDTH-1:0]    	araddr_m0;
  wire  [`AXI4_ARLEN_WIDTH-1:0] 	arlen_m0;
  wire  [`AXI4_ARSIZE_WIDTH-1:0]  	arsize_m0;
  wire  [`AXI4_BURST_WIDTH-1:0]   	arburst_m0;
  wire  [`AXI4_ARLOCK_WIDTH-1:0]  	arlock_m0;
  wire  [`AXI4_ACACHE_WIDTH-1:0]  	arcache_m0;
  wire  [`AXI4_ACPROT_WIDTH-1:0]  	arprot_m0;
  wire								arready_m0;

// Read Data Channel from Manager 1
  wire                      		rvalid_m0;
  wire	[`AXI4_RID_WIDTH-1:0]   	rid_m0;
  wire	[DATA_WIDTH-1:0]   			rdata_m0;
  wire                      		rlast_m0;
  wire	[`AXI4_RRESP_WIDTH-1:0] 	rresp_m0;
  wire                       		rready_m0;


// MANAGER 1 -> AXI4
// Write Address Channel from Manager 1
  wire                       		awvalid_m1;
  wire  [`AXI4_ADDR_WIDTH-1:0]  	awaddr_m1;
  wire  [`AXI4_AWID_WIDTH-1:0]  	awid_m1;
  wire  [`AXI4_AWLEN_WIDTH-1:0]   	awlen_m1;
  wire  [`AXI4_AWSIZE_WIDTH-1:0]  	awsize_m1;
  wire  [`AXI4_BURST_WIDTH-1:0] 	awburst_m1;
  wire  [`AXI4_AWLOCK_WIDTH-1:0]  	awlock_m1;
  wire  [`AXI4_ACACHE_WIDTH-1:0]  	awcache_m1;
  wire  [`AXI4_ACPROT_WIDTH-1:0]  	awprot_m1;
  wire                      		awready_m1;
  
// Write Data Channel from Manager 1
  wire                       		wvalid_m1;
  wire  [DATA_WIDTH-1:0]  			wdata_m1;
  wire  [WSTRB_WIDTH-1:0]   		wstrb_m1;
  wire                       		wlast_m1;
  wire                      		wready_m1;

// Write Response Channel from Manager 1
  wire                      		bvalid_m1;
  wire	[`AXI4_BID_WIDTH-1:0]  		bid_m1;
  wire	[`AXI4_BRESP_WIDTH-1:0] 	bresp_m1;
  wire                       		bready_m1;

// Read Address Channel from Manager 1
  wire                       		arvalid_m1;
  wire  [`AXI4_ARID_WIDTH-1:0]  	arid_m1;
  wire  [`AXI4_ADDR_WIDTH-1:0]  	araddr_m1;
  wire  [`AXI4_ARLEN_WIDTH-1:0] 	arlen_m1;
  wire  [`AXI4_ARSIZE_WIDTH-1:0]	arsize_m1;
  wire  [`AXI4_BURST_WIDTH-1:0]   	arburst_m1;
  wire  [`AXI4_ARLOCK_WIDTH-1:0]  	arlock_m1;
  wire  [`AXI4_ACACHE_WIDTH-1:0]  	arcache_m1;
  wire  [`AXI4_ACPROT_WIDTH-1:0]  	arprot_m1;
  wire								arready_m1;

// Read Data Channel from Manager 1
  wire                      		rvalid_m1;
  wire	[`AXI4_RID_WIDTH-1:0]      	rid_m1;
  wire	[DATA_WIDTH-1:0]   			rdata_m1;
  wire                      		rlast_m1;
  wire	[`AXI4_RRESP_WIDTH-1:0]  	rresp_m1;
  wire                       		rready_m1;

  
  
// MANAGER 2 -> ACELITE
// Write Address Channel from Manager2
  wire                       		awvalid_m2;
  wire  [`ACELITE_ADDR_WIDTH-1:0]  	awaddr_m2;
  wire  [`ACELITE_AWID_WIDTH-1:0]   awid_m2;
  wire  [`ACELITE_AWLEN_WIDTH-1:0] 	awlen_m2;
  wire  [`ACELITE_AWSIZE_WIDTH-1:0] awsize_m2;
  wire  [`ACELITE_BURST_WIDTH-1:0]  awburst_m2;
  wire  [`ACELITE_AWLOCK_WIDTH-1:0] awlock_m2;
  wire  [`ACELITE_ACACHE_WIDTH-1:0] awcache_m2;
  wire  [`ACELITE_ACPROT_WIDTH-1:0] awprot_m2;
  wire                      		awready_m2;

// Write Data Channel from Manager2
  wire                       		wvalid_m2;
  wire  [DATA_WIDTH-1:0]    		wdata_m2;
  wire  [WSTRB_WIDTH-1:0]			wstrb_m2;
  wire                       		wlast_m2;
  wire                      		wready_m2;

// Write Response Channel from Manager2
  wire                      		bvalid_m2;
  wire	[`ACELITE_BID_WIDTH-1:0]  	bid_m2;
  wire	[`ACELITE_BRESP_WIDTH-1:0]	bresp_m2;
  wire                       		bready_m2;

// Read Address Channel from Manager2
  wire                       		arvalid_m2;
  wire  [`ACELITE_ARID_WIDTH-1:0]  	arid_m2;
  wire  [`ACELITE_ADDR_WIDTH-1:0] 	araddr_m2;
  wire  [`ACELITE_ARLEN_WIDTH-1:0]  arlen_m2;
  wire  [`ACELITE_ARSIZE_WIDTH-1:0] arsize_m2;
  wire  [`ACELITE_BURST_WIDTH-1:0]  arburst_m2;
  wire  [`ACELITE_ARLOCK_WIDTH-1:0] arlock_m2;
  wire  [`ACELITE_ACACHE_WIDTH-1:0] arcache_m2;
  wire  [`ACELITE_ACPROT_WIDTH-1:0]	arprot_m2;
  wire                      		arready_m2;

// Read Data Channel from Manager2
  wire                      		rvalid_m2;
  wire	[`ACELITE_RID_WIDTH-1:0]    rid_m2;
  wire	[DATA_WIDTH-1:0]			rdata_m2;
  wire                      		rlast_m2;
  wire	[`ACELITE_RRESP_WIDTH-1:0]  rresp_m2;
  wire                      		rready_m2;
 
 
 
// MANAGER 3 -> AXI3
// Write Address Channel from Manager3
  wire                       		awvalid_m3;
  wire  [`AXI3_ADDR_WIDTH-1:0]    	awaddr_m3;
  wire  [`AXI3_AWID_WIDTH-1:0]    	awid_m3; 
  wire  [`AXI3_AWLEN_WIDTH-1:0]   	awlen_m3;
  wire  [`AXI3_AWSIZE_WIDTH-1:0]  	awsize_m3;
  wire  [`AXI3_BURST_WIDTH-1:0]   	awburst_m3;
  wire  [`AXI3_AWLOCK_WIDTH-1:0]  	awlock_m3;
  wire  [`AXI3_ACACHE_WIDTH-1:0]  	awcache_m3;
  wire  [`AXI3_ACPROT_WIDTH-1:0]	awprot_m3;
  wire                      		awready_m3;

// Write Data Channel from Manager3
  wire                       		wvalid_m3;
  wire  [DATA_WIDTH-1:0]    		wdata_m3;
  wire  [WSTRB_WIDTH-1:0]   		wstrb_m3;
  wire                       		wlast_m3;
  wire                      		wready_m3;

// Write Response Channel from Manager3
  wire                      		bvalid_m3;
  wire	[`AXI3_BID_WIDTH-1:0]  		bid_m3;
  wire	[`AXI3_BRESP_WIDTH-1:0] 	bresp_m3;
  wire                       		bready_m3;

// Read Address Channel from Manager3
  wire                       		arvalid_m3;
  wire  [`AXI3_ARID_WIDTH-1:0]  	arid_m3;
  wire  [`AXI3_ADDR_WIDTH-1:0] 		araddr_m3;
  wire  [`AXI3_ARLEN_WIDTH-1:0]   	arlen_m3;
  wire  [`AXI3_ARSIZE_WIDTH-1:0]	arsize_m3;
  wire  [`AXI3_BURST_WIDTH-1:0]   	arburst_m3;
  wire  [`AXI3_ARLOCK_WIDTH-1:0]  	arlock_m3;
  wire  [`AXI3_ACACHE_WIDTH-1:0]  	arcache_m3;
  wire  [`AXI3_ACPROT_WIDTH-1:0]	arprot_m3;
  wire                      		arready_m3;
 
// Read Data Channel from Manager3
  wire                      		rvalid_m3;
  wire	[`AXI3_RID_WIDTH-1:0]   	rid_m3;
  wire	[DATA_WIDTH-1:0]  			rdata_m3;
  wire                      		rlast_m3;
  wire	[`AXI3_RRESP_WIDTH-1:0]  	rresp_m3;
  wire                       		rready_m3;


  zebu_axi_mem_ctrl #(
       // .AWIDTH  (DAWIDTH+$clog2(DDWIDTH/8)),
        .DWIDTH  (DATA_WIDTH)       
   )
   i_axi_mem_ctrl_0
     (
      	.awaddr(awaddr_m0), .awid(awid_m0), .awlen(awlen_m0), .awsize(awsize_m0), .awprot(awprot_m0), .awburst(awburst_m0),
      	.awlock(awlock_m0), .awcache(awcache_m0), .awvalid(awvalid_m0), .awready(awready_m0), .wdata(wdata_m0),  .wstrb(wstrb_m0),
	.wlast(wlast_m0), .wvalid(wvalid_m0), .wready(wready_m0), .bid(bid_m0), .bresp(bresp_m0), .bvalid(bvalid_m0), .bready(bready_m0),
      	.araddr(araddr_m0), .arid(arid_m0), .arlen(arlen_m0), .arsize(arsize_m0), .arprot(arprot_m0), .arburst(arburst_m0),
      	.arlock(arlock_m0), .arcache(arcache_m0), .arvalid(arvalid_m0), .arready(arready_m0),     .rdata(rdata_m0), .rid(rid_m0),
	.rresp(rresp_m0), .rlast(rlast_m0), .rvalid(rvalid_m0), .rready(rready_m0), .aresetn(ARESETn), .aclk(ACLK),.gclken(1'b1),

 `ifdef AXI2MEM_MEM_IF
         // Memory INF
		.do_oe(shared_mem0_do_oe), .data_from_mem(shared_mem0_data_to_ctrl), .mem_read(shared_mem0_read), .mem_write(shared_mem0_write),
		.mem_addr(shared_mem0_addr), .data_to_mem(shared_mem0_ctrl_data_out),.mem_wstrb(shared_mem0_wstrb)
`else
         // Memory INF
         .mitf(mitfs[0])
`endif
      
      );




   zebu_axi_mem_ctrl #(
        //.AWIDTH  (DAWIDTH+$clog2(DDWIDTH/8)),
        .DWIDTH  (DATA_WIDTH)       
   )
   i_axi_mem_ctrl_1
     (
      	.awaddr(awaddr_m1), .awid(awid_m1), .awlen(awlen_m1), .awsize(awsize_m1), .awprot(awprot_m1), .awburst(awburst_m1),
      	.awlock(awlock_m1), .awcache(awcache_m1), .awvalid(awvalid_m1), .awready(awready_m1), .wdata(wdata_m1),  .wstrb(wstrb_m1),
	.wlast(wlast_m1), .wvalid(wvalid_m1), .wready(wready_m1), .bid(bid_m1), .bresp(bresp_m1), .bvalid(bvalid_m1), .bready(bready_m1),
      	.araddr(araddr_m1), .arid(arid_m1), .arlen(arlen_m1), .arsize(arsize_m1), .arprot(arprot_m1), .arburst(arburst_m1),
      	.arlock(arlock_m1), .arcache(arcache_m1), .arvalid(arvalid_m1), .arready(arready_m1),     .rdata(rdata_m1), .rid(rid_m1),
	.rresp(rresp_m1), .rlast(rlast_m1), .rvalid(rvalid_m1), .rready(rready_m1), .aresetn(ARESETn), .aclk(ACLK),.gclken(1'b1),
      

`ifdef AXI2MEM_MEM_IF
         // Memory INF
		.do_oe(shared_mem1_do_oe), .data_from_mem(shared_mem1_data_to_ctrl), .mem_read(shared_mem1_read), .mem_write(shared_mem1_write),
		.mem_addr(shared_mem1_addr), .data_to_mem(shared_mem1_ctrl_data_out),.mem_wstrb(shared_mem1_wstrb)
`else      
         // Memory INF
         .mitf(mitfs[1])
`endif	 
 
      );

   zebu_axi_mem_ctrl #(
        //.AWIDTH  (DAWIDTH+$clog2(DDWIDTH/8)),
        .DWIDTH  (DATA_WIDTH)       
   )
   i_axi_mem_ctrl_2
     (
      	.awaddr(awaddr_m2), .awid(awid_m2), .awlen(awlen_m2), .awsize(awsize_m2), .awprot(awprot_m2), .awburst(awburst_m2),
      	.awlock(awlock_m2), .awcache(awcache_m2), .awvalid(awvalid_m2), .awready(awready_m2), .wdata(wdata_m2),  .wstrb(wstrb_m2),
	.wlast(wlast_m2), .wvalid(wvalid_m2), .wready(wready_m2), .bid(bid_m2), .bresp(bresp_m2), .bvalid(bvalid_m2), .bready(bready_m2),
      	.araddr(araddr_m2), .arid(arid_m2), .arlen(arlen_m2), .arsize(arsize_m2), .arprot(arprot_m2), .arburst(arburst_m2),
      	.arlock(arlock_m2), .arcache(arcache_m2), .arvalid(arvalid_m2), .arready(arready_m2),     .rdata(rdata_m2), .rid(rid_m2),
	.rresp(rresp_m2), .rlast(rlast_m2), .rvalid(rvalid_m2), .rready(rready_m2), .aresetn(ARESETn), .aclk(ACLK),.gclken(1'b1),

`ifdef AXI2MEM_MEM_IF
         // Memory INF
		.do_oe(shared_mem2_do_oe), .data_from_mem(shared_mem2_data_to_ctrl), .mem_read(shared_mem2_read), .mem_write(shared_mem2_write),
		.mem_addr(shared_mem2_addr), .data_to_mem(shared_mem2_ctrl_data_out),.mem_wstrb(shared_mem2_wstrb)
`else     
         // Memory INF
         .mitf(mitfs[2])
`endif 

      );


   zebu_axi_mem_ctrl #(
        //.AWIDTH  (DAWIDTH+$clog2(DDWIDTH/8)),
        .DWIDTH  (DATA_WIDTH)       
   )
   i_axi_mem_ctrl_3
     (
      	.awaddr(awaddr_m3), .awid(awid_m3), .awlen(awlen_m3), .awsize(awsize_m3), .awprot(awprot_m3), .awburst(awburst_m3),
      	.awlock(awlock_m3), .awcache(awcache_m3), .awvalid(awvalid_m3), .awready(awready_m3), .wdata(wdata_m3),  .wstrb(wstrb_m3),
	.wlast(wlast_m3), .wvalid(wvalid_m3), .wready(wready_m3), .bid(bid_m3), .bresp(bresp_m3), .bvalid(bvalid_m3), .bready(bready_m3),
      	.araddr(araddr_m3), .arid(arid_m3), .arlen(arlen_m3), .arsize(arsize_m3), .arprot(arprot_m3), .arburst(arburst_m3),
      	.arlock(arlock_m3), .arcache(arcache_m3), .arvalid(arvalid_m3), .arready(arready_m3),     .rdata(rdata_m3), .rid(rid_m3),
	.rresp(rresp_m3), .rlast(rlast_m3), .rvalid(rvalid_m3), .rready(rready_m3), .aresetn(ARESETn), .aclk(ACLK),.gclken(1'b1),
 
 
 `ifdef AXI2MEM_MEM_IF
         // Memory INF
		.do_oe(shared_mem3_do_oe), .data_from_mem(shared_mem3_data_to_ctrl), .mem_read(shared_mem3_read), .mem_write(shared_mem3_write),
		.mem_addr(shared_mem3_addr), .data_to_mem(shared_mem3_ctrl_data_out),.mem_wstrb(shared_mem3_wstrb)
`else      
         // Memory INF
         .mitf(mitfs[3])
`endif 
      
      );

      
// wire [7:0]   IRQ_IN__0;
bit [XTOR_DEBUG_WIDTH-1:0] xtor_axi4_target_info0;
xtor_amba_master_axi4_svs #(
                            .DATA_WIDTH (DATA_WIDTH),
                            .ADDR_WIDTH (ADDR_WIDTH), 
                            .ID_WIDTH   (ID_WIDTH), 
                            .WSTRB_WIDTH(WSTRB_WIDTH), 
                            .BLEN_WIDTH (AXI4_BLEN_WIDTH),
                            .USER_WIDTH(USER_WIDTH), 
                            .XTOR_DEBUG_WIDTH(XTOR_DEBUG_WIDTH)
                            ) xtor_axi4_target0 (   
				.ACLK(ACLK),
				.ARESETn(ARESETn),
      
      			.WDATA(wdata_m0),
      			.WSTRB(wstrb_m0),
      			.WLAST(wlast_m0),
				.WVALID(wvalid_m0),
				.WREADY(wready_m0),
				.AWADDR(awaddr_m0),
				.AWID(awid_m0),
				.AWLEN(awlen_m0),
				.AWSIZE(awsize_m0),
				.AWPROT(awprot_m0),
				.AWBURST(awburst_m0),
				.AWLOCK(awlock_m0),
				.AWCACHE(awcache_m0),
				.AWVALID(awvalid_m0),
				.AWREADY(awready_m0),
				.BID(bid_m0),
				.BRESP(bresp_m0),
				.BVALID(bvalid_m0),
				.BREADY(bready_m0),
	
				.ARADDR(araddr_m0),
				.ARID(arid_m0),
				.ARLEN(arlen_m0),
				.ARSIZE(arsize_m0),
				.ARPROT(arprot_m0),
				.ARBURST(arburst_m0),
				.ARLOCK(arlock_m0),
				.ARCACHE(arcache_m0),
				.ARVALID(arvalid_m0),
				.ARREADY(arready_m0),
				.RDATA(rdata_m0),
				.RID(rid_m0),
				.RRESP(rresp_m0),
				.RLAST(rlast_m0),
				.RVALID(rvalid_m0),
				.RREADY(rready_m0),
				.AWQOS(AXI4_AWQOS0),
				.ARQOS(AXI4_ARQOS0),
				.AWREGION(AXI4_AWREGION0),
				.ARREGION(AXI4_ARREGION0),
				.AWUSER(AXI4_AWUSER0),
				.ARUSER(AXI4_ARUSER0),
				.WUSER(AXI4_WUSER0),
				.RUSER(AXI4_RUSER0),
				.BUSER(AXI4_BUSER0),
	
				.xtor_info_port(xtor_axi4_target_info0)
      			    );
bit [XTOR_DEBUG_WIDTH-1:0] xtor_axi4_target_info1;
xtor_amba_master_axi4_svs #(
                            .DATA_WIDTH (DATA_WIDTH),
                            .ADDR_WIDTH (ADDR_WIDTH), 
                            .ID_WIDTH   (ID_WIDTH), 
                            .WSTRB_WIDTH(WSTRB_WIDTH), 
                            .BLEN_WIDTH (AXI4_BLEN_WIDTH),
                            .USER_WIDTH(USER_WIDTH), 
                            .XTOR_DEBUG_WIDTH(XTOR_DEBUG_WIDTH)
                            ) xtor_axi4_target1 (   
				.ACLK(ACLK),
				.ARESETn(ARESETn),    
      			.WDATA(wdata_m1),
      			.WSTRB(wstrb_m1),
      			.WLAST(wlast_m1),
				.WVALID(wvalid_m1),
				.WREADY(wready_m1),
				.AWADDR(awaddr_m1),
				.AWID(awid_m1),
				.AWLEN(awlen_m1),
				.AWSIZE(awsize_m1),
				.AWPROT(awprot_m1),
				.AWBURST(awburst_m1),
				.AWLOCK(awlock_m1),
				.AWCACHE(awcache_m1),
				.AWVALID(awvalid_m1),
				.AWREADY(awready_m1),
				.BID(bid_m1),
				.BRESP(bresp_m1),
				.BVALID(bvalid_m1),
				.BREADY(bready_m1),	
				.ARADDR(araddr_m1),
				.ARID(arid_m1),
				.ARLEN(arlen_m1),
				.ARSIZE(arsize_m1),
				.ARPROT(arprot_m1),
				.ARBURST(arburst_m1),
				.ARLOCK(arlock_m1),
				.ARCACHE(arcache_m1),
				.ARVALID(arvalid_m1),
				.ARREADY(arready_m1),
				.RDATA(rdata_m1),
				.RID(rid_m1),
				.RRESP(rresp_m1),
				.RLAST(rlast_m1),
				.RVALID(rvalid_m1),
				.RREADY(rready_m1),
				.AWQOS(AXI4_AWQOS1),
				.ARQOS(AXI4_ARQOS1),
				.AWREGION(AXI4_AWREGION1),
				.ARREGION(AXI4_ARREGION1),
				.AWUSER(AXI4_AWUSER1),
				.ARUSER(AXI4_ARUSER1),
				.WUSER(AXI4_WUSER1),
				.RUSER(AXI4_RUSER1),
				.BUSER(AXI4_BUSER1),
	
				.xtor_info_port(xtor_axi4_target_info1)
      			    );


bit [XTOR_DEBUG_WIDTH-1 :0] xtor_acelite_target_info;
xtor_amba_master_acelite_svs #( .DATA_WIDTH (DATA_WIDTH),
                                .ADDR_WIDTH (ADDR_WIDTH), 
                                .ID_WIDTH   (ID_WIDTH), 
                                .WSTRB_WIDTH(WSTRB_WIDTH), 
                                .USER_WIDTH(USER_WIDTH), 
                                .XTOR_DEBUG_WIDTH(XTOR_DEBUG_WIDTH)
                              ) xtor_acelite_target (
                                  .ACLK(ACLK),
                                  .ARESETn(ARESETn),

                                  .WDATA(wdata_m2),  
                                  .WSTRB(wstrb_m2), 
                                  .WLAST(wlast_m2), 
                                  .WVALID(wvalid_m2), 
                                  .WREADY(wready_m2), 
                                  .AWADDR(awaddr_m2), 
                                  .AWID(awid_m2), 
                                  .AWLEN(awlen_m2), 
                                  .AWSIZE(awsize_m2), 
                                  .AWPROT(awprot_m2), 
                                  .AWBURST(awburst_m2), 
                                  .AWCACHE(awcache_m2), 
                                  .AWVALID(awvalid_m2), 
                                  .AWREADY(awready_m2), 
                                  .AWLOCK(awlock_m2),
                                  .BID(bid_m2), 
                                  .BRESP(bresp_m2), 
                                  .BVALID(bvalid_m2), 
                                  .BREADY(bready_m2), 
				  
                                  .ARADDR(araddr_m2), 
                                  .ARID(arid_m2), 
                                  .ARLEN(arlen_m2), 
                                  .ARSIZE(arsize_m2), 
                                  .ARPROT(arprot_m2), 
                                  .ARBURST(arburst_m2), 
                                  .ARCACHE(arcache_m2), 
                                  .ARVALID(arvalid_m2), 
                                  .ARREADY(arready_m2), 
                                  .ARLOCK(arlock_m2),
                                  .RDATA(rdata_m2), 
                                  .RID(rid_m2), 
                                  .RRESP(rresp_m2), 
                                  .RLAST(rlast_m2), 
                                  .RVALID(rvalid_m2), 
                                  .RREADY(rready_m2),
                                  .AWQOS(ACELITE_AWQOS),                                                        
                                  .ARQOS(ACELITE_ARQOS),                                                        
                                  .AWREGION(ACELITE_AWREGION),                                                     
                                  .ARREGION(ACELITE_ARREGION),                                                     
                                  .AWUSER(ACELITE_AWUSER),                                                       
                                  .ARUSER(ACELITE_ARUSER),                                                       
                                  .WUSER(ACELITE_WUSER),                                                        
                                  .RUSER(ACELITE_RUSER),                                                        
                                  .BUSER(ACELITE_BUSER),                                                        
                                  .AWSNOOP(ACELITE_AWSNOOP),                                                      
                                  .ARSNOOP(ACELITE_ARSNOOP),                                                      
                                  .AWDOMAIN(ACELITE_AWDOMAIN),                                                     
                                  .ARDOMAIN(ACELITE_ARDOMAIN),                                                     
                                  .AWBAR(ACELITE_AWBAR),                                                        
                                  .ARBAR(ACELITE_ARBAR), 
				                                                         
                                  .xtor_info_port(xtor_acelite_target_info)
                              );



bit [XTOR_DEBUG_WIDTH-1:0] xtor_axi3_target_info;
xtor_amba_master_axi3_svs #(
                            .DATA_WIDTH (DATA_WIDTH),
                            .ADDR_WIDTH (ADDR_WIDTH), 
                            .ID_WIDTH   (ID_WIDTH), 
                            .WSTRB_WIDTH(WSTRB_WIDTH), 
                            .BLEN_WIDTH (AXI3_BLEN_WIDTH),
                            .AXI3_INTERLEAVE_DEPTH(1),
                            .XTOR_DEBUG_WIDTH(XTOR_DEBUG_WIDTH)
                            ) xtor_axi3_target(
                		.ACLK(ACLK),
                		.ARESETn(ARESETn),
 	               
                		.WDATA(wdata_m3),
                		.WSTRB(wstrb_m3),
                		.WLAST(wlast_m3),
                		.WVALID(wvalid_m3),
                		.WREADY(wready_m3),
                		.WID(AXI3_WID),
                
                		.AWADDR(awaddr_m3),
                		.AWID(awid_m3),
                		.AWLEN(awlen_m3),
                		.AWSIZE(awsize_m3),
                		.AWPROT(awprot_m3),
                		.AWBURST(awburst_m3),
                		.AWLOCK(awlock_m3),
                		.AWCACHE(awcache_m3),
                		.AWVALID(awvalid_m3),
                		.AWREADY(awready_m3),
                
                		.BID(bid_m3),
                		.BRESP(bresp_m3),
                		.BVALID(bvalid_m3),
                		.BREADY(bready_m3),
                
                		.ARADDR(araddr_m3),
                		.ARID(arid_m3),
                		.ARLEN(arlen_m3),
                		.ARSIZE(arsize_m3),
                		.ARPROT(arprot_m3),
                		.ARBURST(arburst_m3),
                		.ARLOCK(arlock_m3),
                		.ARCACHE(arcache_m3),
                		.ARVALID(arvalid_m3),
                		.ARREADY(arready_m3),
                
                		.RDATA(rdata_m3),
                		.RID(rid_m3),
                		.RRESP(rresp_m3),
                		.RLAST(rlast_m3),
                		.RVALID(rvalid_m3),
                		.RREADY(rready_m3),
                
                		.xtor_info_port(xtor_axi3_target_info)
            			);

`ifdef AXI2MEM_MEM_IF

zebu_sram #( .AWIDTH(DAWIDTH), .DWIDTH(DDWIDTH)) i_sram_0 (
    	.din(shared_mem0_ctrl_data_out),
    	.dout(shared_mem0_data_to_ctrl),
    	.addr(shared_mem0_addr >> $clog2(DDWIDTH/8)),
    	.we(shared_mem0_write),
    	.re(shared_mem0_read),
    	.do_latport(do_latport),
    	.do_oe(shared_mem0_do_oe),
    	.be(shared_mem0_wstrb),
    	.clk(ACLK)	      	   
    	);


zebu_sram #( .AWIDTH(DAWIDTH), .DWIDTH(DDWIDTH)) i_sram_1 (
    	.din(shared_mem1_ctrl_data_out),
    	.dout(shared_mem1_data_to_ctrl),
    	.addr(shared_mem1_addr >> $clog2(DDWIDTH/8)),
    	.we(shared_mem1_write),
    	.re(shared_mem1_read),
    	.do_latport(do_latport),
    	.do_oe(shared_mem1_do_oe),
    	.be(shared_mem1_wstrb),
    	.clk(ACLK)	      	   
    	);

zebu_sram #( .AWIDTH(DAWIDTH), .DWIDTH(DDWIDTH)) i_sram_2 (
    	.din(shared_mem2_ctrl_data_out),
    	.dout(shared_mem2_data_to_ctrl),
    	.addr(shared_mem2_addr >> $clog2(DDWIDTH/8)),
    	.we(shared_mem2_write),
    	.re(shared_mem2_read),
    	.do_latport(do_latport),
    	.do_oe(shared_mem2_do_oe),
    	.be(shared_mem2_wstrb),
    	.clk(ACLK)	      	   
    	);
	
zebu_sram #( .AWIDTH(DAWIDTH), .DWIDTH(DDWIDTH)) i_sram_3 (
    	.din(shared_mem3_ctrl_data_out),
    	.dout(shared_mem3_data_to_ctrl),
    	.addr(shared_mem3_addr >> $clog2(DDWIDTH/8)),
    	.we(shared_mem3_write),
    	.re(shared_mem3_read),
    	.do_latport(do_latport),
    	.do_oe(shared_mem3_do_oe),
    	.be(shared_mem3_wstrb),
    	.clk(ACLK)	      	   
    	);
		
`endif	

// `ifdef ZEBU_NO_RTB
// defparam AXIDriver0.ACLKCtrl = "hw_top.ACLK_ClockPort";
// `endif
   
endmodule // top


