# Based on ZHAL-API documentation, acomplishe the following:

# 1. Create waves db

# 2. Start waves dumping

# 3. Choose a test to run using auto_run

# 4. Set a HW time trigger and close waves dumping when reached
