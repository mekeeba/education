
import time
import sys
import os


global uart_console

uart_console = vpx.get_node("/startingKitVDK/Periphs/UART_PHY")

# Update count register value
def update_count_register(value):  
    count_reg = zhal.find_signal('hybrid_tb.hybrid_top.count_reg')
    count_reg.write_word32(value)   

# Resume platform run            
def run_platform():
    vpx.continue_simulation()
    
    
# Function to auto-type command on UART console
def uart_console_autotype(command_line, delay_interval):
    print('SCRIPT-INFO: Typing: '+command_line)
    uart_console.send_command('push "'+command_line+'" ')
    add_delay(delay_interval)

def add_delay(delay_interval):
    time.sleep(delay_interval)

# Auto-run test #1
def auto_run_test_1():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("1\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)

# Auto-run test #2 
def auto_run_test_2():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("2\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)

# Auto-run test #3    
def auto_run_test_3():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)

# Auto-run test #4    
def auto_run_test_4():
    uart_console_autotype("C\n", 1)
    uart_console_autotype("3\n", 1)
    uart_console_autotype("T\n", 1)
    uart_console_autotype("4\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)
    uart_console_autotype("X\n", 1)   



run_platform() 
add_delay(5)
auto_run_test_1()
auto_run_test_2() 
