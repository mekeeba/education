# $1: target_so
# $2: source files
# [$3]: extra flags, include dirs, lib dirs
# [$4]: extra libs (e.g. -lmylib)
define build_ext_so
  $(call __build_ext,1,$1,$2,$3,$4)
endef

# $1: target_exe
# $2: source files
# [$3]: extra flags, include dirs, lib dirs
# [$4]: extra libs (e.g. -lmylib)
define build_ext_exe
  $(call __build_ext,,$1,$2,$3,$4)
endef


### Internal: do NOT use!
define __build_ext
  $(eval _iext_is_so   := $1)
  $(eval _iext_target  := $(strip $2))
  $(eval _iext_sources := $(strip $3))
  $(eval _iext_flags   := $(strip $4))
  $(eval _iext_libs    := $(strip $5))
  @#---------------------------

  $(eval _ext_includes := -I$(SRC_DIR) -I$(ZEBU_ROOT)/include -I$(ZEBU_IP_ROOT)/include)
  $(eval _ext_includes += -I$(COMMON_DIR)/infra/testframework/include)

  $(eval _ext_libdirs := -L$(ZEBU_ROOT)/lib -L$(ZEBU_IP_ROOT)/lib)
  $(eval _ext_libdirs += -L$(COMMON_DIR)/infra/testframework/lib)

  $(eval _ext_cflags := -std=c++14 -O3 -g -Wall -fexceptions)
  $(if $(_iext_is_so), $(eval _ext_cflags += -fPIC -shared),)
  $(eval _ext_cflags += -DNORM_ZEBU_VER=$(NORM_ZEBU_VER) -DNORM_ZEBUIP_VER=$(NORM_ZEBUIP_VER))
  $(eval _ext_cflags += $(_ext_includes) $(_ext_libdirs)  $(_iext_flags))
  $(if $(shell [[ "$(NORM_ZEBU_VER)" -lt 2021090001 ]] && echo 1), $(eval _ext_cflags+=-D_GLIBCXX_USE_CXX11_ABI=0),)

  $(eval _ext_libs := -lZebuXtor -lZebu -lZebuVpi -lZebuZEMI3 -lpthread -lzmq)
  $(eval _ext_libs += $(_iext_libs))
  @#---------------------------

  @echo "building external object..."
  g++ -o $(_iext_target) $(_iext_sources) $(_ext_cflags) $(_ext_libs)
  @echo "building external object done"
endef

