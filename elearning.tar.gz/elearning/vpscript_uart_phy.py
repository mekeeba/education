print ("vpscript_auto.py [INFO]  Start")

#############################################################################
# sets up the remote control to type in commands automatically.
#############################################################################

def get_path_to_current_vpconfig():    
    vpCfg = vpx.get_current_vpconfig()    
    vpCfgPath = os.path.dirname(vpCfg.get_path())    
    vpCfg.dispose()    
    return vpCfgPath


def setup_uart_remote_control(soc_uart_phy_name, generate_uart_commands='False'):
    args = [
        soc_uart_phy_name,
        generate_uart_commands,
     ]
    vpconfig_dir = get_path_to_current_vpconfig()    
    vpx.create_sim_python_thread(os.path.join(vpconfig_dir, 'uart_remote_control.py'), ' '.join(args))
     

#############################################################################
# connected callback
#############################################################################

def initial_crunch_auto_cb(sim):  
    # setup the remote control 
    setup_uart_remote_control("/startingKitVDK/Periphs/UART_PHY", 'True')

def connected_auto_cb(sim):
    if (vpx.get_breakpoint_count() == 0):
        print('[ERROR] VPX failed.. Number of breakpoints is zero!!')
        shutdown()
    else:
        vpx.get_breakpoint(0).set_callback('initial_crunch_auto_cb(__sim__)')

def update_callbacks(enable):
    if (enable == True):
        vpx.add_callback('connected', 'connected_auto_cb(__sim__)')     
    else:
        vpx.remove_callback('connected', 'connected_auto_cb(__sim__)')
          
update_callbacks(True)    
