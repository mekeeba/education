
# INPUTS:
#   - TEST_DIR : Specify the test directory
#   - [RUN_DIR]: Specify test run/build output directory
#   - [RUN_ARGS] : add cli arguments for test runner (see $(TESTFRAMEWORK_DIR)/bin/run_test.py)
#   - [RUN_ENV]  : add env variable definition before calling test runner
#   - [RUN_PRE_LD_LIB_PATH / RUN_POS_LD_LIB_PATH]: append / prepend a path to the LD_LIBRARY_PATH envar 
##############################################

THIS_DIR := $(dir $(abspath $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))))
include $(THIS_DIR)/variables.mk

ifeq ($(TEST_DIR),)
  $(error no TEST_DIR is specified!)
endif

##############################################
QUIET           ?= @

TEST_NAME       ?= $(notdir $(abspath .))
TEST_REPORTER   ?= /dev/null
RUN_LOGFILE     ?= run_simulation.log
BUILD_TIMEOUT   ?= 20m
RUN_TIMEOUT     ?= 1200 #20m
GOLDEN_MASK     ?= ZTLM_SYSTEM_MANAGER
GOLDEN_FILENAME ?= SIMOUT.golden
BUILD_DONE      ?= $(RUN_DIR)/build_done

TESTFRAMEWORK_DIR ?= $(COMMON_DIR)/infra/testframework

# If needed to rename designFeatures file based on design' clock mode
HW_CLOCK_MODE_LOWER_CASE  = $(shell echo $(HW_CLOCK_MODE) | tr A-Z a-z)
DESIGN_FEATURES_FILE ?= $(HW_CLOCK_MODE_LOWER_CASE).designFeatures

ifneq ($(call f_file-exists,$(SRC_DIR)/run.py),)
  RUN_SIM_SCRIPT ?= $(SRC_DIR)/run.py
endif

ifneq ($(call f_file-exists,$(SRC_DIR)/project.tcl),)
  build_platform: build_pcsh
  RUN_SIM_EXE       ?= $(RUN_DIR)/Debug/sim
  RUN_VPCONFIG  ?= $(RUN_DIR)/vpconfigs/Default/Default.vpcfg
else ifneq ($(call f_file-exists,$(SRC_DIR)/project.py),)
  build_platform: build_vssh
  VS_VDK_NAME   ?= vdk
  VS_WORKSPACE  ?= $(RUN_DIR)/workspace
  RUN_SIM_EXE       ?= $(VS_WORKSPACE)/$(VS_VDK_NAME)/bin/export/Release/sim
  RUN_VPCONFIG  ?= $(VS_WORKSPACE)/$(VS_VDK_NAME)/vpconfigs/default/default.vpcfg
else
  $(error source dir MUST have either a project.tcl or a project.py script !)
endif

# Retrun "" (empty) is the pattern is NOT found in the RUN_SIM_SCRIPT name, non-empty otherwise.
# $1: pattern to match against the RUN_SIM_SCRIPT filename. Can contain multiple space-separated words, in which case the first match is reported
# e.g.: ifneq ($(call match_run_script,TestXXX TestYYY),) # taken if RUN_SIM_SCRIPT name has "TestXXX" or has "TestYYY"
match_run_script = $(shell for w in $1; do echo "$(notdir $(RUN_SIM_SCRIPT))" | grep "$$w" && break; done)

##########################################
$(RUN_DIR):
	@ echo "Creating tmp run dir $(RUN_DIR) ..."
	$(QUIET) mkdir -p $(RUN_DIR)

##########################################
### Link design DB 
.PHONY: design_link

ifneq ($(TEST_HAS_DESIGN),1)
  design_link:
	@echo "This test does not use a design!"
else
  design_link: $(RUN_DIR) $(RUN_DIR)/zcui.work
  $(RUN_DIR)/zcui.work:
	@#! Experimental: doing 'ls -l' on the design build directory seems to force NFS sync
	@-bddir=$$(dirname "$(DB_ZCUI_WORK)"); \
	ls -l `dirname $$bddir` > /dev/null ;\
	ls -l "$$bddir" > /dev/null ;\
	ls -l $(DB_ZCUI_WORK) > /dev/null

	@echo "Creating link to Design build ..."
	$(QUIET) cd $(RUN_DIR); ln -fs $(DB_ZCUI_WORK)
endif

##########################################
### Edit Virtual Platform
.PHONY: edit_pct

edit_pct: $(RUN_DIR)
	$(QUIET) cd $(RUN_DIR) ; pct $(SRC_DIR)/project.tcl

##########################################
### Build Platform and External Testbenches 
.PHONY: build build_platform build_pcsh build_vssh build_sem

build: $(RUN_DIR) design_link build_platform build_tb

#!! Building all modules should be managed by $(SRC_DIR)/project.tcl or $(SRC_DIR)/project.py
build_pcsh:
	@echo "Building test platform using pcsh ..."
	$(QUIET) rm -f $(BUILD_DONE)
ifneq ($(call f_file-exists,$(SRC_DIR)/cosim.tcl),)
	$(QUIET) cd $(RUN_DIR); SRC_DIR=$(SRC_DIR) timeout $(BUILD_TIMEOUT) pcsh $(COMMON_DIR)/infra/build/build_cosim_platform.tcl
else
	$(QUIET) cd $(RUN_DIR); SRC_DIR=$(SRC_DIR) timeout $(BUILD_TIMEOUT) pcsh $(COMMON_DIR)/infra/build/build_platform.tcl
endif
	$(QUIET) touch $(BUILD_DONE)
build_vssh:
	@echo "Building test platform using vssh ..."
	$(QUIET) rm -f $(BUILD_DONE)
	$(QUIET) cd $(RUN_DIR); SRC_DIR=$(SRC_DIR) VS_VDK_NAME=$(VS_VDK_NAME) timeout $(BUILD_TIMEOUT) vssh -d $(VS_WORKSPACE) -s $(COMMON_DIR)/infra/build/build_platform.py
	$(QUIET) touch $(BUILD_DONE)

# build_tb can be used to build external dependecies other that EXT_TESTBENCH (e.g. a .so)
# EXT_TESTBENCH MUST be used only to specify the external testbench EXECUTABLE !
# Alternatively, RUN_ARGS += -e <executable> can be used
ifneq ($(EXT_TESTBENCH),)
  build_tb: $(EXT_TESTBENCH)
else
  build_tb:
endif
	$(QUIET) touch $(BUILD_DONE)

#XXX
build_sem:
	$(QUIET) HWSystem=SEM $(MAKE) build

##########################################
### Run targets
.PHONY: run run_gui run_gui_all

#TODO ??? move designFeatures and all design config from design/src to design/config? and merge both targets below to link all content of design/config to $(RUN_DIR)
$(RUN_DIR)/designFeatures: $(RUN_DIR)
	$(QUIET) ln -fs $(SRC_DIR)/designFeatures $(RUN_DIR)

$(RUN_DIR)/memory.init: $(RUN_DIR)
	$(QUIET) ln -fs $(SRC_DIR)/memory.init $(RUN_DIR)

##########
# run script (run_test.py) args

RUN_ARGS    = -t $(RUN_TIMEOUT)
RUN_ARGS   += -c $(RUN_VPCONFIG)
ifneq ($(VS_WORKSPACE),)
  RUN_ARGS += -d "$(VS_WORKSPACE)"
endif
ifneq ($(VS_VDK_NAME),)
  RUN_ARGS += -k "$(VS_VDK_NAME)"
endif
ifneq ($(RUN_SIM_SCRIPT),)
  RUN_ARGS += -s $(shell readlink -f "$(RUN_SIM_SCRIPT)")
endif
ifneq ($(EXT_TESTBENCH),)
  RUN_ARGS += -e "$(EXT_TESTBENCH)"
endif

##########
# run script ENV

RUN_PRE_LD_LIB_PATH += $(RUN_DIR)                       # for user defined libs
RUN_PRE_LD_LIB_PATH += $(RUN_DIR)/zcui.work             # for DPI xtor libs 
RUN_PRE_LD_LIB_PATH += /depot/boost_1_55_0/amd64/lib    # required by libZRDBWrapper.so 
RUN_PRE_LD_LIB_PATH += /depot/libffi/libffi-3.0.5/lib   # required on RedHat/CentOS 7 hosts as a dependency for testFramwork (zmq in run_test.py)
RUN_POS_LD_LIB_PATH += $(TESTFRAMEWORK_DIR)/lib         # needed to load the libzmq for test framework (no longer needed since 20.03 !)  

RUN_ENV += LD_LIBRARY_PATH=$(call f_make_ldlib_path,$(RUN_PRE_LD_LIB_PATH),$(RUN_POS_LD_LIB_PATH))

ifeq ($(call v_compare,$(NORM_ZHAL_VER), -ge, 2022090000),1) 
  ifdef _USING_REGRUN_FLOW_
    _VS_CONFIG_DIR ?= $(RUN_DIR)/.vs_config
    RUN_ENV += SNPS_VPX_USER_HOME=$(_VS_CONFIG_DIR)
.PHONY: install_zhal_api
install_zhal_api:
	$(SNPS_VP_HOME)/java/bin/java -jar $(SNPS_ZHAL_HOME)/../zhal.ui.p2/ZhalInstaller.jar --skip-vs --skip-gui -d 4 -c $(_VS_CONFIG_DIR)

    ifneq ($(RUN_SIM_SCRIPT),)
run: install_zhal_api
    endif
  endif #_USING_REGRUN_FLOW_
endif # ZHAL_VER >= 2022.09

ifndef ZHAL_TEST_DISABLE_REQUIREMENT_CHECK
run: check_requirements
endif

run: $(RUN_DIR)/designFeatures $(RUN_DIR)/memory.init
	$(call do_pre_run)
	set -e; set -o pipefail; cd $(RUN_DIR); rm -f $(RUN_LOGFILE); $(RUN_ENV) $(TESTFRAMEWORK_DIR)/bin/run_test.py $(RUN_ARGS) |& tee $(RUN_LOGFILE)

run_gui_all: RUN_ARGS += -g
run_gui_all: run

run_gui: $(RUN_DIR)/designFeatures $(RUN_DIR)/memory.init
	$(call do_pre_run)

  ifeq ($(VS_WORKSPACE),)
	cd $(RUN_DIR); $(RUN_ENV) vs -d $(RUN_DIR) -r $(RUN_VPCONFIG) --logfile "sim.log"
  else
	cd $(RUN_DIR); $(RUN_ENV) vs -d $(VS_WORKSPACE) -r $(RUN_VPCONFIG) --logfile "sim.log"
  endif

##########################################
### Check targets
.PHONY: check_run check_log check_golden generate_golden

check_run: check_log check_golden

check_golden:
	@[ -f "$(RUN_DIR)/$(RUN_LOGFILE)" ] || { echo "Could not find simulation run log file ($(RUN_DIR)/$(RUN_LOGFILE))! Use 'make run' first"; exit 1; }

  ifneq ($(call f_file-exists,$(TEST_DIR)/$(GOLDEN_FILENAME)),) 
	# check if simulation output is matching golden file
	@if ! grep $(GOLDEN_MASK) "$(RUN_DIR)/$(RUN_LOGFILE)" | sed -n '/ \+Hybride \+platform \+is \+ready/,//p' | tail -n +3 | diff - "$(TEST_DIR)/$(GOLDEN_FILENAME)" ; then \
		echo "[GOLDEN CHECK] FAILED: simulation log does not match the expected GOLDEN file '$(GOLDEN_FILENAME)'"; exit 1 ; \
	else echo "[GOLDEN CHECK] OK: simulation log matches the expected GOLDEN file '$(GOLDEN_FILENAME)'"; fi
  endif

# Check simulation log for error keywords 
# ! This does not necessarly indicate a test failure !
# ! TODO: this is temporary since not all tests have been migrarted to report failures using the Test Framework 
check_log:
	@[ -f "$(RUN_DIR)/$(RUN_LOGFILE)" ] || { echo "Could not find simulation run log file ($(RUN_DIR)/$(RUN_LOGFILE))! Use 'make run' first"; exit 1; }
	@cd $(RUN_DIR); if ! grep -q 'Connecting to server on ipc:///tmp/' $(RUN_LOGFILE) && grep -w 'Test FAILED\|ERROR\|Error\|segmentation fault' $(RUN_LOGFILE) ; then \
		echo -e "[LOG CHECK] MAYBE_FAILED: siluation log has at least one failure keyword.\n\tThis does not necessarily indicated a failure!\n\tPlease check simulation log to make sure." | tee -a $(TEST_REPORTER); exit 1; \
	elif grep -q '^ *Result: PASS *$$' $(RUN_LOGFILE) ; then \
		echo "[LOG CHECK] OK: run_test doesn't report failure"; \
	else echo "[LOG CHECK] OK: simulation log does not contain any failing keywords."; fi \


generate_golden: $(TEST_DIR)/$(GOLDEN_FILENAME)
$(TEST_DIR)/$(GOLDEN_FILENAME): $(RUN_DIR)/$(RUN_LOGFILE)
	grep $(GOLDEN_MASK) $(RUN_DIR)/$(RUN_LOGFILE) | sed -n '/ \+Hybride \+platform \+is \+ready/,//p' | tail -n +3 > $(TEST_DIR)/$(GOLDEN_FILENAME)

##########################################
### Clean targets
.PHONY: clean

clean:
	@echo "cleaning up run directory..."
	$(QUIET) rm -rf $(RUN_DIR)/*

##########################################
### Debug/Profile targets
.PHONY: convsim sim2perf sim2ddd sim2valgrind sim2normal run_perf run_debug check_perf

sim2perf: CONV_SIM_PROG='perf record -F 999 -g -o perf.data --'
sim2ddd: CONV_SIM_PROG=/depot/ddd/bin/ddd
sim2valgrind: CONV_SIM_PROG='valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes --verbose'

sim2perf sim2ddd sim2valgrind: convsim

convsim:
	$(QUIET) set -e; cd $(RUN_DIR)     ;\
	mv $(RUN_SIM_EXE) $(RUN_SIM_EXE).exe ;\
	echo "#!/bin/sh" > $(RUN_SIM_EXE)   ;\
	echo '$(CONV_SIM_PROG) $$0.exe' >> $(RUN_SIM_EXE) ;\
	chmod +x $(RUN_SIM_EXE)             ;\

run_perf: sim2perf run
run_debug: sim2ddd run

sim2normal:
	$(QUIET) set -e; cd $(RUN_DIR); [[ -f $(RUN_SIM_EXE).exe ]] && mv $(RUN_SIM_EXE).exe $(RUN_SIM_EXE);

check_perf:
	cd $(RUN_DIR); perf report -i perf.data --threads --sort comm,dso

