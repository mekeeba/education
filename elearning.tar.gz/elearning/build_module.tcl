set HERE $::env(OUT_DIR)
set srcDir $::env(SRC_DIR)
set modelName $::env(MODEL_NAME)

set needZHAL 0
if { [info exists ::env(MODULE_REQUIRE_ZHAL) ] } {
  set needZHAL $::env(MODULE_REQUIRE_ZHAL)
}

set infraDir ${srcDir}/../common/infra
if { [info exists ::env(INFRA_DIR) ] } {
  set infraDir $::env(INFRA_DIR)
}

###################################################################
set blockName SYSTEM_LIBRARY:${modelName}
set enCap ${modelName}
set encName ${blockName}/${enCap}
set enCapHeader "${srcDir}/${modelName}.hh"
set enCapSource "${srcDir}/${modelName}.cc"
set target Release

::pct::open_library AMBA_TLM2_BL 
if { ! [info exists ::env(NORM_ZHAL_VER)] || $env(NORM_ZHAL_VER) < 2022090000 } {
    ::pct::copy_protocol_to_system_library AMBA_TLM2_BL:tlm2_amba_hybrid
} else {
    ::pct::copy_protocol_to_system_library AMBA_TLM2_BL:tlm2_amba
}

::pct::add_to_systemc_include_path $::env(SNPS_VP_HOME)/IP_common/AMBA_TLM2_BL/AMBA-PV/include 
::pct::add_to_systemc_include_path $::env(SNPS_VP_HOME)/IP_common/AMBA_TLM2_BL/include 
::pct::add_to_systemc_include_path $srcDir
::pct::add_to_systemc_include_path ${infraDir}/testframework/include

if {$needZHAL == 1} {
  ::pct::add_to_systemc_include_path $::env(ZEBU_ADAPTOR_PATH)/include
  ::pct::add_to_systemc_include_path $::env(ZEBU_ROOT)/include
  ::pct::add_to_systemc_include_path $::env(ZEBU_IP_ROOT)/include
}

::pct::set_import_protocol_generation_flag false 
::pct::set_update_existing_encaps_flag true 
::pct::set_dynamic_port_arrays_flag true 
::pct::add_systemc_define SC_INCLUDE_DYNAMIC_PROCESSES 1

::pct::load_modules --set-category load_${modelName} $enCapSource

::pct::clear_systemc_defines

#############################
#::pct::duplicate_encap_config ${blockName}/$enCap FromSource $target
::pct::create_encap_config ${blockName}/$enCap $target
::pct::set_default_encap_config ${blockName}/${enCap} $target

::pct::set_encap_config_setting $encName $target build enabled true
::pct::set_encap_config_setting $encName $target build debug false
::pct::set_encap_config_setting $encName $target build optimized true
::pct::set_encap_config_setting $encName $target build dynamic_library true
::pct::add_encap_config_setting $encName $target build target ${modelName}.${enCap} *
::pct::add_encap_config_setting $encName $target build target_directory "${HERE}/FastBuild/lib" *

::pct::add_encap_config_setting $encName $target build source_file ${HERE}/${modelName}.${enCap}.dladapter.cc *
::pct::add_encap_config_setting $encName $target build source_file "${enCapSource}" *
::pct::add_encap_config_setting $encName $target build header_file "${enCapHeader}" *

::pct::add_encap_config_setting $encName $target build define SC_INCLUDE_DYNAMIC_PROCESSES "" *

::pct::add_encap_config_setting $encName $target build include_path #(SNPS_VP_HOME)#/common/include
::pct::add_encap_config_setting $encName $target build include_path #(SNPS_VP_HOME)#/common/include/tlm
::pct::add_encap_config_setting $encName $target build include_path #(SNPS_VP_HOME)#/IP_common/AMBA_TLM2_BL/AMBA-PV/include
::pct::add_encap_config_setting $encName $target build include_path #(SNPS_VP_HOME)#/IP_common/AMBA_TLM2_BL/include
::pct::add_encap_config_setting $encName $target build include_path ${infraDir}/testframework/include
::pct::add_encap_config_setting $encName $target build library_path ${infraDir}/testframework/lib
::pct::add_encap_config_setting $encName $target build library zmq
if {$needZHAL == 1} {
  ::pct::add_encap_config_setting $encName $target build include_path #(ZEBU_ADAPTOR_PATH)#/include *
  ::pct::add_encap_config_setting $encName $target build include_path #(ZEBU_IP_ROOT)#/include *
  ::pct::add_encap_config_setting $encName $target build include_path #(ZEBU_ROOT)#/include *
  ::pct::add_encap_config_setting $encName $target build library_path #(ZEBU_ADAPTOR_PATH)#/lib *
  ::pct::add_encap_config_setting $encName $target build library_path #(ZEBU_IP_ROOT)#/lib *
  ::pct::add_encap_config_setting $encName $target build library_path #(ZEBU_ROOT)#/lib *
  ::pct::add_encap_config_setting $encName $target build library ZebuHybrid-%(COMPILER)% *
  ::pct::add_encap_config_setting $encName $target build library ZebuXtor *
  ::pct::add_encap_config_setting $encName $target build library Zebu *

  ::pct::add_encap_config_setting $encName $target build compile_flag "-fvisibility=hidden" gcc-*
  ::pct::add_encap_config_setting $encName $target build link_flag -fPIC gcc-*
  ::pct::add_encap_config_setting $encName $target build link_flag -Wl,--no-undefined gcc-*
  ::pct::add_encap_config_setting $encName $target build link_flag "-Wl,--unresolved-symbols=ignore-all" *
}

#############################
::pct::add_encap_config_setting $encName $target package dynamic_load ${modelName}.${enCap} "${HERE}/FastBuild/lib" *
#if {$needZHAL == 1} {
#  ::pct::add_encap_config_setting $encName $target package environment_variable SNPS_SLS_VP_RELAXED_LOADING_${modelName}.${enCap} 1 * 
#  ::pct::add_encap_config_setting $encName $target package environment_variable SNPS_ZHAL_LOADING_REUSE_OBJECT_${modelName}.${enCap} "${HERE}/FastBuild/lib" * 
#}

#############################
::pct::generate_dynamic_load_adapter $encName $target ${HERE}/${modelName}.${enCap}.dladapter.cc true
::pct::build_encap_config $encName $target -j16

::pct::package_encap_build_config $encName $target
::pct::clean_encap_config $encName $target

::pct::export_system_library ${modelName} ${modelName}.xml 

puts "Module ${modelName} Ready"
