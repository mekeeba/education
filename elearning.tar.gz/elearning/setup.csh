
#! /bin/csh -f


# Where is this file?
if ("$0" =~ "*setup*.csh") then
     echo "Please source '$0' instead of calling it directly"
     exit 1
endif

# Get this setup root directory
set called=($_)
if ("$called" != "") then
   set script_fn  = `readlink -f $called[2]`
   set __here = `dirname "$script_fn"`
else
   set __here = `pwd`
endif

cd $__here


# Tools versions
set SITE 					= "FR"
set MAKE_VER				= 4.2
set GCC_VER					= 9.2.0
set PYTHON_VER				= 3.8.0

# SEM modes : SEMB | SEMC
set SEM_MODE				= "SEMC"


#############
###  ZEBU ###
#############
# Zebu builds types & versions
set ZEBU_BASE_VERSION		= "2021.09-2-OST2"
set ZEBU_FINAL_VERSION		= "S-2021.09-2"
set ZEBU_MODULE_VERSION		= "2021.09-2"


################
###  ZEBU IP ###
################
# Zebu IP builds types & versions
set ZEBU_IP_OST_VER			= "S-2023.03"
set ZEBU_IP_PREREL_VER		= "S-2023.03"
set ZEBU_IP_NIGHTLY_VER		= "ZS2023.03"
set ZEBU_IP_OFFICIAL_VER	= "S-2023.03-SP1"


#############
###  ZHAL ###
#############
# ZHAL builds types & versions
# set ZHAL_BASE_VERSION 		= "U-2023.03-SP1"
set ZHAL_BASE_VERSION 		= "U-2023.03-SP1"
set ZHAL_NIGHTLY_VERSION 	= "V-2024.03-DEV-20240118"

####################
###  VIRTUALIZER ###
####################
# Vzer builds types & versions
set VZER_BASE_VERSION 		= "2023.03-2"
set VZER_FINAL_VERSION 		= "2023.03-2"

# HW_TYPE : SEM | ORION | ZS4 | ZS5 | H100
setenv HW_TYPE ZS4


# Release mode
# Officals | nightly | prerelease | OST
setenv ZEBU_BUILD_MODE		"officials"
setenv ZEBU_IP_BUILD_MODE	"officials"
setenv ZHAL_BUILD_MODE		"officials"
setenv VZER_BUILD_MODE		"officials"

source $__here/configs/setup.csh
