MIN_MAKE_VERSION := 4.2
ifneq ($(firstword $(sort $(MAKE_VERSION) $(MIN_MAKE_VERSION))),$(MIN_MAKE_VERSION))
  $(error GNU Make verion higher or equal $(MIN_MAKE_VERSION) is required!  You are running version $(MAKE_VERSION))
endif
##########################################
THIS_DIR := $(dir $(abspath $(word $(words $(MAKEFILE_LIST)),$(MAKEFILE_LIST))))

####################################
# declare a test that can be run with different test scripts
#   $1: TestName
#   $2: test scripts location relative to TestName
# Example: $(call declare_multiscript_test,PyApiTest,src/tests)
define declare_multiscript_test
  $(eval $(call __declare_multiscript_test,$1,$2))
endef
define __declare_multiscript_test
  ifneq ($(findstring $(1)_,$(TG_RUN)),)
    MAKE_OPS += RUN_SIM_SCRIPT="$(ROOT_DIR)/$(1)/$(2)/$(shell echo $(TG_RUN) | sed 's/$(1)_//' | tr -d ' ').py"
    TG_RUN := $(1)
  endif
endef

##########################################
# Required inputs

ifeq ($(ROOT_DIR),)
#! This is equivalent to $(Abs_Dir_Name) defined by regrun
#Also it could be determined from MAKEFILE_LIST..
  $(error no ROOT_DIR is specified!)
endif

TEST_DIR   ?= $(ROOT_DIR)/$(TG_RUN)
DESIGN_DIR ?= $(ROOT_DIR)/common/design

COMP_DESIGN_DIR ?= $(TS_VERIFY_TEST_LOCAL_DIR)
RUN_DESIGN_DIR  ?= $(TS_VERIFY_TEST_LOCAL_DIR)/../${TG_COMP}_compile/

MAKE_OPS += _USING_REGRUN_FLOW_=1
ifneq ($(ZHAL_TEST_USE_DESIGN_CACHE),1)
  MAKE_OPS += USE_DESIGN_BUILD_CACHE=0
endif

# build/run output in the regrun tmp dir instead of the test source dir
compil: MAKE_OPS += DESIGN_BUILD_OUTPUTDIR="$(COMP_DESIGN_DIR)"
run: MAKE_OPS += DESIGN_BUILD_OUTPUTDIR="$(RUN_DESIGN_DIR)" RUN_DIR=$(TS_VERIFY_TEST_LOCAL_DIR)/tmprun ZEBU_DESIGN_DIR=$(TS_VERIFY_TEST_LOCAL_DIR)/tmprun

##########################################
ifeq ($(PROTOCOMPILER),1)
DESIGN_BUILD_TARGET	?= compile_haps
else
DESIGN_BUILD_TARGET	?= design
endif
RUN_TARGET	        ?= build run check_run

##########################################
# Build design
#####################
#TODO support multi compile targets with 'TG_COMP'
compil: 
	@echo "Compiling design ..."
	make --debug=v -C "$(DESIGN_DIR)" $(MAKE_OPS) $(DESIGN_BUILD_TARGET) 

clean_compil:
	@echo "Cleaning design ..."
	make --debug=v -C "$(DESIGN_DIR)" $(MAKE_OPS) clean_design

##########################################
# Build / Run Testbench
#####################
ifeq ($(TG_RUN),)
run:
	$(error no TG_RUN is specified!)
clean_run:

else
run:
	@echo "Running test $(TG_RUN) ..."
	make -C "$(TEST_DIR)" $(MAKE_OPS) $(RUN_TARGET)
clean_run:
	@echo "Cleaning test $(TG_RUN) ..."
	make -C "$(TEST_DIR)" $(MAKE_OPS) clean
info:
	@echo "TG_RUN="$(TG_RUN)
	@echo $(MAKE_OPS)

endif

##########################################
.PHONY: clean_all
clean_all: clean_run clean_compil

