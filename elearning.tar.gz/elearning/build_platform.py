# This is a generic vssh script to build a VDK
#
# Inputs:
#    - env var 'SRC_DIR'     : specify the location of the source directory,
#                              which must have a 'project.py' file.
#    - env var 'VS_VDK_NAME' : specify the vdk name being created/built
#
# 'SRC_DIR/project.py' can use any of the Utility Functions below,
# but it MUST define the function:
# 'def create_vdk(srcDir, workspacePath, vdkName)'

import sys, os #, shutil
import inspect, traceback
import subprocess

THIS_SCRIPT_ABS_DIR = os.path.realpath(os.path.dirname(inspect.getfile(lambda: None)))
SRC_DIR = os.getenv('SRC_DIR')
VDK_NAME = os.getenv('VS_VDK_NAME')

RUN_DIR = os.getcwd()
PRJ_FILE = '%s/project.py' % SRC_DIR
WORK_DIR = eclipse.get_workspace_path()

TEST_BASE_DIR = os.path.dirname(SRC_DIR)
INFRA_DIR = f'{TEST_BASE_DIR}/common/infra'

#####################################################################
### Utility Functions

def info(msg):
	print('[BUILD][INFO]: %s' % msg)

def error(msg):
	print('[BUILD][ERROR]: %s' % msg)

def create_module_from_tcl(tclScript):
	info('Creating module using tcl script: %s ...' % tclScript)
	tlmcreator.execute_tcl_script(tclScript)

def create_module_pcsh(srcDir, modelName, requireZHAL=0, infraDir=None):
	'''
	This uses the default build_module.tcl script
	the <srcDir> MUST contain <modelName>.cc and <modelName>.hh
	'''
	info('Creating module "%s" using default pcsh tcl script ...' % modelName)

	script = '%s/build_module.tcl' % THIS_SCRIPT_ABS_DIR
	envcpy = os.environ.copy()
	envcpy["OUT_DIR"] = RUN_DIR
	envcpy["SRC_DIR"] = srcDir
	envcpy["MODEL_NAME"] = modelName
	envcpy["MODULE_REQUIRE_ZHAL"] = str(requireZHAL)
	if infraDir: envcpy["INFRA_DIR"] = infraDir
	subprocess.check_call(['pcsh', script], env=envcpy)

def set_parameter(instance, propertyName, value):
	instance.get_parameter(propertyName).set_value(value)

def set_parameters(instance, paramsDict):
	for propertyName, value in paramsDict.items():
		instance.get_parameter(propertyName).set_value(value)

def connect_interfaces(inst1, inst2, connections):
	for i1, i2 in connections.items():
		inst1.get_interface(i1).connect_to(inst2.get_interface(i2))

def add_library_dir(vdk, path):
	vdkcreator.refresh_workspace()
	vdk.get_library_manager().add_path(path)
	vdk.save()

def refresh_library_manager(vdk):
	vdkcreator.refresh_workspace()
	vdk.get_library_manager().refresh()

def add_instance(parent, instanceName, modelName, library, vendor='Synopsys', params=None):
	'''
	create a new instance of <ZhalModelName> from "ZebuHybrid"
	library and add it to <parent>.
	If params is specified, each key, value pair is used to initialze
	the instance's parameter <key> to <value>
	'''
	inst = parent.add_building_block(instanceName, vendor, library, modelName)
	if params: set_parameters(inst, params)
	return inst

# DEPRECATED: this is kept for old tests only!
#    ALIAS              : ZHAL_MODLE_NAME
_ZHAL_MODELS_DICT = {
    'AMBA_Initiator'    : 'ZHAL_AMBA_Initiator'   ,
    'AXI_to_AHB_bridge' : 'ZHAL_AXI_to_AHB_bridge',
    'AXI_to_APB_bridge' : 'ZHAL_AXI_to_APB_bridge',
    'CHI_Target'        : 'ZHAL_CHI_Target'       ,
    'ACE_Target'        : 'ZHAL_ACE_Target'       ,
    'AMBA_Target'       : 'ZHAL_AMBA_Target'      ,
    'GICv3_Initiator'   : 'ZHAL_GICv3_Initiator'  ,
    'GICv3_Target'      : 'ZHAL_GICv3_Target'     ,
    'PChannel'          : 'ZHAL_PChannel'         ,
    'FT_Initiator'      : 'ZHAL_FT_Initiator'     ,
    'FT_Target'         : 'ZHAL_FT_Target'        ,
    'Uart'              : 'ZHAL_Uart'             ,
    'Csi'               : 'ZHAL_Csi'              ,
    'Dsi'               : 'ZHAL_Dsi'              ,
    'Backdoor'          : 'ZHAL_Backdoor'         ,
    'DesignMem'         : 'ZHAL_DesignMem'        ,
    'FastMem'           : 'ZHAL_FastMem'          ,
    'PCIe_RC'           : 'ZHAL_PCIe_RC'          ,
    'SBReg'             : 'ZHAL_SBReg'            ,
    'SBSigIn'           : 'ZHAL_SBSigIn'          ,
    'SBSigOut'          : 'ZHAL_SBSigOut'         ,
    'SystemManager'     : 'ZHAL_SystemManager'    ,
    'ClockRegulator'    : 'ZHAL_ClockRegulator'   ,
    'CoreDebug'         : 'ZHAL_CoreDebug'        ,
    'VideoOut'          : 'ZHAL_VideoOut'         ,
}

def gen_zhal_hbb(root, zebuWorkPath:str='${ZEBU_DESIGN_DIR}/zebu.work', designfeaturePath:str='${ZEBU_DESIGN_DIR}/designFeatures', hwtopRtlPath:str='', schedulerMode:str='FreeRunning'):
	info(f'adding ZHAL CBB...')
	bb = root.add_building_block('ZebuCockpit_BB', 'Synopsys', 'ZebuHybrid', 'ZHAL_CBB')
	cfg = bb.new_configuration()
	cfg.get_parameter('zebuwork').set_value(0, zebuWorkPath)
	cfg.get_parameter('designfeature').set_value(0, designfeaturePath)
	cfg.get_parameter('hwtop').set_value(0, hwtopRtlPath)
	cfg.get_parameter('hybridtype').set_value(0, schedulerMode)

	bb.regenerate(cfg)
	return (bb, cfg)

def find_instance_byModel(buildingBlock, modelName, firstOnly=True):
	res =[]
	instances = buildingBlock.get_instances()
	for c in instances:
		if modelName in c.get_model_specifier():
			res.append(c)
			if firstOnly: return res
	return res

#####################################################################
### Build flow

info('run Dir   : %s' % RUN_DIR)
info('src Dir   : %s' % SRC_DIR)
info('workspace : %s' % WORK_DIR)
info('vdk name  : %s' % VDK_NAME)

## Create vdk or Open it if already exists
if not eclipse.exists(VDK_NAME):
	info('Creating vdk using %s ...' % PRJ_FILE)
	if not os.path.exists(PRJ_FILE):
		error('"project.py" is not found: %s' % PRJ_FILE)
		sys.exit(1)

	execfile(PRJ_FILE)

	if 'zhal_construct_vdk' in dir():
		vdk = vdkcreator.create_vdk(VDK_NAME)
		add_library_dir(vdk, '${ZEBU_ADAPTOR_PATH}')
		zhal_models = [m.split('/')[2] for m in vdk.get_library_manager().get_models() if 'ZebuHybrid' in m]
		for model in zhal_models:
			aliases = {model, model.replace('ZHAL_', '')}
			info(f'ZHAL model {model} aliased by {aliases}')
			for alias in aliases:
				exec(f"""def zhal_add_{alias}(parent, instanceName, params=None):
					return add_instance(parent, instanceName, '{model}', 'ZebuHybrid', 'Synopsys', params)""")
		add_library_dir(vdk, RUN_DIR)
		try:
			info('invoking zhal_construct_vdk...')
			zhal_construct_vdk(vdk, vdk.get_root())
		except:
			vdkcreator.delete_project(VDK_NAME)
			raise
	elif 'create_vdk' in dir():
		#! DEPRECATED: use zhal_construct_vdk instead
		for k, v in _ZHAL_MODELS_DICT.items():
			exec(f"""def zhal_add_{k}(parent, instanceName, params=None):
				return add_instance(parent, instanceName, '{v}', 'ZebuHybrid', 'Synopsys', params)""")
		vdk = create_vdk(SRC_DIR, WORK_DIR, VDK_NAME)
	else:
		error('"project.py" MUST define a function "zhal_construct_vdk(vdk, root)"!')
		sys.exit(2)
else:
	info('Opening vdk ...')
	vdk = vdkcreator.open(VDK_NAME)

if not vdk: # TODO check that a valid vdk ..
	error("Failed to create vdk")
	sys.exit(3)

## Building the vdk
info('Building vdk ...')
vdk.save()
vdk.build()

os.system('ln -s %s/export %s' % (vdk.get_build_directory(), RUN_DIR))
with open(f'{RUN_DIR}/.pctlibignore', 'w') as fp:
	fp.write('export\n')
	fp.write('workspace\n')


