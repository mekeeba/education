#!/bin/env pcsh

set srcDir $env(SRC_DIR)
set THIS_DIR [file normalize [file dirname [info script]]]

#########################################################
# These can be called from the build script "${srcDir}/project.tcl"

proc build_module_custom {tclscript} {
   exec pcsh $tclscript >&@stdout
}

proc build_module {HERE srcDir modelName {requireZHAL 0}} {
   upvar THIS_DIR THIS_DIR
   global env;

   set env(OUT_DIR) $HERE
   set env(SRC_DIR) $srcDir 
   set env(MODEL_NAME) $modelName
   set env(MODULE_REQUIRE_ZHAL) $requireZHAL 

   exec pcsh $THIS_DIR/build_module.tcl >&@stdout
}

#########################################################
if { [file exists "${srcDir}/create_test.tcl"] == 1} {
    # A test can have a custom pcsh build script  
    puts "Using ${srcDir}/create_test.tcl ..."
    source "${srcDir}/create_test.tcl"
} else {
    puts "Using default build script ..."

    ::pct::set_preference_value /GUI/DoNotShow/StartupDialog true
    ::pct::set_preference_value /CLI/CommandLogging/DoNotLog { add_to_selection remove_from_selection get_location_on_owner get_orientation get_shape set_location_on_owner get_angle get_bounds get_connection_on get_fixed set_preference_value set_orientation }
    ::pct::start_log pct.log

    # Default build script 
    source "${srcDir}/project.tcl"
    
    ::pct::create_simulation_build_project .
    ::pct::set_simulation_build_project_setting Debug "Optimize Level" "Optimize more (-O2)" 
    ::pct::set_simulation_build_project_setting Debug "Backdoor Mode" true 
    ::pct::set_simulation_build_project_setting Debug "Disable Elaboration" true 
    # Disable build cache ~/.ccache
    ::pct::set_simulation_build_project_setting Debug "Cache Objects" false
    ::pct::set_simulation_build_project_setting Debug {Export Type} {DYNAMIC NETLIST}
    ::pct::export_simulation 
    ::scsh::open-project
    ::scsh::build-options -skip-elab on
    ::scsh::build

    puts "SystemC Platform Ready"
}
