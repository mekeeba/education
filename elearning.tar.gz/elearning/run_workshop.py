import os

global waves_path 
global waves_db 

waves_path = os.environ["HYBRID_TRAINING_ROOT_DIR"]+'/vs.run/training.ztdb'
waves_db = zhal.create_qwc_waveform(waves_path, "driverClk")


def start_waveforms_dump ():
    print("SCRIPT-INFO: Dumping waveforms")
    waves_db.capture()
    
def waveforms_dumping_status ():
    print("SCRIPT-INFO: Waveforms dumping status")
    waves_db.get_status()

def close_waveforms_dump ():
    print("SCRIPT-INFO: Flushing and closing dumping waveforms")
    waves_db.flush()
    waves_db.close()
       
def check_hw_time(time):
    hw_time = zhal.get_hw_time()
    if (hw_time >= time):
        print("SCRIPT-INFO: HW time triggered value has reached")
        return True
    else:
        return False
 
def trigger_hw_time(trig_time):
    print("SCRIPT-INFO: Waiting for hardware time trigger ...")
    while True:
        if (check_hw_time(trig_time) == True): close_waveforms_dump (); break


run_platform() 
start_waveforms_dump()
add_delay(5)
auto_run_test_1() 
add_delay(5)
trigger_hw_time(79000000)
